#------------------------------------------------------------------------------
# Copyright (c) 2005, Enthought, Inc.
# All rights reserved.
# 
# This software is provided without warranty under the terms of the BSD
# license included in enthought/LICENSE.txt and may be redistributed only
# under the conditions described in the aforementioned license.  The license
# is also available online at http://www.enthought.com/licenses/BSD.txt
# Thanks for using Enthought open source!
# 
# Author: Enthought, Inc.
# Description: <Enthought util package component>
#------------------------------------------------------------------------------
#-------------------------------------------------------------------------------
#
#  Handle the editing of a simulation variable distribution.
#
#  Date: 06/17/2003
#
#  Written By: David C. Morrill
#
#  (c) Copyright 2003 by Enthought, Inc.
#
#-------------------------------------------------------------------------------

#-------------------------------------------------------------------------------
#  Imports:
#-------------------------------------------------------------------------------

import wx

import enthought.traits
import enthought.traits.wxtrait_sheet as trait_sheet

from enthought.enable.wx                      import Window

from enthought.chaco.plot_axis                import PlotAxis
from enthought.chaco.plot_canvas              import PlotCanvas
from enthought.chaco.plot_component           import PlotComponent
from enthought.util.distribution.distribution import Distribution
from enthought.util.distribution.constant     import Constant
from enthought.util.distribution.gaussian     import Gaussian
from enthought.util.distribution.triangular   import Triangular
from enthought.util.distribution.log_normal   import LogNormal

#-------------------------------------------------------------------------------
#  Constants:
#-------------------------------------------------------------------------------

DistributionTypes = [ 'Constant', 'Gaussian', 'Triangular', 'Log Normal' ]

DistributionTypeFactory = {
   'Constant':   Constant,
   'Gaussian':   Gaussian,
   'Triangular': Triangular,
   'Log Normal': LogNormal
}

#-------------------------------------------------------------------------------
#  'DistributionEditor' class:
#-------------------------------------------------------------------------------

class DistributionEditor ( trait_sheet.wxTraitEditor ):
    
   #----------------------------------------------------------------------------
   #  Initialize the trait editor:
   #----------------------------------------------------------------------------
   
   def __init__ ( self, low, high, handler = None ):
       self.low          = low
       self.high         = high
       self.handler      = handler
       self.distribution = None
       self.dist_cache   = {}
   
   #----------------------------------------------------------------------------
   #  Create an in-place custom view of the current value of the 
   # 'trait_name' trait of 'object':
   #----------------------------------------------------------------------------

   def custom_editor ( self, object, trait_name, description, handler, 
                             parent ):
       # Create a panel to hold all of the custom controls:
       panel    = wx.Panel( parent, -1 )
       h_sizer  = wx.BoxSizer( wx.HORIZONTAL )
       v_sizer  = wx.BoxSizer( wx.VERTICAL )
       h_sizer2 = wx.BoxSizer( wx.HORIZONTAL )
                             
       # Get the current distribution:
       cur_distribution = getattr( object, trait_name )  
       
       # Add the current distribution type widget:
       h_sizer2.Add( wx.StaticText( panel, -1, 'Type:', 
                            style = wx.ALIGN_RIGHT ), 0, wx.RIGHT, 2 )
       choice  = cur_distribution.__class__.__name__
       control = panel.dist_type = wx.Choice( panel, -1,
                    wx.Point( 0, 0 ), wx.Size( 100, 25 ), 
                    DistributionTypes, name = choice )
       control.SetStringSelection( choice )
       wx.EVT_CHOICE( panel, control.GetId(), self.on_value_changed )
       h_sizer2.Add( control, 1 )
       v_sizer.Add( h_sizer2 )
       
       # Create the panel to hold the specific distribution editor:
       panel.edit_panel = edit_panel = wx.Panel( panel, -1 )
       self.plot_window = plot = Window( panel, size = wx.Size( 130, 110 ) )
       self.canvas = PlotCanvas( axis       = PlotAxis( label_style = 'none' ),
                                 axis_index = PlotAxis( label_style = 'none' ),
                                 plot_min_height = 20, 
                                 plot_min_width  = 20 )
       plot.component = PlotComponent( component = self.canvas )
       
       self.init_distribution( edit_panel, cur_distribution )

       v_sizer.Add( edit_panel )
       h_sizer.Add( v_sizer )
       v_sizer2 = wx.BoxSizer( wx.VERTICAL )
#       if object.has_ge:
#           self.copy_ge = button = wx.Button( panel, -1, 'Copy GE' )
#           button.SetToolTip( wx.ToolTip( '' ) )
#           wx.EVT_BUTTON( panel, button.GetId(), self.on_copy )
#           v_sizer2.Add( button, 0, wx.EXPAND )
       v_sizer2.Add( plot,    1, wx.EXPAND )
       h_sizer.Add( v_sizer2, 1, wx.EXPAND | wx.LEFT, 6 )

       # Set-up the layout:
       panel.SetSizer( h_sizer )
       h_sizer.Fit( panel )
           
       # Return the panel as the result:
       return panel
       
   #----------------------------------------------------------------------------
   #  Initialize the specific distribution editor:
   #----------------------------------------------------------------------------
   
   def init_distribution ( self, edit_panel, distribution ):
       edit_panel.SetSizer( None )
       edit_panel.DestroyChildren()
       sizer = wx.BoxSizer( wx.VERTICAL )
       sizer.Add( trait_sheet.TraitSheet( edit_panel, distribution ) )
       edit_panel.SetSizer( sizer )
       sizer.Fit( edit_panel )
       self.update_plot( distribution )
       #if self.distribution is not None:
       #   self.distribution.on_trait_change( self.distribution_changed, 
       #                                      remove = True )
       self.distribution = distribution
       if hasattr( distribution, 'ui_name' ):
           name = distribution.ui_name
       else:
           name = distribution.__class__.__name__
       self.dist_cache[ name ] = distribution
       #distribution.on_trait_change( self.distribution_changed )
       
   #----------------------------------------------------------------------------
   #  Update the current distribution plot:
   #----------------------------------------------------------------------------
   
   def update_plot ( self, distribution = None ):
       if distribution is not None:
           self.distribution = distribution
       del self.canvas[:]
       if hasattr( self, 'global_equivalent_distribution' ):
           ge_dist = self.global_equivalent_distribution.plot_value()
           ge_dist.set( axis = PlotAxis( visible      = 'no', 
                                         tick_visible = 'no',
                                         grid_visible = 'no',
                                         label_style  = 'none' ) )
           self.canvas.add( ge_dist )
       self.canvas.add( self.distribution.plot_value() )
       self.canvas.redraw()
       
   #----------------------------------------------------------------------------
   #  Handle some trait of the current distribution changing value:
   #----------------------------------------------------------------------------
   
   def distribution_changed ( self, distribution, trait_name, old, new ):
       self.update_plot( distribution )
   
   #----------------------------------------------------------------------------
   #  Set a new 'global equivalent' distribution:
   #----------------------------------------------------------------------------
   
   def set_global_equivalent ( self, global_equivalent_distribution ):
       self.global_equivalent_distribution = global_equivalent_distribution
       self.copy_ge.GetToolTip().SetTip( 'Low: %g, Mid: %g, High: %g' % (
            global_equivalent_distribution.low,
            global_equivalent_distribution.mid,
            global_equivalent_distribution.high ) )
       self.update_plot()

   #----------------------------------------------------------------------------
   #  Handle the user selecting a new value from the combo box:
   #----------------------------------------------------------------------------

   def on_value_changed ( self, event ):
       panel        = event.GetEventObject().GetParent()
       dist_class   = event.GetString()
       distribution = self.dist_cache.get( dist_class )
       if distribution is None:
           distribution = DistributionTypeFactory[ dist_class ]( 
                             self.low, self.high )
           distribution.on_trait_change( self.distribution_changed )
           if self.handler is not None:
               distribution.on_trait_change( self.handler )
       self.set( panel.object, panel.trait_name, distribution, panel.handler )
       self.init_distribution( panel.edit_panel, distribution )
       panel.Layout()
       if self.handler is not None:
           self.handler()
       
   #----------------------------------------------------------------------------
   #  Copy the global equivalence values to the current distribution:
   #----------------------------------------------------------------------------
   
   def on_copy ( self, event ):
       distribution = self.global_equivalent_distribution.clone()
       panel        = event.GetEventObject().GetParent()
       panel.dist_type.SetStringSelection( distribution.__class__.__name__ )
       self.init_distribution( panel.edit_panel, distribution )
