#!/usr/bin/env python

# we have to maintain 2 min versions for each numpy and scipy
# because releases do not include svn versions
minimum_numpy_version_svn = '0.9.7.2476'
minimum_scipy_version_svn = '0.4.9.1882'
minimum_numpy_version = '0.9.8'
minimum_scipy_version = '0.4.9'

def configuration(parent_package='',top_path=None):
    global minimum_numpy_version
    global minimum_scipy_version
    import numpy
    if (4 == len(numpy.__version__.split('.'))):
        minimum_numpy_version = minimum_numpy_version_svn
    if numpy.__version__ < minimum_numpy_version:
        raise RuntimeError, 'numpy version %s or higher required, but got %s'\
              % (minimum_numpy_version, numpy.__version__)
    import scipy
    if (4 == len(scipy.__version__.split('.'))):
        minimum_scipy_version = minimum_scipy_version_svn
    if scipy.__version__ < minimum_scipy_version:
        raise RuntimeError, 'scipy version %s or higher required, but got %s'\
              % (minimum_scipy_version, scipy.__version__)
    from numpy.distutils.misc_util import Configuration
    config = Configuration('enthought',parent_package,top_path)
    config.set_options(ignore_setup_xxx_py=True,
                       assume_default_configuration=True,
                       delegate_options_to_subpackages=True,
                       quiet=True)

    config.add_data_files('LICENSE.txt')

    config.add_subpackage('chaco')

    config.add_subpackage('chaco2')
    config.add_subpackage('chaco2.examples')
    config.add_subpackage('chaco2.tools')
    config.add_subpackage('chaco2.advanced_datamodel')
    config.add_data_files('chaco2/*.txt', 'chaco2/LICENSE')
    config.add_data_dir('chaco2/doc')
    config.add_data_dir('chaco2/tests')
    
    config.add_subpackage('charm')
    config.add_subpackage('charm.ui')
    config.add_subpackage('charm.ui.action')
    config.add_data_dir('charm/ui/images')
    config.add_subpackage('charm.plugin')
    config.add_subpackage('charm.plugin.charm')
    config.add_subpackage('charm.plugin.charm.view')
    config.add_data_dir('charm/plugin/charm/images')
    config.add_data_dir('charm/apps')
    
    config.add_data_dir('envisage/repository/images')

    config.add_subpackage('component')
    config.add_data_dir('component/image')

    config.add_subpackage('debug')
    config.add_subpackage('debug.*')
    config.add_data_dir('debug/images')

    config.add_subpackage('enable')
    config.add_subpackage('enable2')

    config.add_subpackage('endo')

#    config.add_data_dir('enquire')

    config.add_subpackage('envisage')

    config.add_subpackage('freetype')

    config.add_subpackage('gotcha')
    config.add_subpackage('gotcha.*')
    config.add_subpackage('gotcha.*.*')
    config.add_data_dir('gotcha/*/images')

    config.add_subpackage('graph')
    config.add_subpackage('graph.*')
    config.add_subpackage('graph.*.*')
    config.add_data_dir('graph/scripts/resource_type/images')
    config.add_data_dir('graph/chips/resource_type/images')
    config.add_data_dir('graph/function/scripts')
    config.add_data_dir('graph/function/tests')
#    config.add_data_dir('graph/vpl/images')
#    config.add_data_dir('graph/vpl/resource_type/images')
    config.add_data_files('graph/*.doc','graph/*.txt')
    config.add_data_files('graph/function/*.xml','graph/tests/*.m')

    config.add_subpackage('greenlet')

    config.add_subpackage('guitest')

    config.add_subpackage('help')
    config.add_subpackage('help.tests')
    config.add_data_dir('help/EnLibHelp')
    config.add_data_dir('help/TestHelp')
    config.add_data_files('help/*.chm')
    config.add_data_files('help/*.png')

    config.add_subpackage('interpolate')

    config.add_subpackage('io')
    config.add_data_dir('io/tests')

    config.add_subpackage('kiva')

    config.add_subpackage('logger')
    config.add_subpackage('logger.*')
    config.add_subpackage('logger.*.*')
    config.add_data_dir('logger/widget/images')
    config.add_subpackage('logging')

    config.add_subpackage('mathtext')
    config.add_data_files('mathtext/*.txt','mathtext/*.pyd')
    config.add_data_dir('mathtext/share/matplotlib')
    config.add_data_dir('mathtext/license')

    config.add_subpackage('mathematics')

    config.add_subpackage('mayavi')

    config.add_subpackage('model')
    config.add_data_dir('model/tests')
    config.add_data_dir('model/images')
    config.add_data_files('model/*.ppt')

    config.add_subpackage('naming')
    config.add_subpackage('naming.*')
    config.add_data_dir('naming/examples')
    config.add_data_dir('naming/tests')
    config.add_data_dir('naming/ui/images')

    config.add_subpackage('persistence')

    config.add_subpackage('plugins')
    config.add_subpackage('plugins.*')
    config.add_subpackage('plugins.*.*')
    config.add_data_files('plugins/*.txt')

    config.add_subpackage('pyface')

#    config.add_data_dir('research')

    config.add_subpackage('resource')
    config.add_subpackage('resource_type')
    config.add_data_dir('resource_type/images')

    config.add_subpackage('sharing')
    config.add_subpackage('sharing.plugin')
    config.add_data_dir('sharing/test')
    config.add_data_files('sharing/*.txt')

    config.add_subpackage('sweet_pickle')
    config.add_data_dir('sweet_pickle/tests')
    config.add_data_files('sweet_pickle/*.txt')

    config.add_subpackage('testing')
    config.add_data_dir('testing/research')
    config.add_data_files('testing/research/*.txt')
    config.add_data_files('testing/*.txt')

    config.add_subpackage('traits')
    config.add_subpackage('traits.ui.wx')
    
    config.add_subpackage('tvtk')

    config.add_subpackage('type_manager')
    config.add_data_dir('type_manager/tests')

    config.add_subpackage('units')
    config.add_subpackage('units.plugin')
    config.add_subpackage('units.plugin.action')
    config.add_data_dir('units/data')
    config.add_data_dir('units/tests')
    
    config.add_subpackage('util')

   # nightly builds are svn-exported and not in svn
   #config.make_svn_version_py()
    
    config.get_version()
    
    config.make_config_py() # installs __config__.py

    return config

if __name__ == "__main__":

    # Remove current working directory from sys.path
    # to avoid importing numpy.logging as Python std. logging:
    import os, sys
    for cwd in ['','.',os.getcwd(),os.path.dirname(sys.argv[0])]:
        while cwd in sys.path: sys.path.remove(cwd)

    from numpy.distutils.core import setup
    setup(configuration=configuration)
