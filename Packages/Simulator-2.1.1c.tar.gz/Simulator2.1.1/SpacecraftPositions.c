/****************************************************************************/
/*                                                                          */
/* TITLE: LISA's Spacecraft Positions                                       */
/* AUTHORS: Louis J. Rubbo and Neil J. Cornish                              */
/* DATE: July 11, 2003                                                      */
/* VERSION: 2.0                                                             */
/*                                                                          */
/*                                                                          */
/* ABSTRACT: These set of functions return the position of the LISA         */
/* spacecraft given the time and the spacecraft index as inputs.            */
/*                                                                          */
/****************************************************************************/


/*************************  REQUIRED HEADER FILES  **************************/

#include <math.h>
#include "LISAconstants.h"



/**************************  SPACECRAFT POSITIONS  **************************/

double xPos(double t, int i)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Azimuthal position of the guiding center */
  double alpha;

 /* Relative orbital phase of each spacecraft within the constellation */
  double beta;

 /* The x-position of the i-th spacecraft */
  double x;


          /* -------------------  CALCULATIONS  ------------------- */

  alpha = 2.0*pi*(t/year) + kappa;

  beta = 2.0*pi*(i-1)/3.0 + lambda;

  x = Rgc*cos(alpha) + (1.0/2.0)*Rgc*ecc*(cos(2.0*alpha-beta)-3.0*cos(beta));
  /*   + (1.0/8.0)*Rgc*pow(ecc,2)*( 3.0*cos(3.0*alpha-2.0*beta)
       - 5.0*(2.0*cos(alpha)+cos(alpha-2.0*beta)) ); */

  return x;
}





double yPos(double t, int i)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Azimuthal position of the guiding center */
  double alpha;

 /* Relative orbital phase of each spacecraft within the constellation */
  double beta;

 /* The y-position of the i-th spacecraft */
  double y;


          /* -------------------  CALCULATIONS  ------------------- */

  alpha = 2.0*pi*(t/year) + kappa;

  beta = 2.0*pi*(i-1)/3.0 + lambda;

  y = Rgc*sin(alpha) + (1.0/2.0)*Rgc*ecc*(sin(2.0*alpha-beta)-3.0*sin(beta));
    /*    + (1.0/8.0)*Rgc*pow(ecc,2)*( 3.0*sin(3.0*alpha-2.0*beta)
	  - 5.0*(2.0*sin(alpha)-sin(alpha-2.0*beta)) ); */

  return y;
}





double zPos(double t, int i)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Azimuthal position of the guiding center */
  double alpha;

 /* Relative orbital phasse of each spacecraft within the constellation */
  double beta;

 /* The z-position of the i-th spacecraft */
  double z;


          /* -------------------  CALCULATIONS  ------------------- */

  alpha = 2.0*pi*(t/year) + kappa;

  beta = 2.0*pi*(i-1)/3.0 + lambda;

  z = -sqrt(3.0)*Rgc*ecc*cos(alpha-beta);
    /*  + sqrt(3.0)*Rgc*pow(ecc,2)*( pow(cos(alpha-beta),2)
	+ 2.0*pow(sin(alpha-beta),2) ); */


  return z;
}
