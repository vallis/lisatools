#------------------------------------------------------------------------------
# Copyright (c) 2005, Enthought, Inc.
# All rights reserved.
# 
# This software is provided without warranty under the terms of the BSD
# license included in enthought/LICENSE.txt and may be redistributed only
# under the conditions described in the aforementioned license.  The license
# is also available online at http://www.enthought.com/licenses/BSD.txt
# Thanks for using Enthought open source!
# 
# Author: Enthought, Inc.
# Description: <Enthought util package component>
#------------------------------------------------------------------------------
""" Base class for distributions. """


# Enthought library imports.
from enthought.traits import HasDynamicTraits, Trait


class Distribution(HasDynamicTraits):
    """ Base class for distributions. """

    __traitsXXXX__ = {

        # The lowest value allowed in the distribution.
        'low_bound' : 0.0,

        # The highest value allowed in the distribution.
        'high_bound' : 0.0
    }

    def __init__ (self, low_bound, high_bound):
        """ Creates a new distribution. """

        # Base-class constructor.
        HasDynamicTraits.__init__(self)

        # Dynamic traits.
        self.add_trait('low_bound', Trait(low_bound))
        self.add_trait('high_bound', Trait(low_bound))
        
        self.low_bound  = low_bound
        self.high_bound = high_bound

        return

    ###########################################################################
    # 'Distribution' interface.
    ###########################################################################

    def clone(self):
        """ Returns a clone of the distribution. """

        raise 'Implement Me'
    
    def generate(self, n=1):
        """ Generates 'n' values in the distribution. """

        raise 'Implement Me'

    def plot_value(self):
        """ Returns a plot value representing the distribution. """

        raise 'Implement Me'

#### EOF #####################################################################
