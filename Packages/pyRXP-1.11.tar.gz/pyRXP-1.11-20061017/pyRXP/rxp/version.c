char *rxp_version_string = 
    "RXP 1.4.0 Copyright Richard Tobin, LTG, HCRC, University of Edinburgh";
