#------------------------------------------------------------------------------
# Copyright (c) 2005, Enthought, Inc.
# All rights reserved.
# 
# This software is provided without warranty under the terms of the BSD
# license included in enthought/LICENSE.txt and may be redistributed only
# under the conditions described in the aforementioned license.  The license
# is also available online at http://www.enthought.com/licenses/BSD.txt
# Thanks for using Enthought open source!
# 
# Author: Enthought, Inc.
# Description: <Enthought util package component>
#------------------------------------------------------------------------------
#-------------------------------------------------------------------------------
#  Imports:
#-------------------------------------------------------------------------------

from enthought.traits  import Trait, TraitRange, TraitGroup
from distribution      import Distribution
from scipy             import arange, clip, stats

#-------------------------------------------------------------------------------
#  'LogNormal' class:
#-------------------------------------------------------------------------------

class LogNormal ( Distribution ):
    """ A log normal distribution. """

    __editable_traits__ = TraitGroup( 'location', 'scale', 'shape', 
                                      style = 'text' )
                                      
    ui_name = 'Log Normal'

    def __init__ ( self, low_bound, high_bound, **traits ):
        Distribution.__init__( self, low_bound, high_bound )
        self.add_trait( 'location', Trait( (low_bound + high_bound ) / 2, 
                                    TraitRange( low_bound, high_bound ) ) )
        high = None
        if high_bound is not None:
           high = max( 2.0, high_bound - low_bound )
        self.add_trait( 'scale', Trait( 2.0, TraitRange( 0.000001, high ) ) )
        self.add_trait( 'shape', Trait( 0.6, TraitRange( 0.0, 50.0 ) ) )
        self.set( **traits )
        self.fill_color = ( 247.0/255.0, 188.0/255.0, 91.0/255.0, 0.6 )
        
    def clone ( self ):
        return LogNormal( self.low_bound, self.high_bound ).set( 
                          location = self.location,
                          scale    = self.scale,
                          shape    = self.shape )

    def generate ( self, n = 500 ):
        """ Generates 'n' values in the distribution. """
        result = stats.lognorm( self.shape, self.location, self.scale, 
                                size = n )
        if self.high_bound is None:
           return max( result, self.low_bound )
        else: 
           return clip( result, self.low_bound, self.high_bound )
        
    def plot_value ( self ):

        from enthought.chaco.plot_value import PlotValue        

        '''x = arange( self.location, self.location + (5.0 * self.scale), 
                    self.scale / 20.0 )'''
        x = arange( self.low_bound, self.high_bound, self.scale / 20.0 )
                    
        return PlotValue( stats.lognorm.pdf( x, self.shape, self.location, 
                                                self.scale ), 
                          index      = PlotValue( x ),
                          type       = 'stackedline',
                          fill_color = self.fill_color )
