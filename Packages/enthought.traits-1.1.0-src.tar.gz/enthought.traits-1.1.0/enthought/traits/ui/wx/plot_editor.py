#------------------------------------------------------------------------------
# Copyright (c) 2005, Enthought, Inc.
# All rights reserved.
# 
# This software is provided without warranty under the terms of the BSD
# license included in enthought/LICENSE.txt and may be redistributed only
# under the conditions described in the aforementioned license.  The license
# is also available online at http://www.enthought.com/licenses/BSD.txt
# Thanks for using Enthought open source!
# 
# Author: David C. Morrill
# Date: 01/14/2005
# Description: Define the wxPython implementation of the various simple plot
#              editors and the plot editor factory.
#
#  Symbols defined: ToolkitEditorFactory
#
#------------------------------------------------------------------------------

#-------------------------------------------------------------------------------
#  Imports:
#-------------------------------------------------------------------------------

import wx

from enthought.traits    import List, Str, true, Range, Tuple, RGBAColor
from enthought.traits.ui import View, Item, EnableRGBAColorEditor                             
from editor_factory      import EditorFactory
from editor              import Editor

from enthought.enable.wx import Window

from enthought.chaco.wx.plot import PlotAxis, PlotComponent, PlotTitle
from enthought.chaco.wx.plot import PlotValue


from enthought.util.numerix  import arange

#-------------------------------------------------------------------------------
#  Constants:  
#-------------------------------------------------------------------------------

WindowColor = ( 236.0 / 255.0, 233.0 / 255.0, 216.0 / 255.0, 1.0 )

#-------------------------------------------------------------------------------
#  Trait definitions:  
#-------------------------------------------------------------------------------

# Range of values for an axis:
AxisRange =  Tuple( ( 0.0, 1.0, 0.01 ), 
                    labels = [ 'Low', 'High', 'Step' ],
                    cols   = 3 )
                    
# Minimum/Maximum axis bounds:                    
AxisBounds = Tuple( ( 0.0, 1.0 ),
                    labels = [ 'Min', 'Max' ],
                    cols   = 2 )

# Height/Width range for the plot widget:                    
PlotSize = Range( 50, 1000, 180 )

# Range of plot line weights:
LineWeight = Range( 1, 9, 3 )

# Defines the color editor to use for various color traits:
color_editor = EnableRGBAColorEditor( auto_set = False )

#-------------------------------------------------------------------------------
#  'ToolkitEditorFactory' class:
#-------------------------------------------------------------------------------

class ToolkitEditorFactory ( EditorFactory ):
    
    #---------------------------------------------------------------------------
    #  Trait definitions:
    #---------------------------------------------------------------------------
    
    traits   = List( Str )  # List of traits the plot is associated with
    title    = Str          # Plot title
    x_label  = Str          # X-axis label
    y_label  = Str          # Y-axis label
    x_range  = AxisRange    # X-axis range
    x_values = Str          # Name of handler method to compute x values
    y_values = Str          # Name of handler method to compute y values
    x_auto   = true         # Should X-axis bounds be automatically computed?
    x_bounds = AxisBounds   # X-axis bounds (i.e. min/max values)
    y_auto   = true         # Should Y-axis bounds be automatically computed?
    y_bounds = AxisBounds   # Y-axis bounds (i.e. min/max values)
    width    = PlotSize     # Width of the plot editor
    height   = PlotSize     # Height of the plot editor
    weight   = LineWeight   # Weight of plot line (i.e. line thickness)
    color    = RGBAColor( 'blue',  editor = color_editor ) # Line color 
    bg_color = RGBAColor( 'white', editor = color_editor ) # Background color
    
    #---------------------------------------------------------------------------
    #  Traits view definition:    
    #---------------------------------------------------------------------------
        
    traits_view = View( [ [ 'traits',
                            '|[Trait Names]<>' ],
                          [ 'title', 'x_label', 'y_label', 
                            '|[Labels]' ],
                          [ 'y_values', '_', 'x_values',
                            Item( 'x_range', 
                                  enabled_when = "object.x_values == ''" ),
                            '|[Plot Values]' ],
                          [ [ 'x_auto',
                              Item( 'x_bounds',
                                    enabled_when = "not object.x_auto" ),
                              '-' ],
                            [ 'y_auto',
                              Item( 'y_bounds',
                                    enabled_when = "not object.y_auto" ),
                              '-' ],
                            '|[Plot bounds]' ],
                          [ 'width', 'height',
                            '-[Plot Size]' ],
                          [ 'weight{Line Weight}', '_', 
                            'color{Line Color}', 
                            'bg_color{Background color}',
                            '|[Plot Attributes]' ]
                        ] )
    
    #---------------------------------------------------------------------------
    #  'Editor' factory methods:
    #---------------------------------------------------------------------------
    
    def simple_editor ( self, ui, object, name, description, parent ):
        return PlotEditor( parent,
                           factory     = self, 
                           ui          = ui, 
                           object      = object, 
                           name        = name, 
                           description = description )
    
    def text_editor ( self, ui, object, name, description, parent ):
        return PlotEditor( parent,
                           factory     = self, 
                           ui          = ui, 
                           object      = object, 
                           name        = name, 
                           description = description )
    
    def readonly_editor ( self, ui, object, name, description, parent ):
        return PlotEditor( parent,
                           factory     = self, 
                           ui          = ui, 
                           object      = object, 
                           name        = name, 
                           description = description )

#-------------------------------------------------------------------------------
#  'PlotEditor' class  
#-------------------------------------------------------------------------------
                     
class PlotEditor ( Editor ):
    
    #---------------------------------------------------------------------------
    #  Finishes initializing the editor by creating the underlying toolkit
    #  widget:
    #---------------------------------------------------------------------------
        
    def init ( self, parent ):
        """ Finishes initializing the editor by creating the underlying toolkit
            widget.
        """
        factory = self.factory
        x_axis  = PlotAxis()
        if not factory.x_auto:
            x_axis.bound_low  = min( *factory.x_bounds )
            x_axis.bound_high = max( *factory.x_bounds )
        if factory.x_label != '':
            x_axis.title = factory.x_label
        y_axis = PlotAxis()
        if not factory.y_auto:
            y_axis.bound_low  = min( *factory.y_bounds )
            y_axis.bound_high = max( *factory.y_bounds )
        if factory.y_label != '':
            y_axis.title = factory.y_label
        self._pv = pv = PlotValue( line_color    = factory.color,
                                   line_weight   = factory.weight,
                                   bg_color      = WindowColor,
                                   plot_bg_color = factory.bg_color,
                                   axis_index    = x_axis,
                                   axis          = y_axis )
        if factory.title != '':
            pv.add( PlotTitle( text = factory.title ) )
        window       = Window( parent, 
                               component = PlotComponent( component = pv ) )
        self.control = control = window.control
        control.SetSize( ( factory.width, factory.height ) )
        object = self.object
        for name in factory.traits:
            object.on_trait_change( self._update_editor, name ) 
        
    #---------------------------------------------------------------------------
    #  Disposes of the contents of an editor:    
    #---------------------------------------------------------------------------
                
    def dispose ( self ):
        """ Disposes of the contents of an editor.
        """
        object = self.object
        for name in self.factory.traits:
            object.on_trait_change( self._update_editor, name, remove = True )
        super( PlotEditor, self ).dispose()
            
    #---------------------------------------------------------------------------
    #  Updates the editor when the object trait changes external to the editor:
    #---------------------------------------------------------------------------
        
    def update_editor ( self ):
        """ Updates the editor when the object trait changes external to the 
            editor.
        """
        factory  = self.factory
        x_values = None
        if factory.x_values != '':
            try:
                x_values = getattr( self.ui.handler, factory.x_values )(
                                    self.ui.info )
            except:
                pass
        if x_values is None:
            try:
                low, high, step = factory.x_range
                x_values = arange( low, high + (step / 2.0), step )
            except:
                x_values = arange( 0.0, 1.005, 0.01 )
        try:
            y_values = getattr( self.ui.handler, factory.y_values )( 
                                self.ui.info, x_values )
        except:
            t = x_values - 0.5
            y_values = t * t
        self._pv.set( data = y_values, index = PlotValue( x_values ) )
        self._pv.update()
