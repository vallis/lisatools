#------------------------------------------------------------------------------
# Copyright (c) 2005, Enthought, Inc.
# All rights reserved.
# 
# This software is provided without warranty under the terms of the BSD
# license included in enthought/LICENSE.txt and may be redistributed only
# under the conditions described in the aforementioned license.  The license
# is also available online at http://www.enthought.com/licenses/BSD.txt
# Thanks for using Enthought open source!
# 
# Author: Enthought, Inc.
# Description: <Enthought pyface package component>
#------------------------------------------------------------------------------
""" System metrics (screen width and height etc). """


# Major package imports.
import wx

# Enthought library imports.
from enthought.traits import HasPrivateTraits, Int, Property


class SystemMetrics(HasPrivateTraits):
    """ System metrics (screen width and height etc). """
    
    # fixme: add in all the other metrics as we find the need for them.

    #### 'SystemMetrics' interface ############################################
    
    # The width of the screen in pixels.    
    screen_width = Property(Int)

    # The height of the screen in pixels.
    screen_height = Property(Int)
    
    ###########################################################################
    # 'SystemMetrics' interface.
    ###########################################################################

    #### Properties ###########################################################
    
    def _get_screen_width(self):
        """ Returns the width of the scene in pixels. """
        
        return wx.SystemSettings.GetMetric( wx.SYS_SCREEN_X )
    
    def _get_screen_height(self):
        """ Returns the height of the scene in pixels. """
        
        return wx.SystemSettings.GetMetric( wx.SYS_SCREEN_Y )
    
#### EOF ######################################################################
