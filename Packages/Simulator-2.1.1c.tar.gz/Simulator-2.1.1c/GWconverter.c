/****************************************************************************/
/*                                                                          */
/* TITLE: Gravitational Wave Converter                                      */
/* AUTHOR: Neil J. Cornish                                                  */
/* DATE: June 23, 2006                                                      */
/* VERSION: 2.1.1                                                           */
/*                                                                          */
/*                                                                          */
/* ABSTRACT: This code imports the individual polarization signals and      */
/* feeds them to the simulator in bite size, binary pieces.                 */
/*                                                                          */
/*                                                                          */
/* COMPILE: gcc -o GWconverter GWconverter.c -lm                            */
/*                                                                          */
/****************************************************************************/


/*************************  REQUIRED HEADER FILES  **************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <stdlib.h>

#include "LISAconstants.h"
#include "IO/readxml.h"

/**************  PROTOTYPE DECLARATIONS FOR INTERNAL FUNCTIONS  *************/

void FileWriteSP(char*, int, double, double, double);
void FileWritePS(double*, double*, long, long);
void KILL(char*);



/* ============================  MAIN PROGRAM  ============================ */

int main(int argc, char* argv[])
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Polarized signals h_plus and h_cross */
  double* hp;
  double* hc;

 /* Spline interpolation of Polarized signals h_plus and h_cross */
  double* hp2;
  double* hc2;
  double* hpu;
  double* hcu;
  double* hps;
  double* hcs;

 /* variable used in splint */
  int div;

 /* variables used in splint */
  double x, y, delt;

 /* variables used in sline */
  double pp, pc;

 /* Root name for the files */
  char root[50];

 /* Power of 2 that gives the total number of sample data points for the  
    gravitaional wave */
  int nsource;

 /* Observation time (this does not include padding) */
  double ObsTime;

 /* Polar location of the source in heliocentric-ecliptic coordinates */
  double theta;

 /* Azimuthal location of the source in heliocentric-ecliptic coordinates */
  double phi;

 /* Filename character array */
  char Filename[50];

 /* Interval of time between data points (seconds) */
  double Dt;


 /* Number of sample data points per section with padding included */
  long Ninsec;
  long Njoin;
  long Nmid;
  long Ntot;

 /* Boosted number of sample data points with padding included */
  long Nnew;

 /* Error message character array */
  char ErrorMessage[100];

 /* Loop index */
  long i, j, a, b;

  size_t ns;

  LISASource *lisasource;


          /* -------------------  CALCULATIONS  ------------------- */

  printf("\n\n");
  printf("  ______________________________________________________  \n");
  printf(" |                                                      | \n");
  printf(" |              Gravitationl Wave Converter             | \n");
  printf(" |______________________________________________________| \n\n");


 /* Check that this code was properly called and send filenames to 
    appropriate character arrays */

  if (argc < 2) 
    KILL("A source name was not entered at the command line prompt.\n");

 /* Read in the gravitational wave file */

  strcpy(root, argv[1]);
  sprintf(Filename, "XML/%s_Barycenter.xml", argv[1]);

  printf("\nImporting the polarization signals for %s.\n\n",root);

  lisasource = getLISASources(Filename);

  /* up the sample cadence by a factor of 4 using a cubic spline.
     this allows us to use linear interpolation in the rest of the
     code */

  div = 4;
  delt = 0.25;
  
     /* Calculate the increment of time and the total number of data points in
        each section */

  Dt = dt/4.0;

  /* pad by Tpad at either end of the record */
  Njoin = 2*(int)ceil(Tpad/dt);

  /* Ndiv and NFFT must be powers of 2 */
  Nmid = (NFFT/Ndiv);

  Ninsec = Nmid + Njoin;

  Ntot = NFFT + Njoin;

  /* make sure input data is compatible with current Simulator setup */
  
  if(lisasource->TimeSeries->Length != Ntot)
    {
     sprintf(ErrorMessage,"Data file length %d not compatible with current simulator setting %d\n", lisasource->TimeSeries->Data[0]->Length, Ntot);
     KILL(ErrorMessage);
    }

  if(fabs(lisasource->TimeSeries->Cadence - dt) > 1.0e-8)
    {
     sprintf(ErrorMessage,"Input cadence %g not compatible with current simulator setting %g\n", lisasource->TimeSeries->Cadence, dt);
     KILL(ErrorMessage);
    }

   /* Import the source parameters */

  theta = pi/2.0-lisasource->EclipticLatitude;
  phi = lisasource->EclipticLongitude;

  hp = (double*) malloc (Ninsec*sizeof(double));
  hc = (double*) malloc (Ninsec*sizeof(double));

  if (!hp || !hc) KILL("Out of memory!");

  /* Begin the loop over sections */

  for (i = 0; i < Ndiv; i++)
    {

      printf("Processing section %d of %d\n", (i+1), Ndiv);

    // copy in the ith section of the array

  for (a = 0 ; a < Ninsec ; a++)
    {
      hp[a] = lisasource->TimeSeries->Data[0]->data[a+Nmid*i];
      hc[a] = lisasource->TimeSeries->Data[1]->data[a+Nmid*i];
    }

      hp2 = (double*) malloc (Ninsec*sizeof(double));
      hc2 = (double*) malloc (Ninsec*sizeof(double));
      hpu = (double*) malloc (Ninsec*sizeof(double));
      hcu = (double*) malloc (Ninsec*sizeof(double));

     if (!hp2 || !hc2) KILL("Out of memory!");
     if (!hpu || !hcu) KILL("Out of memory!");

      hp2[0] = 0.0;
      hc2[0] = 0.0;
      hpu[0] = 0.0;
      hcu[0] = 0.0;

     for (a = 1 ; a < Ninsec-1 ; a++)
       {
         pp = 0.5*hp2[a-1]+2.0;
         hp2[a] = -0.5/pp;
	 hpu[a] = (hp[a+1]-2.0*hp[a]+hp[a-1]);
         hpu[a] = (3.0*hpu[a]-0.5*hpu[a-1])/pp;

         pc = 0.5*hc2[a-1]+2.0;
         hc2[a] = -0.5/pc;
	 hcu[a] = (hc[a+1]-2.0*hc[a]+hc[a-1]);
         hcu[a] = (3.0*hcu[a]-0.5*hcu[a-1])/pc;
       }

      hp2[Ninsec-1] = 0.0;
      hc2[Ninsec-1] = 0.0;

     for (a = Ninsec-2 ; a >= 0 ; a--)
       {
	 hp2[a] = hp2[a]*hp2[a+1]+hpu[a];
	 hc2[a] = hc2[a]*hc2[a+1]+hcu[a];
       }

     free(hpu);
     free(hcu);

     Nnew = div*Ninsec-(div-1);

      hps = (double*) malloc (Nnew*sizeof(double));
      hcs = (double*) malloc (Nnew*sizeof(double));

      if (!hps || !hcs) KILL("Out of memory!");

     for (a = 0 ; a < Nnew-1 ; a++)
       {
	 b=a/div;
         x= (double)(b+1)-delt*((double)(a));
         y= delt*((double)(a))-(double)(b); 

         hps[a] = x*hp[b]+y*hp[b+1]+((x*x*x-x)*hp2[b]+(y*y*y-y)*hp2[b+1])/6.0;
         hcs[a] = x*hc[b]+y*hc[b+1]+((x*x*x-x)*hc2[b]+(y*y*y-y)*hc2[b+1])/6.0;
       }

      hps[Nnew-1] =  hp[Ninsec-1];
      hcs[Nnew-1] =  hc[Ninsec-1];

     free(hp2);
     free(hc2);

 /* Write the polarization signals to Ndiv files in binary format */

     FileWritePS(hps, hcs, (i+1), Nnew);

     free(hps);
     free(hcs);

    }

 /* Free the allocated memory */

  free(hp);
  free(hc);

 /* Write a text file that contains the source parameters */

  FileWriteSP(root, Nnew, theta, phi, T);


  printf("\n----------------------------------------------------------\n");
  printf("Source %s is now imported.\n\n\n",root);

    
  return 0;
}

/* ======================================================================== */


/***************************  INTERNAL FUNCTIONS  ***************************/


void FileWritePS(double* hp, double* hc, long a, long N)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Initial bin number within the n_ij array to start for each section */
  long Nint;

 /* Loop indexes */
  long b;

 /* Filename character array */
  char Filename[50];

 /* Error message character array */
  char ErrorMessage[100];

 /* File pointer */
  FILE* AmpsOut;


          /* -------------------  CALCULATIONS  ------------------- */


 /* Divide the polarization signals into equal size sections and save each
    section to a binary formatted file */

    sprintf(Filename, "Binary/GW%i.dat", a);

    if ((AmpsOut = fopen(Filename, "wb")) == NULL)
    {
      sprintf(ErrorMessage, "Cannot open the file %s.\n", Filename);
      KILL(ErrorMessage);
    }

    for (b = 0 ; b < N ; b++) 
    {
      fwrite(&hp[b], sizeof(double), 1, AmpsOut);
      fwrite(&hc[b], sizeof(double), 1, AmpsOut);  
    }

    fclose(AmpsOut);

  return;
}

void FileWriteSP(char* root, int Ninsec, double theta, double phi, 
		 double ObsTime)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Error message character array */
  char ErrorMessage[100];

 /* Filename charater array */
  char* Filename;

 /* File pointer */
  FILE* SPout;


          /* -------------------  CALCULATIONS  ------------------- */

  printf("\n Writing the source parameters to a file.\n\n");


 /* Open an ASCII formatted file */

  Filename = "Binary/SourceParameters.dat";

  if ((SPout = fopen(Filename, "w")) == NULL)
  {
    sprintf(ErrorMessage, "Cannot open the file %s.\n", Filename);
    KILL(ErrorMessage);
  }


 /* Write the source parameters to the file */

  fprintf(SPout, "%s\n", root);
  fprintf(SPout, "%i\n", Ninsec);
  fprintf(SPout, "%g\n", theta);
  fprintf(SPout, "%g\n", phi);
  fprintf(SPout, "%.12g\n", ObsTime);


  /* Close the file */

  fclose(SPout);


  return;
}


void KILL(char* Message)
{
  printf("\a\n");
  printf(Message);
  printf("Terminating the program.\n\n");
  exit(1);


  return;
}
