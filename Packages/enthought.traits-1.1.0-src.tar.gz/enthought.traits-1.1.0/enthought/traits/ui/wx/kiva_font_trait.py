#------------------------------------------------------------------------------
# Copyright (c) 2005, Enthought, Inc.
# All rights reserved.
# 
# This software is provided without warranty under the terms of the BSD
# license included in enthought/LICENSE.txt and may be redistributed only
# under the conditions described in the aforementioned license.  The license
# is also available online at http://www.enthought.com/licenses/BSD.txt
# Thanks for using Enthought open source!
# 
# Author: David C. Morrill
# Date: 12/22/2004
# Description: Trait definition for a wxPython-based Kiva font.
#------------------------------------------------------------------------------

#-------------------------------------------------------------------------------
#  Imports:
#-------------------------------------------------------------------------------

from enthought.kiva.constants import NORMAL, BOLD, ITALIC, DEFAULT, ROMAN, \
                                     DECORATIVE, SCRIPT, SWISS, MODERN
from enthought.kiva.fonttools import Font

from enthought.traits         import Trait, TraitError, TraitHandler
from enthought.traits.ui      import KivaFontEditor

#-------------------------------------------------------------------------------
#  Convert a string into a valid 'Font' object (if possible):
#-------------------------------------------------------------------------------

font_families = {
    'default':    DEFAULT,
    'decorative': DECORATIVE,
    'roman':      ROMAN,
    'script':     SCRIPT,
    'swiss':      SWISS,
    'modern':     MODERN
}

font_styles = {
    'italic': ITALIC
}

font_weights = {
    'bold': BOLD
}

font_noise = [ 'pt', 'point', 'family' ]

#-------------------------------------------------------------------------------
#  'TraitKivaFont' class'
#-------------------------------------------------------------------------------

class TraitKivaFont ( TraitHandler ):
    
    #---------------------------------------------------------------------------
    #  Validates that the value is a valid font:
    #---------------------------------------------------------------------------
    
    def validate ( self, object, name, value ):
        """ Validates that the value is a valid font.
        """
        if isinstance( value, Font ):
            return value
        try:
            point_size = 10
            family     = DEFAULT
            style      = NORMAL
            weight     = NORMAL
            underline  = 0
            facename   = []
            for word in value.split():
                lword = word.lower()
                if font_families.has_key( lword ):
                    family = font_families[ lword ]
                elif font_styles.has_key( lword ):
                    style = font_styles[ lword ]
                elif font_weights.has_key( lword ):
                    weight = font_weights[ lword ]
                elif lword == 'underline':
                    underline = 1
                elif lword not in font_noise:
                    try:
                        point_size = int( lword )
                    except:
                        facename.append( word )
            return Font( point_size, family, weight, style, underline, 
                         ' '.join( facename ) )
        except:
            pass
        raise TraitError, ( object, name, 'a font descriptor string',
                            repr( value ) )

    def info ( self ):                              
        return ( "a string describing a font (e.g. '12 pt bold italic "
                 "swiss family Arial' or 'default 12')" )

#-------------------------------------------------------------------------------
#  Define a wxPython specific font trait:
#-------------------------------------------------------------------------------

fh       = TraitKivaFont()
KivaFont = Trait( fh.validate( None, None, 'modern 12' ), fh, 
                  editor = KivaFontEditor )
    
