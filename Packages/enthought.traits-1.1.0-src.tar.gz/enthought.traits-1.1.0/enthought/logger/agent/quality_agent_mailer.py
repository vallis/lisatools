#------------------------------------------------------------------------------
# Copyright (c) 2005, Enthought, Inc.
# All rights reserved.
# 
# This software is provided without warranty under the terms of the BSD
# license included in enthought/LICENSE.txt and may be redistributed only
# under the conditions described in the aforementioned license.  The license
# is also available online at http://www.enthought.com/licenses/BSD.txt
# Thanks for using Enthought open source!
# 
# Author: Enthought, Inc.
# Description: <Enthought logger package component>
#------------------------------------------------------------------------------

# Standard library imports.
import os

# Enthought library imports.
from enthought.enthought_version import revision
from enthought.logger import logger 
from enthought.util.home_directory import get_home_directory
from enthought.envisage import get_application

def create_email_message(fromaddr, toaddrs, ccaddrs, subject, priority, 
                         include_project=False, stack_trace="", comments=""): 
    # format a message suitable to be sent to the Roundup bug tracker
       
    from email import Encoders
    from email.MIMEMultipart import MIMEMultipart
    from email.MIMEText import MIMEText
    from email.MIMEBase import MIMEBase

    message = MIMEMultipart()
    message['Subject'] = "%s [priority=%s]" % (subject, priority) 
    message['To'] = ', '.join(toaddrs)
    message['Cc'] = ', '.join(ccaddrs)
    message['From'] = fromaddr
    message.preamble = 'You will not see this in a MIME-aware mail reader.\n'
    message.epilogue = ' ' # To guarantee the message ends with a newline
    
    # First section is simple ASCII data ... 
    m = []
    m.append("CPLab Bug Report - Build #%s" % revision)
    m.append("==============================")
    m.append("")
    
    if len(comments) > 0: 
        m.append("Comments:")
        m.append("========")
        m.append(comments)
        m.append("")
        
    if len(stack_trace) > 0:
        m.append("Stack Trace:")
        m.append("===========")
        m.append(stack_trace)
        m.append("")
        
    msg = MIMEText('\n'.join(m))       
    message.attach(msg)
    
    # Include the log file ...
    if True:
        try:
            log = os.path.join(get_home_directory(), 'envisage.log')   
            f = open(log, 'r')
            entries = f.readlines()
            f.close()

            ctype = 'application/octet-stream'
            maintype, subtype = ctype.split('/', 1)
            msg = MIMEBase(maintype, subtype)        

            msg = MIMEText(''.join(entries))
            msg.add_header('Content-Disposition', 'attachment', filename='logfile.txt')  
            message.attach(msg)  
        except:
            logger.exception('Failed to include log file with message')
            
    # Include the environment variables ...            
    if True:
        """
        Transmit the user's environment settings as well.  Main purpose is to
        work out the user name to help with following up on bug reports and 
        in future we should probably send less data. 
        """
        try:
            entries = []
            for key, value in os.environ.iteritems():
                entries.append('%30s : %s\n' % (key, value))
            
            ctype = 'application/octet-stream'
            maintype, subtype = ctype.split('/', 1)
            msg = MIMEBase(maintype, subtype)        

            msg = MIMEText(''.join(entries))
            msg.add_header('Content-Disposition', 'attachment', filename='environment.txt')  
            message.attach(msg)  
            
        except:
            logger.exception('Failed to include environment variables with message')
              

    # Attach the project if requested ...
    if include_project:
        try:    
        
            if get_application() is not None:
                workspace = get_application().service_registry.get_service('enthought.envisage.project.IWorkspace')
                dir = workspace.path
                relpath = os.path.basename(dir)    
        
                import zipfile
                from cStringIO import StringIO
        
                ctype = 'application/octet-stream'
                maintype, subtype = ctype.split('/', 1)
                msg = MIMEBase(maintype, subtype)
       
                file_object = StringIO()
                zip = zipfile.ZipFile(file_object, 'w')
                _append_to_zip_archive(zip, dir, relpath)  
                zip.close()          

                msg.set_payload(file_object.getvalue()) 
  
                Encoders.encode_base64(msg) # Encode the payload using Base64   
                msg.add_header('Content-Disposition', 'attachment', filename='workspace.zip')  
                message.attach(msg)  
            
                file_object.close()  
        except:
            logger.exception('Failed to include workspace files with message')     
                
    return message     

        
def _append_to_zip_archive(zip, dir, relpath):  
    """ Add all files in and below directory dir into zip archive"""
    for filename in os.listdir(dir):
        path = os.path.join(dir, filename)

        if os.path.isfile(path):
            name = os.path.join(relpath, filename)
            zip.write(path, name)
            logger.debug('adding %s to error report' % name) 
        else:
            if filename != ".svn": # skip svn files if any
                subdir = os.path.join(dir, filename)
                _append_to_zip_archive(zip, subdir, os.path.join(relpath, filename))
    return     


