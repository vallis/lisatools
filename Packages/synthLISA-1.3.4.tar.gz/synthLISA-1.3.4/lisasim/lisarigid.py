import numpy

from math import sin, cos, sqrt, pi
import time

# initially, support only one source
# the source (CoherentWave?) must define
#
# - phi(samples,deltat,zerotime)
# - f(samples,deltat,zerotime)
# - amp(samples,deltat,zerotime)
# - hp(samples,deltat,zerotime)
# - hc(samples,deltat,zerotime)
#
# perhaps in addition to instantaneous versions thereof;
# hp and hc could be replaced by an instantaneous amplitude
# and inclination phase, according to the LAL convention

def sinc(x):
    return numpy.where(x == 0, 1.0, numpy.sin(x)/x)

class TDIrigid(object):
    zeta = -pi/6.0
    
    year = 31536000.0
    omega = 2 * pi / year
    
    R = 499.004
    
    L = 16.6782
    
    def __init__(self,lisa,coherentwave):
        self.eta0 = lisa.geteta0()
        self.xi0  = lisa.getxi0()
        self.sw   = lisa.getsw()
        
        # should also handle CircularRotating's t0
        
        self.coherentwave = coherentwave
        
        self.beta  = coherentwave.EclipticLatitude
        self.lambd = coherentwave.EclipticLongitude
        self.psi   = -coherentwave.Polarization
        
        # question here... presumably coherent wave should already be adding
        # it's phi0 in its phi call, so this is just a shift with respect to that... 
        
        # self.phi0  = coherentwave.phi0
        self.phi0  = 0
        
        self.sigma = [None] + [ 3.0 * pi / 2.0 - 2.0 * (i-1) * pi / 3.0 for i in range(1,4) ]
        
        if self.sw < 0:
            # exchanging s/c 2 and 3 if sw < 0; also need to invert arms,
            # see definition of c[i] below
            self.sigma[2], self.sigma[3] = self.sigma[3], self.sigma[2]
        
        # references to simplify formulas below
        eta0,xi0,zeta = self.eta0,self.xi0,self.zeta
        beta,lambd,psi = self.beta,self.lambd,self.psi
        sigma = self.sigma
        
        self.cc = [None] + [ ( -3 * cos(beta) * sin(eta0 - lambd + xi0 + sigma[i]) / 4.0,
                               -sqrt(3) * sin(beta) * sin(xi0 + sigma[i]) / 2.0,
                               -cos(beta) * sin(eta0 - lambd - xi0 - sigma[i]) / 4.0,
                                sqrt(3) * sin(beta) * cos(xi0 + sigma[i]) / 2.0,
                               -cos(beta) * cos(eta0 - lambd - xi0 - sigma[i]) / 4.0 )
                             for i in range(1,4) ]
        
        # self.dc = [None] + [ (  sqrt(3) * cos(beta) * cos(eta0 - lambd + xi0 + sigma[i]) / 8.0,
        #                         sin(beta) * cos(xi0 + sigma[i]) / 4.0,
        #                        -cos(beta) * cos(eta0 - lambd - xi0 - sigma[i]) / (8.0*sqrt(3)),
        #                         sin(beta) * sin(xi0 + sigma[i]) / 4.0,
        #                         cos(beta) * sin(eta0 - lambd - xi0 - sigma[i]) / (8.0*sqrt(3)) )
        #                      for i in range(1,4) ]
        
        self.dc = [None] + [ ( -cos(beta) * sin(eta0 - lambd + xi0 - 2*sigma[i]) * sqrt(3) / 8.0,
                               -sin(beta) * sin(xi0 - 2*sigma[i]) / 4.0,
                               -cos(beta) * sin(eta0 - lambd - xi0 + 2*sigma[i]) / (8*sqrt(3)),
                                sin(beta) * cos(xi0 - 2*sigma[i]) / 4.0,
                               -cos(beta) * cos(eta0 - lambd - xi0 + 2*sigma[i]) / (8*sqrt(3)) )
                             for i in range(1,4) ]
        
        U = (  (1 + sin(beta)**2) * (1 - sin(zeta))**2 / 16.0,
              -cos(zeta) * sin(2*beta) * (1 - sin(zeta)) / 8.0,
               3 * cos(beta)**2 * cos(zeta)**2 / 8.0,
               cos(zeta) * sin(2*beta) * (1 + sin(zeta)) / 8.0,
               (1 + sin(beta)**2) * (1 + sin(zeta))**2 / 16.0 )
        
        V = ( -sin(beta) * (1 - sin(zeta))**2 / 8.0,
               cos(beta) * cos(zeta) * (1 - sin(zeta)) / 4.0,
               0.0,
               cos(beta) * cos(zeta) * (1 + sin(zeta)) / 4.0,
               sin(beta) * (1 + sin(zeta))**2 / 8.0 )
        
        self.uc = [None] + [ ( (-cos(beta)**2 * (-2 + 3*cos(zeta)**2) / 8.0 + U[0] * cos(2*(eta0 - lambd + xi0 + sigma[i]))),
                               (-cos(eta0 - lambd) * sin(2*beta) * sin(2*zeta) / 8.0 + U[1] * cos(eta0 - lambd + 2*xi0 + 2*sigma[i])),
                               (-(-3 + cos(2*beta)) * cos(2*(eta0 - lambd)) * cos(zeta)**2 / 16.0 + U[2] * cos(2*(xi0 + sigma[i]))),
                               (U[3] *  cos(eta0 - lambd - 2*xi0 - 2*sigma[i])),
                               (U[4] *  cos(2*(eta0 - lambd - xi0 - sigma[i]))),
                               ( sin(eta0 - lambd) * sin(2*beta) * sin(2*zeta) / 8.0 + U[1] * sin(eta0 - lambd + 2*xi0 + 2*sigma[i])),
                               ( (-3 + cos(2*beta)) * sin(2*(eta0 - lambd)) * cos(zeta)**2 / 16.0 + U[2] * sin(2*(xi0 + sigma[i]))),
                               (U[3] * -sin(eta0 - lambd - 2*xi0 - 2*sigma[i])),
                               (U[4] * -sin(2*(eta0 - lambd - xi0 - sigma[i]))) )
                             for i in range(1,4) ]     
        
        self.vc = [None] + [ ( (V[0] *  sin(2*(eta0 - lambd + xi0 + sigma[i]))),
                               (cos(beta) * sin(eta0 - lambd) * sin(2*zeta) / 4.0 + V[1] * sin(eta0 - lambd + 2*xi0 + 2*sigma[i])),
                               (-sin(2*(eta0 - lambd)) * cos(zeta)**2 * sin(beta) / 4.0),
                               (V[3] * -sin(eta0 - lambd - 2*xi0 - 2*sigma[i])),
                               (V[4] * -sin(2*(eta0 - lambd - xi0 - sigma[i]))),
                               (cos(beta) * cos(eta0 - lambd) * sin(2*zeta) / 4.0 - V[1] * cos(eta0 - lambd + 2*xi0 + 2*sigma[i])),
                               (-cos(2*(eta0 - lambd)) * cos(zeta)**2 * sin(beta) / 4.0),
                               (V[3] * -cos(eta0 - lambd - 2*xi0 - 2*sigma[i])),
                               (V[4] * -cos(2*(eta0 - lambd - xi0 - sigma[i]))) )
                             for i in range(1,4) ]
        
        self.samples,self.deltat,self.zerotime = None,None,None
        
        self.phim = {}
        self.trf = {}
    
    def setup(self,samples,deltat,zerotime = 0.0):
        if (self.samples,self.deltat,self.zerotime) == (samples,deltat,zerotime):
            return
        
        self.samples,self.deltat,self.zerotime = samples,deltat,zerotime
        
        # assure that the interface works even if a single element is requested
        
        if deltat == 0.0:
            zerotime = samples
            samples = 1
        
        omegat = self.omega * ( zerotime + deltat * numpy.arange(0,samples,1,'d') )
        
        cosomegat = [None] + [ numpy.cos(omegat),
                               numpy.cos(2.0*omegat),
                               numpy.cos(3.0*omegat),
                               numpy.cos(4.0*omegat) ]
        
        sinomegat = [None] + [ numpy.sin(omegat),
                               numpy.sin(2.0*omegat),
                               numpy.sin(3.0*omegat),
                               numpy.sin(4.0*omegat) ]
        
        c = [None]
        for i in range(1,4):
            r  = self.cc[i][1] * cosomegat[1]
            r += self.cc[i][2] * cosomegat[2]
            r += self.cc[i][3] * sinomegat[1]
            r += self.cc[i][4] * sinomegat[2]
            r += self.cc[i][0]
            
            # inverting the direction of the arms if sw < 0
            c.append(self.sw * r)
        
        d = [None]
        for i in range(1,4):
            r  = self.dc[i][1] * cosomegat[1]
            r += self.dc[i][2] * cosomegat[2]
            r += self.dc[i][3] * sinomegat[1]
            r += self.dc[i][4] * sinomegat[2]
            r += self.dc[i][0]
            
            d.append(r)
        
        self.u = [None]
        for i in range(1,4):
            r  = self.uc[i][1] * cosomegat[1]
            r += self.uc[i][2] * cosomegat[2]
            r += self.uc[i][3] * cosomegat[3]
            r += self.uc[i][4] * cosomegat[4]
            r += self.uc[i][5] * sinomegat[1]
            r += self.uc[i][6] * sinomegat[2]
            r += self.uc[i][7] * sinomegat[3]
            r += self.uc[i][8] * sinomegat[4]
            r += self.uc[i][0]
            
            self.u.append(r)
        
        self.v = [None]
        for i in range(1,4):
            r  = self.vc[i][1] * cosomegat[1]
            r += self.vc[i][2] * cosomegat[2]
            r += self.vc[i][3] * cosomegat[3]
            r += self.vc[i][4] * cosomegat[4]
            r += self.vc[i][5] * sinomegat[1]
            r += self.vc[i][6] * sinomegat[2]
            r += self.vc[i][7] * sinomegat[3]
            r += self.vc[i][8] * sinomegat[4]
            r += self.vc[i][0]
            
            self.v.append(r)
        
        phi = self.coherentwave.phi(samples,deltat,zerotime)
        f   = self.coherentwave.f(samples,deltat,zerotime)
        
        self.amp = self.coherentwave.amp(samples,deltat,zerotime)
        
        hp  = self.coherentwave.hp(samples,deltat,zerotime)
        hc  = self.coherentwave.hc(samples,deltat,zerotime)
        
        self.phid  = phi
        self.phid += cosomegat[1] * ((2*pi*f) *  (self.R*cos(self.beta)*cos(self.eta0 - self.lambd)))
        self.phid += sinomegat[1] * ((2*pi*f) * -(self.R*cos(self.beta)*sin(self.eta0 - self.lambd)))

        self.a = [None] + [ hp * cos(self.phi0) * cos(2*self.psi) - hc * sin(self.phi0) * sin(2*self.psi),
                            hp * cos(self.phi0) * sin(2*self.psi) + hc * sin(self.phi0) * cos(2*self.psi),
                           -hp * sin(self.phi0) * cos(2*self.psi) - hc * cos(self.phi0) * sin(2*self.psi),
                           -hp * sin(self.phi0) * sin(2*self.psi) + hc * cos(self.phi0) * cos(2*self.psi) ]
        
        self.x = (2 * pi * self.L) * f
        self.xd = [None] + [ self.x * d[i] for i in range(1,4) ]
        
        self.sincp = [None] + [ sinc(0.5 * (1 + c[i]) * self.x) for i in range(1,4) ]
        self.sincm = [None] + [ sinc(0.5 * (1 - c[i]) * self.x) for i in range(1,4) ]
        
        self.phim = {}
        self.trf = {}
    
    def makescalar(self,array):
        if array.size == 1:
            return array[0]
        else:
            return array
    
    def Xm(self,samples,deltat = 0.0,zerotime = 0.0):
        self.setup(samples,deltat,zerotime) 
        return self.XYZm(2,3)
    
    def Ym(self,samples,deltat = 0.0,zerotime = 0.0):
        self.setup(samples,deltat,zerotime) 
        return self.XYZm(3,1)
    
    def Zm(self,samples,deltat = 0.0,zerotime = 0.0):
        self.setup(samples,deltat,zerotime) 
        return self.XYZm(1,2)
    
    def setupphim(self,key):
        if key not in self.phim:
            self.phim[key] = self.phid - key * self.x
    
    def setuptrf(self,key):
        if key not in self.phim:
            if key == 'XYZm':
                self.trf[key] = 2.0 * self.x * numpy.sin(self.x) * self.amp
    
    def cXYZm(self,j,k):
        self.setupphim(1.5)
        self.setupphim(2.5)
        
        self.setuptrf('XYZm')
        
        Xjc = self.trf['XYZm'] * (self.sincp[j] * numpy.cos(self.phim[1.5] - self.xd[j]) + self.sincm[j] * numpy.cos(self.phim[2.5] - self.xd[j]))
        Xkc = self.trf['XYZm'] * (self.sincp[k] * numpy.cos(self.phim[2.5] - self.xd[k]) + self.sincm[k] * numpy.cos(self.phim[1.5] - self.xd[k]))
        
        Xjs = self.trf['XYZm'] * (self.sincp[j] * numpy.sin(self.phim[1.5] - self.xd[j]) + self.sincm[j] * numpy.sin(self.phim[2.5] - self.xd[j]))
        Xks = self.trf['XYZm'] * (self.sincp[k] * numpy.sin(self.phim[2.5] - self.xd[k]) + self.sincm[k] * numpy.sin(self.phim[1.5] - self.xd[k]))
        
        return [None] + [ self.u[j] * Xjc - self.u[k] * Xkc,
                          self.v[j] * Xjc - self.v[k] * Xkc,
                          self.u[j] * Xjs - self.u[k] * Xks,
                          self.v[j] * Xjs - self.v[k] * Xks ]
    
    def XYZm(self,j,k):
        Xc = self.cXYZm(j,k)
        
        return self.makescalar(self.a[1] * Xc[1] + self.a[2] * Xc[2] + self.a[3] * Xc[3] + self.a[4] * Xc[4])
    

class CoherentSimpleBinary(object):
    def __init__(self,freq,phi0,inc,amp,elat,elon,psi):
        self.freq = freq
        
        self.phi0 = phi0
        
        self.inc = inc
        self.a = amp
        
        self.EclipticLatitude = elat
        self.EclipticLongitude = elon
        self.Polarization  = psi
    
    def phi(self,samples,deltat,zerotime):
        t = zerotime + deltat * numpy.arange(0,samples,1,'d')
        
        return (self.phi0 + 2 * pi * self.freq * t)
    
    def f(self,samples,deltat,zerotime):
        return self.freq * numpy.ones(samples,'d')
    
    def amp(self,samples,deltat,zerotime):
        return self.a * numpy.ones(samples,'d')
    
    def hp(self,samples,deltat,zerotime):
        return (1.0 + cos(self.inc)**2)
    
    def hc(self,samples,deltat,zerotime):
        return 2.0 * cos(self.inc)
    
