/****************************************************************************/
/*                                                                          */
/* TITLE: Vertex 1 Noise                                                    */
/* AUTHORS: Louis J. Rubbo and Neil J. Cornish                              */
/* DATE: June 22, 2006                                                      */
/* VERSION: 2.1.1                                                           */
/*                                                                          */
/*                                                                          */
/* ABSTRACT: This program produces a full realization of the LISA noise     */
/* associated with the signals produced with spacecraft 1 acting as the     */
/* vertex craft.  The two main effects included in the noise are photon     */
/* shot noise and acceleration noise.                                       */
/*                                                                          */
/*                                                                          */
/* COMPILE: gcc -o Vertex1Noise Vertex1Noise.c -lm                          */
/*                                                                          */
/****************************************************************************/


/*************************  REQUIRED HEADER FILES  **************************/

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "LISAconstants.h"



/*******************************  STRUCTURES  *******************************/

 /* Vertex 1 time structure (tij: time of emission from spacecraft i for a 
    photon that will be received by spacecraft j) */
struct Time
{
  double t1;
  double t21;
  double t12;
  double t31;
  double t13;
  double t21x;
  double t12x;
  double t31x;
  double t13x;
};
 


/*************  PROTOTYPE DECLARATIONS FOR INTERNAL FUNCTIONS  **************/

void MichelsonNoise(struct Time*, double*, long, long, int);
void TDINoise(struct Time*, double*, double*, long, long, int);
void MichelsonShotNoise(struct Time*, double*, double, long, long, int);
void TDIShotNoise(struct Time*, double*, double, long, long, int);
void MichelsonAccNoise(struct Time*, double*, double, long, long, int);
void TDIAccNoise(struct Time*, double*, double, long, long, int);
void VertexTimes(struct Time*, long, char*);
void FileRead(double*, long, char*);
void FileWrite(double*, long, char*);
void KILL(char*);



/* ============================  MAIN PROGRAM  ============================ */

int main(void)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Number of data points in a section without padding */
  long Nsec;

 /* Number of data points in a section with padding */
  long N;

 /* Array of Time structures */
  struct Time* Times;

 /* Time noise stream for the Michelson and X noises */
  double* Mike;
  double* Xsig;

 /* Filename character array */
  char Filename[50];
  char Xfile[50];
  char Mfile[50];

 /* rSeed recorded for file naming */
  FILE* filename;

 /* Random number seed */
  long rSeed;

 /* Loop indexes */
  long a, b;


          /* -------------------  CALCULATIONS  ------------------- */

  printf("\n\n");
  printf("  ______________________________________________________  \n");
  printf(" |                                                      | \n");
  printf(" |                    Vertex 1 Noise                    | \n");
  printf(" |______________________________________________________| \n\n");

  filename = fopen("Data/seed.txt","r");

  fscanf(filename,"%d\n",&rSeed);

  fclose(filename);

  rSeed *= -1;

  sprintf(Xfile, "Binary/XNoise_%d.bin", rSeed);
  sprintf(Mfile, "Binary/M1Noise_%d.bin", rSeed);

 /* Remove any old signal files */

  remove(Xfile);
  remove(Mfile);

 /* Calculate the section widths */

  Nsec = (int)ceil(NFFT/Ndiv);

  N = Nsec + 2*(int)ceil(Tpad/dt);


 /* Dynamically allocate the memory for the array of Time structures */

  Times = (struct Time*) malloc (Nsec*sizeof(struct Time));

  if (!Times) KILL("Out of memory!\n");


 /* Dynamically allocate the memory for the two noise data series */

  Mike = (double*) malloc (Nsec*sizeof(double));
  Xsig = (double*) malloc (Nsec*sizeof(double));

  if(!Mike || !Xsig) KILL("Out of memory.\n");


 /* Calculate the noise in the time domain */

  printf("Calculating the noise in the time domain.\n\n");

  for (a = 1 ; a <= Ndiv ; a++)
  {

   /* Initialize the noise to zero */

    for (b = 0 ; b < Nsec ; b++)
    {
      Mike[b] = 0.0;
      Xsig[b] = 0.0;
    }


   /* Import the vertex 1 times */

    sprintf(Filename, "Binary/Vert1_%i.dat", a);
    VertexTimes(Times, Nsec, Filename);


   /* Calculate the Michelson noise */

    MichelsonNoise(Times, Mike, Nsec, N, a);


   /* Calculate the X noise */

    TDINoise(Times, Mike, Xsig, Nsec, N, a);


   /* Turn the noise data series into unitless strains */

    for(b = 0 ; b < Nsec ; b++)
    {
      Mike[b] *= 1.0/(2.0*L);
      Xsig[b] *= 1.0/(2.0*L);
    }


   /* Write the time noise stream to file */

    FileWrite(Mike, Nsec, Mfile);
    FileWrite(Xsig, Nsec, Xfile);


   /* User update */

    printf("  Section %i out of %i is now complete.\n", a, (int)Ndiv);
  }


 /* Free the allocated memory */

  free(Times);
  free(Mike);
  free(Xsig);


  printf("\n----------------------------------------------------------\n");
  printf("The program is now complete.\n\n\n");


  return 0;
}

/* ======================================================================== */





/***************************  INTERNAL FUNCTIONS  ***************************/

void MichelsonNoise(struct Time* Times, double* Mike, long Nsec, long N, 
		    int Section)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Initial time for a section */
  double ts;


          /* -------------------  CALCULATIONS  ------------------- */

 /* Calculate the starting time for the section */

  ts = T0 + dt*( (double)(Section-1)*ceil(NFFT/Ndiv) - ceil(Tpad/dt) )+dt/2.0;

 /* Add in the shot noise */

  MichelsonShotNoise(Times, Mike, ts, Nsec, N, Section);


 /* Add in the acceleration noise */

  MichelsonAccNoise(Times, Mike, ts, Nsec, N, Section);


  return;
}





void TDINoise(struct Time* Times, double* Mike, double* Xsig, long Nsec, 
	      long N, int Section)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Initial time for a section */
  double ts;

 /* Loop index */
  long a;


          /* -------------------  CALCULATIONS  ------------------- */

 /* Initialize the X noise */

  for(a = 0 ; a < Nsec ; a++) Xsig[a] = Mike[a];


 /* Calculate the starting time for the section */

  ts = T0 + dt*( (double)(Section-1)*ceil(NFFT/Ndiv) - ceil(Tpad/dt) )+dt/2.0;

 /* Add in the shot noise */

  TDIShotNoise(Times, Xsig, ts, Nsec, N, Section);


 /* Add in the acceleration noise */

  TDIAccNoise(Times, Xsig, ts, Nsec, N, Section);


  return;
}





void MichelsonShotNoise(struct Time* Times, double* Mike, double ts, long Nsec,
			long N, int Section)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Helio-time */
  double t;

 /* Temporary shot noise array */
  double* nsij;

 /* Bin number that contains the time t */
  long Bin;

 /* Loop index */
  long a;

  double DT;

 /* Filename character array */
  char Filename[50];


          /* -------------------  CALCULATIONS  ------------------- */

 /* Dynamically allocate the memory for the shot noise array */

  nsij = (double*) malloc (N*sizeof(double));

  if (!nsij) KILL("Out of memory!\n");


 /* Phi21 */

  sprintf(Filename, "Binary/ShotNoise21_%i.dat", Section);
  FileRead(nsij, N, Filename);

  for (a = 0 ; a < Nsec ; a++)
  {
    t = Times[a].t1;
    Bin = (int)floor(t/dt) - (int)floor(ts/dt);
    if (Bin < 0 || Bin > N-2) 
      KILL("Requested array access is out of bounds.\n");

    DT = t - dt*floor(t/dt);

    Mike[a] += ((nsij[Bin+1]-nsij[Bin])/dt)*DT + nsij[Bin];


  }


 /* Phi12 */

  sprintf(Filename, "Binary/ShotNoise12_%i.dat", Section);
  FileRead(nsij, N, Filename);

  for (a = 0 ; a < Nsec ; a++)
  {
    t = Times[a].t21;
    Bin = (int)floor(t/dt) - (int)floor(ts/dt);

    if (Bin < 0 || Bin > N-2) 
      KILL("Requested array access is out of bounds.\n");

    DT = t - dt*floor(t/dt);

    Mike[a] += (((nsij[Bin+1]-nsij[Bin])/dt)*DT + nsij[Bin]);

  }


 /* Phi31 */

  sprintf(Filename, "Binary/ShotNoise31_%i.dat", Section);
  FileRead(nsij, N, Filename);

  for (a = 0 ; a < Nsec ; a++)
  {
    t = Times[a].t1;
    Bin = (int)floor(t/dt) - (int)floor(ts/dt);
    if (Bin < 0 || Bin > N-2) 
      KILL("Requested array access is out of bounds.\n");

    DT = t - dt*floor(t/dt);

    Mike[a] -= (((nsij[Bin+1]-nsij[Bin])/dt)*DT + nsij[Bin]);

  }


 /* Phi13 */

  sprintf(Filename, "Binary/ShotNoise13_%i.dat", Section);
  FileRead(nsij, N, Filename);

  for (a = 0 ; a < Nsec ; a++)
  {
    t = Times[a].t31;
    Bin = (int)floor(t/dt) - (int)floor(ts/dt);
    if (Bin < 0 || Bin > N-2) 
      KILL("Requested array access is out of bounds.\n");

    DT = t - dt*floor(t/dt);

    Mike[a] -= (((nsij[Bin+1]-nsij[Bin])/dt)*DT + nsij[Bin]);

  }


 /* Free the allocated memory */

  free(nsij);


  return;
}





void TDIShotNoise(struct Time* Times, double* Xsig, double ts, long Nsec,
		  long N, int Section)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Helio-time */
  double t;

 /* Temporary shot noise array */
  double* nsij;

 /* Bin number that contains the time t */
  long Bin;

 /* Loop index */
  long a;

  double DT;

 /* Filename character array */
  char Filename[50];


          /* -------------------  CALCULATIONS  ------------------- */

 /* Dynamically allocate the memory for the shot noise array */

  nsij = (double*) malloc (N*sizeof(double));

  if (!nsij) KILL("Out of memory!\n");


 /* Phi21 */

  sprintf(Filename, "Binary/ShotNoise21_%i.dat", Section);
  FileRead(nsij, N, Filename);

  for (a = 0 ; a < Nsec ; a++)
  {
    t = Times[a].t13;
    Bin = (int)floor(t/dt) - (int)floor(ts/dt);
    if (Bin < 0 || Bin > N-2) 
      KILL("Requested array access is out of bounds.\n");

    DT = t - dt*floor(t/dt);

    Xsig[a] -= (((nsij[Bin+1]-nsij[Bin])/dt)*DT + nsij[Bin]);

  }


 /* Phi12 */

  sprintf(Filename, "Binary/ShotNoise12_%i.dat", Section);
  FileRead(nsij, N, Filename);

  for (a = 0 ; a < Nsec ; a++)
  {
    t = Times[a].t21x;
    Bin = (int)floor(t/dt) - (int)floor(ts/dt);
    if (Bin < 0 || Bin > N-2) 
      KILL("Requested array access is out of bounds.\n");

    DT = t - dt*floor(t/dt);

    Xsig[a] -= (((nsij[Bin+1]-nsij[Bin])/dt)*DT + nsij[Bin]);

  }


 /* Phi31 */

  sprintf(Filename, "Binary/ShotNoise31_%i.dat", Section);
  FileRead(nsij, N, Filename);

  for (a = 0 ; a < Nsec ; a++)
  {
    t = Times[a].t12;
    Bin = (int)floor(t/dt) - (int)floor(ts/dt);
    if (Bin < 0 || Bin > N-2) 
      KILL("Requested array access is out of bounds.\n");

    DT = t - dt*floor(t/dt);

    Xsig[a] += (((nsij[Bin+1]-nsij[Bin])/dt)*DT + nsij[Bin]);

  }


 /* Phi13 */

  sprintf(Filename, "Binary/ShotNoise13_%i.dat", Section);
  FileRead(nsij, N, Filename);

  for (a = 0 ; a < Nsec ; a++)
  {
    t = Times[a].t31x;
    Bin = (int)floor(t/dt) - (int)floor(ts/dt);
    if (Bin < 0 || Bin > N-2) 
      KILL("Requested array access is out of bounds.\n");

    DT = t - dt*floor(t/dt);

    Xsig[a] += (((nsij[Bin+1]-nsij[Bin])/dt)*DT + nsij[Bin]);

  }


 /* Free the allocated memory */

  free(nsij);


  return;
}





void MichelsonAccNoise(struct Time* Times, double* Mike, double ts, long Nsec, 
		       long N, int Section)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Emmission and reception times */
  double ti, tj;

 /* Time bins that contain the emission and reception times */
  long Bin_i, Bin_j;

 /* Interpolated unit vector component needed for dot product */
  double rij;

 /* Filename character array */
  char Filename[50];

 /* Acceleration noise in the time domain */
  double* na12;
  double* na21;
  double* na13;
  double* na31;

  double DTj, DTi;

 /* Loop index */
  long a;


          /* -------------------  CALCULATIONS  ------------------- */

 /* Phi12 and Phi21 */

     /* Dynamically allocate the memory for a component of the acceleration
	noise */

  na12 = (double*) malloc (N*sizeof(double));
  na21 = (double*) malloc (N*sizeof(double));

  if (!na12 || !na21) KILL("Out of memory!\n");


     /* Import the component of the acceleration noise in Phi12 and Phi21 */

  sprintf(Filename, "Binary/AccNoise12_%i.dat", Section);
  FileRead(na12, N, Filename);

  sprintf(Filename, "Binary/AccNoise21_%i.dat", Section);
  FileRead(na21, N, Filename);


     /* Phi21 acceleration noise */

  for (a = 0 ; a < Nsec ; a++)
  {
    tj = Times[a].t1;
    Bin_j = (int)floor(tj/dt) - (int)floor(ts/dt);
    if (Bin_j < 0 || Bin_j > N-2) 
      KILL("Requested array access is out of bounds.\n");

    ti = Times[a].t21;
    Bin_i = (int)floor(ti/dt) - (int)floor(ts/dt);
    if (Bin_i < 0 || Bin_i > N-2) 
      KILL("Requested array access is out of bounds.\n");

    DTi = ti - dt*floor(ti/dt);
    DTj = tj - dt*floor(tj/dt);

    Mike[a] += -(((na21[Bin_j+1]-na21[Bin_j])/dt)*DTj + na21[Bin_j])
              -(((na12[Bin_i+1]-na12[Bin_i])/dt)*DTi + na12[Bin_i]);

  }


     /* Phi12 acceleration noise */

  for (a = 0 ; a < Nsec ; a++)
  {
    tj = Times[a].t21;
    Bin_j = (int)floor(tj/dt) - (int)floor(ts/dt);
    if (Bin_j < 0 || Bin_j > N-2) 
      KILL("Requested array access is out of bounds.\n");

    ti = Times[a].t12;
    Bin_i = (int)floor(ti/dt) - (int)floor(ts/dt);
    if (Bin_i < 0 || Bin_i > N-2) 
      KILL("Requqested array access is out of bounds.\n");

    DTi = ti - dt*floor(ti/dt);
    DTj = tj - dt*floor(tj/dt);

    Mike[a] += -(((na12[Bin_j+1]-na12[Bin_j])/dt)*DTj + na12[Bin_j])
              -(((na21[Bin_i+1]-na21[Bin_i])/dt)*DTi + na21[Bin_i]);

  }


 /* Free the allocated memory */

  free(na12);
  free(na21);


 /* Phi13 and Phi31 */

     /* Dynamically allocate the memory for a component of the acceleration
	noise */

  na13 = (double*) malloc (N*sizeof(double));
  na31 = (double*) malloc (N*sizeof(double));

  if (!na13 || !na31) KILL("Out of memory!\n");


     /* Import the component of the acceleration noise in Phi13 and Phi31 */

  sprintf(Filename, "Binary/AccNoise13_%i.dat", Section);
  FileRead(na13, N, Filename);

  sprintf(Filename, "Binary/AccNoise31_%i.dat", Section);
  FileRead(na31, N, Filename);


     /* Phi31 acceleration noise */

  for (a = 0 ; a < Nsec ; a++)
  {

    tj = Times[a].t1;
    Bin_j = (int)floor(tj/dt) - (int)floor(ts/dt);
    if (Bin_j < 0 || Bin_j > N-2) 
      KILL("Requested array access is out of bounds.\n");

    ti = Times[a].t31;
    Bin_i = (int)floor(ti/dt) - (int)floor(ts/dt);
    if (Bin_i < 0 || Bin_i > N-2) 
      KILL("Requested array access is out of bounds.\n");

    DTi = ti - dt*floor(ti/dt);
    DTj = tj - dt*floor(tj/dt);

    Mike[a] += +(((na31[Bin_j+1]-na31[Bin_j])/dt)*DTj + na31[Bin_j])
              +(((na13[Bin_i+1]-na13[Bin_i])/dt)*DTi + na13[Bin_i]);

  }


     /* Phi13 acceleration noise */

  for (a = 0 ; a < Nsec ; a++)
  {
    tj = Times[a].t31;
    Bin_j = (int)floor(tj/dt) - (int)floor(ts/dt);
    if (Bin_j < 0 || Bin_j > N-2) 
      KILL("Requested array access is out of bounds.\n");

    ti = Times[a].t13;
    Bin_i = (int)floor(ti/dt) - (int)floor(ts/dt);
    if (Bin_i < 0 || Bin_i > N-2) 
      KILL("Requested array access is out of bounds.\n");

    DTi = ti - dt*floor(ti/dt);
    DTj = tj - dt*floor(tj/dt);

    Mike[a] += (((na13[Bin_j+1]-na13[Bin_j])/dt)*DTj + na13[Bin_j])
              +(((na31[Bin_i+1]-na31[Bin_i])/dt)*DTi + na31[Bin_i]);

  }


 /* Free the allocated memory */

  free(na13);
  free(na31);


  return;
}





void TDIAccNoise(struct Time* Times, double* Xsig, double ts, long Nsec, 
		 long N, int Section)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Emmission and reception times */
  double ti, tj;

 /* Time bins that contain the emission and reception times */
  long Bin_i, Bin_j;

 /* Interpolated unit vector component needed for dot product */
  double rij;

 /* Filename character array */
  char Filename[50];

 /* Acceleration noise in the time domain */
  double* na12;
  double* na21;
  double* na13;
  double* na31;

  double DTi, DTj;

 /* Loop index */
  long a;


          /* -------------------  CALCULATIONS  ------------------- */

 /* Phi12 and Phi21 */

     /* Dynamically allocate the memory for a component of the acceleration
	noise */

  na12 = (double*) malloc (N*sizeof(double));
  na21 = (double*) malloc (N*sizeof(double));

  if (!na12 || !na21) KILL("Out of memory!\n");


     /* Import the component of the acceleration noise in Phi12 and Phi21 */

  sprintf(Filename, "Binary/AccNoise12_%i.dat", Section);
  FileRead(na12, N, Filename);

  sprintf(Filename, "Binary/AccNoise21_%i.dat", Section);
  FileRead(na21, N, Filename);


     /* Phi21 acceleration noise */

  for (a = 0 ; a < Nsec ; a++)
  {
    tj = Times[a].t13;
    Bin_j = (int)floor(tj/dt) - (int)floor(ts/dt);
    if (Bin_j < 0 || Bin_j > N-2) 
      KILL("Requested array access is out of bounds.\n");

    ti = Times[a].t21x;
    Bin_i = (int)floor(ti/dt) - (int)floor(ts/dt);
    if (Bin_i < 0 || Bin_i > N-2) 
      KILL("Requestes array access is out of bounds.\n");

    DTi = ti - dt*floor(ti/dt);
    DTj = tj - dt*floor(tj/dt);

    Xsig[a] += +(((na21[Bin_j+1]-na21[Bin_j])/dt)*DTj + na21[Bin_j])
               +(((na12[Bin_i+1]-na12[Bin_i])/dt)*DTi + na12[Bin_i]);

  }


     /* Phi12 acceleration noise */

  for (a = 0 ; a < Nsec ; a++)
  {
    tj = Times[a].t21x;
    Bin_j = (int)floor(tj/dt) - (int)floor(ts/dt);
    if (Bin_j < 0 || Bin_j > N-2) 
      KILL("Requested array access is out of bounds.\n");

    ti = Times[a].t12x;
    Bin_i = (int)floor(ti/dt) - (int)floor(ts/dt);
    if (Bin_i < 0 || Bin_i > N-2) 
      KILL("Requqested array access is out of bounds.\n");

    DTi = ti - dt*floor(ti/dt);
    DTj = tj - dt*floor(tj/dt);

    Xsig[a] += (((na12[Bin_j+1]-na12[Bin_j])/dt)*DTj + na12[Bin_j])
               +(((na21[Bin_i+1]-na21[Bin_i])/dt)*DTi + na21[Bin_i]);

  }


 /* Free the allocated memory */

  free(na12);
  free(na21);


 /* Phi13 and Phi31 */

     /* Dynamically allocate the memory for a component of the acceleration
	noise */

  na13 = (double*) malloc (N*sizeof(double));
  na31 = (double*) malloc (N*sizeof(double));

  if (!na13 || !na31) KILL("Out of memory!\n");


     /* Import the component of the acceleration noise in Phi13 and Phi31 */

  sprintf(Filename, "Binary/AccNoise13_%i.dat", Section);
  FileRead(na13, N, Filename);

  sprintf(Filename, "Binary/AccNoise31_%i.dat", Section);
  FileRead(na31, N, Filename);


     /* Phi31 acceleration noise */

  for (a = 0 ; a < Nsec ; a++)
  {
    tj = Times[a].t12;
    Bin_j = (int)floor(tj/dt) - (int)floor(ts/dt);
    if (Bin_j < 0 || Bin_j > N-2) 
      KILL("Requested array access is out of bounds.\n");

    ti = Times[a].t31x;
    Bin_i = (int)floor(ti/dt) - (int)floor(ts/dt);
    if (Bin_i < 0 || Bin_i > N-2) 
      KILL("Requested array access is out of bounds.\n");

    DTi = ti - dt*floor(ti/dt);
    DTj = tj - dt*floor(tj/dt);

    Xsig[a] += -(((na31[Bin_j+1]-na31[Bin_j])/dt)*DTj + na31[Bin_j])
               -(((na13[Bin_i+1]-na13[Bin_i])/dt)*DTi + na13[Bin_i]);

  }


     /* Phi13 acceleration noise */

  for (a = 0 ; a < Nsec ; a++)
  {
    tj = Times[a].t31x;
    Bin_j = (int)floor(tj/dt) - (int)floor(ts/dt);
    if (Bin_j < 0 || Bin_j > N-2) 
      KILL("Requested array access is out of bounds.\n");

    ti = Times[a].t13x;
    Bin_i = (int)floor(ti/dt) - (int)floor(ts/dt);
    if (Bin_i < 0 || Bin_i > N-2) 
      KILL("Requested array access is out of bounds.\n");

    DTi = ti - dt*floor(ti/dt);
    DTj = tj - dt*floor(tj/dt);

    Xsig[a] += -(((na13[Bin_j+1]-na13[Bin_j])/dt)*DTj + na13[Bin_j])
               -(((na31[Bin_i+1]-na31[Bin_i])/dt)*DTi + na31[Bin_i]);

  }


 /* Free the allocated memory */

  free(na13);
  free(na31);


  return;
}





void VertexTimes(struct Time* Times, long Nsec, char* Filename)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Error message character array */
  char ErrorMessage[100];

 /* Loop index */
  int a;

 /* File pointer */
  FILE* TimeIn;


          /* -------------------  CALCULATIONS  ------------------- */

 /* Open a binary formatted file */

  if ((TimeIn = fopen(Filename, "rb")) == NULL)
  {
    sprintf(ErrorMessage, "Cannot open the file %s.\n", Filename);
    KILL(ErrorMessage);
  }


 /* Read in the file */

  for (a = 0 ; a < Nsec ; a++)
    fread(&Times[a], sizeof(struct Time), 1, TimeIn);


 /* Close the file */

  fclose(TimeIn);


  return;
}





void FileRead(double* n_ij, long N, char* Filename)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Error message character array */
  char ErrorMessage[100];

 /* Loop index */
  long a;

 /* File pointer */
  FILE* NoiseIn;


          /* -------------------  CALCULATIONS  ------------------- */

 /* Open a binary formatted file */

  if ((NoiseIn = fopen(Filename, "rb")) == NULL)
  {
    sprintf(ErrorMessage, "Cannot open the file %s.\n", Filename);
    KILL(ErrorMessage);
  }


 /* Read in the file */

  for (a = 0 ; a < N ; a++) fread(&n_ij[a], sizeof(double), 1, NoiseIn);


 /* Close the file */

  fclose(NoiseIn);


  return;
}






void FileWrite(double* TDS, long Nsec, char* Filename)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Error message character array */
  char ErrorMessage[100];

 /* Loop index */
  int a;

 /* File pointer */
  FILE* NoiseOut;


          /* -------------------  CALCULATIONS  ------------------- */

 /* Open a binary formatted file */

  if ((NoiseOut = fopen(Filename, "ab")) == NULL)
  {
    sprintf(ErrorMessage, "Cannot open the file %s.\n", Filename);
    KILL(ErrorMessage);
  }


 /* Write to file in binary format */

  for (a = 0 ; a < Nsec ; a++) fwrite(&TDS[a], sizeof(double), 1, NoiseOut);


 /* Close the file */

  fclose(NoiseOut);


  return;
}





void KILL(char* Message)
{
  printf("\a\n");
  printf(Message);
  printf("Terminating the program.\n\n");
  exit(1);

 
  return;
}
