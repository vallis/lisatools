#------------------------------------------------------------------------------
# Copyright (c) 2005, Enthought, Inc.
# All rights reserved.
# 
# This software is provided without warranty under the terms of the BSD
# license included in enthought/LICENSE.txt and may be redistributed only
# under the conditions described in the aforementioned license.  The license
# is also available online at http://www.enthought.com/licenses/BSD.txt
# Thanks for using Enthought open source!
# 
# Author: Enthought, Inc.
# Description: <Enthought util package component>
#------------------------------------------------------------------------------
""" A normal (Gaussian) distribution. """


# Major package imports.
from scipy import arange, clip, stats, zeros

# Enthought library imports.
from enthought.traits import Trait, TraitGroup, TraitRange

# Local imports.
from distribution import Distribution


class Gaussian(Distribution):
    """ A normal (Gaussian) distribution. """


    # todo - these are no longer required????? 
    __editable_traitsXXX__ = TraitGroup('mean', 'std', style='text')


    def __init__(self, mean, std, low_bound, high_bound):
        """ Creates a new Gaussian distribution. """

        # Base-class constructor.
        Distribution.__init__(self, low_bound, high_bound)

        # Dynamic traits.
        mean_trait = Trait(mean, TraitRange(low_bound, high_bound))
        self.add_trait('mean', mean_trait)

        std_trait = Trait(std, TraitRange(0.0, high_bound - low_bound))
        self.add_trait('std',  std_trait)

        # Initialize dynamic traits.
        self.mean = mean
        self.std  = std

        # fixme: Hmmm, so the 'model' knows about its colour!
        self.fill_color = (255.0/255.0, 251.0/255.0, 164.0/255.0, 0.6)

        return

    ###########################################################################
    # 'Distribution' interface.
    ###########################################################################
        
    def clone(self):
        """ Returns a clone of the distribution. """

        clone = Gaussian(self.low_bound, self.high_bound)
        clone.set(mean=self.mean, std=self.std)

        return clone

    def generate(self, n=1):
        """ Generates 'n' values in the distribution. """
        
        # workaround for a bug in stats.norm where a sd = 0.0 throws an 
        # exception
        
        if self.std <= 0:
            values = zeros(n) + self.mean
        else:
            values = stats.norm(self.mean, self.std, size=n)
        
        values = clip(self.low_bound, self.high_bound)

        return values

    def plot_value(self):
        """ Returns a plot value representing the distribution. """
        
        from enthought.chaco.plot_value import PlotValue
        
        delta = 3.0 * self.std
        x     = arange(self.mean - delta, self.mean + delta, delta / 50.0)

        plot_value = PlotValue(
            stats.norm.pdf(x, self.mean, self.std),
            index      = PlotValue(x),
            type       = 'stackedline',
            fill_color = self.fill_color
        )

        return plot_value

#### EOF ######################################################################
