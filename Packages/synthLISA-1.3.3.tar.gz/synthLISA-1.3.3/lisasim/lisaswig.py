# This file was created automatically by SWIG 1.3.29.
# Don't modify this file, modify the SWIG interface instead.
# This file is compatible with both classic and new-style classes.

import _lisaswig
import new
new_instancemethod = new.instancemethod
def _swig_setattr_nondynamic(self,class_type,name,value,static=1):
    if (name == "thisown"): return self.this.own(value)
    if (name == "this"):
        if type(value).__name__ == 'PySwigObject':
            self.__dict__[name] = value
            return
    method = class_type.__swig_setmethods__.get(name,None)
    if method: return method(self,value)
    if (not static) or hasattr(self,name):
        self.__dict__[name] = value
    else:
        raise AttributeError("You cannot add attributes to %s" % self)

def _swig_setattr(self,class_type,name,value):
    return _swig_setattr_nondynamic(self,class_type,name,value,0)

def _swig_getattr(self,class_type,name):
    if (name == "thisown"): return self.this.own()
    method = class_type.__swig_getmethods__.get(name,None)
    if method: return method(self)
    raise AttributeError,name

def _swig_repr(self):
    try: strthis = "proxy of " + self.this.__repr__()
    except: strthis = ""
    return "<%s.%s; %s >" % (self.__class__.__module__, self.__class__.__name__, strthis,)

import types
try:
    _object = types.ObjectType
    _newclass = 1
except AttributeError:
    class _object : pass
    _newclass = 0
del types


import numpy.oldnumeric as Numeric

import math
import sys
import random
import time

globalseed = 0

cseeds = []

def setglobalseed(seed = 0):
    globalseed = seed
    random.seed(globalseed)
   
def getglobalseed():
    if globalseed == 0:
        setglobalseed(int(time.time()))

    return globalseed
    
def getcseed():
    if globalseed == 0:
        setglobalseed(int(time.time()))

    while True:
        ret = random.randint(0,2**32)
    
        if not ret in cseeds:
            cseeds.append(ret)
            return ret

class LISA(_object):
    """
    LISA is the base class for all LISA geometries. All derived LISA
    classes must define putn(l,t), putp(i,t), and armlength(l,t). LISA,
    and most of its derived classes, are defined in lisasim-lisa.cpp
    """
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, LISA, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, LISA, name)
    def __init__(self): raise AttributeError, "No constructor defined"
    __repr__ = _swig_repr
    def putp(*args):
        """
        LISA.putp(i,t) -> (pix,piy,piz) returns a 3-tuple with the SSB
        coordinates of spacecraft i (1,2,3) at time t [s].
        """
        return _lisaswig.LISA_putp(*args)

    def putn(*args):
        """
        LISA.putn(l,t) -> (nlx,nly,nlz) returns a 3-tuple with the SSB
        components (normalized) of arm l (1,2,3,-1,-2,-3) at time t [s].
        """
        return _lisaswig.LISA_putn(*args)

    def putv(*args):
        """
        LISA.putv(i,t) -> (vix,viy,viz) returns a 3-tuple with the SSB
        coordinate speed of spacecraft i (1,2,3) at time t [s], given
        in units of the speed of light.
        """
        return _lisaswig.LISA_putv(*args)

    def armlength(*args):
        """
        LISA.armlength(l,t) the armlength [s] of LISA link l (1,2,3,-1,-2,-3)
        for laser pulse reception at time t [s].
        """
        return _lisaswig.LISA_armlength(*args)

    def dotarmlength(*args):
        """
        LISA.armlength(l,t) the instantaneous rate of change of the armlength
        of LISA link l (1,2,3,-1,-2,-3) for laser pulse reception a time t [s],
        given in units of the speed of light.
        """
        return _lisaswig.LISA_dotarmlength(*args)

    def reset(*args):
        """
        LISA.reset() resets any underlying pseudo-random or ring-buffer
        elements used by the LISA object.
        """
        return _lisaswig.LISA_reset(*args)

LISA_swigregister = _lisaswig.LISA_swigregister
LISA_swigregister(LISA)

class OriginalLISA(LISA):
    """
    OriginalLISA(L1,L2,L3) returns a static LISA object with armlengths
    given by L1, L2, L3 (in seconds). If omitted, the Li take the standard
    value Lstd.

    The positions of the spacecraft are chosen so that 1) the baricenter
    is in the SSB origin; 2) piz = 0 for all spacecraft; 3) the spacecraft
    sequence 1 -> 2 -> 3 -> 1 traces a clockwise path, as seen from above;
    p1y = 0.
    """
    __swig_setmethods__ = {}
    for _s in [LISA]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, OriginalLISA, name, value)
    __swig_getmethods__ = {}
    for _s in [LISA]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, OriginalLISA, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        """
        Constructor. See above.

        """
        this = _lisaswig.new_OriginalLISA(*args)
        try: self.this.append(this)
        except: self.this = this
        
        self.initargs = args


    __swig_destroy__ = _lisaswig.delete_OriginalLISA
    __del__ = lambda self : None;
OriginalLISA_swigregister = _lisaswig.OriginalLISA_swigregister
OriginalLISA_swigregister(OriginalLISA)

class ModifiedLISA(OriginalLISA):
    """
    ModifiedLISA(L1,L2,L3) returns a stationary LISA object set equal to
    OriginalLISA(L1,L2,L3) at time 0, but rotating around its baricenter
    (at the SSB origin) with angular speed 2*pi/yr. L1, L2, L3 are given
    in seconds; if omitted, they take the standard value Lstd.

    Because of the rotation, the armlengths depend on the
    direction of light propagation.
    """
    __swig_setmethods__ = {}
    for _s in [OriginalLISA]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, ModifiedLISA, name, value)
    __swig_getmethods__ = {}
    for _s in [OriginalLISA]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, ModifiedLISA, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        """
        Constructor. See above.

        """
        this = _lisaswig.new_ModifiedLISA(*args)
        try: self.this.append(this)
        except: self.this = this
        
        self.initargs = args


    __swig_destroy__ = _lisaswig.delete_ModifiedLISA
    __del__ = lambda self : None;
ModifiedLISA_swigregister = _lisaswig.ModifiedLISA_swigregister
ModifiedLISA_swigregister(ModifiedLISA)

class ApproxLISA(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, ApproxLISA, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, ApproxLISA, name)
    def __init__(self): raise AttributeError, "No constructor defined"
    __repr__ = _swig_repr
    def geteta0(*args): return _lisaswig.ApproxLISA_geteta0(*args)
    def getxi0(*args): return _lisaswig.ApproxLISA_getxi0(*args)
    def getsw(*args): return _lisaswig.ApproxLISA_getsw(*args)
ApproxLISA_swigregister = _lisaswig.ApproxLISA_swigregister
ApproxLISA_swigregister(ApproxLISA)

class CircularRotating(LISA,ApproxLISA):
    """
    CircularRotating(eta0=0,xi0=0,sw=1,t0=0) and
    CircularRotating(myL,eta0,xi0,sw,t0) return rigid LISA objects where
    the armlengths are equal and constant before aberration is taken into
    account. The parameters eta0 and xi0 are the true anomaly of the LISA
    guiding center and the initial phase of the LISA array at t=t0; sw<0
    will swap spacecraft 2 and 3, so that the spacecraft sequence 1 -> 2
    -> 3 -> 1 goes ccw as seen from above. If given (in which case all
    parameters must be specified), myL is the common armlength; if not
    given, it is set to Lstd.

    CircularRotating() is legal and replaces stdlisa(). The LISA
    baricenter moves on a circular orbit in the ecliptic, while the
    constellation rotates around the guiding center with the same angular
    velocity. The orbits follow Krolak et al, PRD 70, 022003 (2004).
    """
    __swig_setmethods__ = {}
    for _s in [LISA,ApproxLISA]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, CircularRotating, name, value)
    __swig_getmethods__ = {}
    for _s in [LISA,ApproxLISA]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, CircularRotating, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        """
        Constructor. See above.

        """
        this = _lisaswig.new_CircularRotating(*args)
        try: self.this.append(this)
        except: self.this = this
        
        self.initargs = args


    __swig_destroy__ = _lisaswig.delete_CircularRotating
    __del__ = lambda self : None;
CircularRotating_swigregister = _lisaswig.CircularRotating_swigregister
CircularRotating_swigregister(CircularRotating)

class EccentricInclined(LISA,ApproxLISA):
    """
    EccentricInclined(eta0=0,xi0=0,sw=1,t0=0) returns a realistic LISA
    geometry modeled up to second order in the eccentricity, following
    Cornish and Rubbo, PRD 67, 022001 (2003), but with the approximate
    parametrization of CircularRotating (eta0 and xi0 true anomaly of
    baricenter and array phase at t0=0; sw<0 swaps spacecraft).
    """
    __swig_setmethods__ = {}
    for _s in [LISA,ApproxLISA]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, EccentricInclined, name, value)
    __swig_getmethods__ = {}
    for _s in [LISA,ApproxLISA]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, EccentricInclined, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        """
        Constructor. See above.

        """
        this = _lisaswig.new_EccentricInclined(*args)
        try: self.this.append(this)
        except: self.this = this
        
        self.initargs = args


    def genarmlength(*args): return _lisaswig.EccentricInclined_genarmlength(*args)
    __swig_destroy__ = _lisaswig.delete_EccentricInclined
    __del__ = lambda self : None;
EccentricInclined_swigregister = _lisaswig.EccentricInclined_swigregister
EccentricInclined_swigregister(EccentricInclined)

class ZeroLISA(LISA):
    __swig_setmethods__ = {}
    for _s in [LISA]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, ZeroLISA, name, value)
    __swig_getmethods__ = {}
    for _s in [LISA]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, ZeroLISA, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _lisaswig.new_ZeroLISA(*args)
        try: self.this.append(this)
        except: self.this = this
    __swig_destroy__ = _lisaswig.delete_ZeroLISA
    __del__ = lambda self : None;
ZeroLISA_swigregister = _lisaswig.ZeroLISA_swigregister
ZeroLISA_swigregister(ZeroLISA)

class PyLISA(LISA):
    """
    PyLISA(baseLISA,Func) returns a LISA object with physical geometry
    (used for light propagation and GW and noise responses) given by the
    LISA object baseLISA, but with nominal armlengths (as used for the TDI
    delays) given by the Python function Func(i,t) (i=1,2,3,-1,-2,-3, time
    in seconds).

    PyLISA attempts to provide a more general (if less efficient)
    mechanism for the nominal-armlength computations previously performed
    with NoisyLISA, NominalLISA, LinearLISA, MeasureLISA (all
    experimental and now removed from the main distribution).
    """
    __swig_setmethods__ = {}
    for _s in [LISA]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, PyLISA, name, value)
    __swig_getmethods__ = {}
    for _s in [LISA]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, PyLISA, name)
    __repr__ = _swig_repr
    __swig_setmethods__["baseLISA"] = _lisaswig.PyLISA_baseLISA_set
    __swig_getmethods__["baseLISA"] = _lisaswig.PyLISA_baseLISA_get
    if _newclass:baseLISA = property(_lisaswig.PyLISA_baseLISA_get, _lisaswig.PyLISA_baseLISA_set)
    def __init__(self, *args): 
        """
        Constructor. See above.

        """
        this = _lisaswig.new_PyLISA(*args)
        try: self.this.append(this)
        except: self.this = this
        
        self.initargs = args


    __swig_destroy__ = _lisaswig.delete_PyLISA
    __del__ = lambda self : None;
PyLISA_swigregister = _lisaswig.PyLISA_swigregister
PyLISA_swigregister(PyLISA)

class AllPyLISA(LISA):
    """
    AllPyLISA(putpfunc,armlengthfunc = 0)

    returns a LISA object that takes the positions of spacecraft from
    the Python function putpfunc(craft,time), where craft = 1,2,3, and
    time is given in seconds; and that takes the armlengths from the
    Python function armlengthfunc(link,time), where link = 1,2,3,-1,-2,-3.
    If armlengthfunc is not given, the armlengths will be determined from
    the s/c positions using the exact light-propagation equation (solved
    in the base LISA class).

    Note: simulations that use AllPyLISA can be speeded up somewhat by
    enclosing the AllPyLISA object in a CacheLengthLISA object.
    """
    __swig_setmethods__ = {}
    for _s in [LISA]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, AllPyLISA, name, value)
    __swig_getmethods__ = {}
    for _s in [LISA]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, AllPyLISA, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        """
        Constructor. See above.

        """
        this = _lisaswig.new_AllPyLISA(*args)
        try: self.this.append(this)
        except: self.this = this
        
        self.initargs = args


    __swig_destroy__ = _lisaswig.delete_AllPyLISA
    __del__ = lambda self : None;
AllPyLISA_swigregister = _lisaswig.AllPyLISA_swigregister
AllPyLISA_swigregister(AllPyLISA)

class CacheLISA(LISA):
    """
    CacheLISA(baseLISA)
    returns a LISA object that works by routing all putp-putn calls to the
    baseLISA object, passed on construction. It will however interpose a
    layer of its own making for retard() calls, effectively caching
    chained retardations for the most recently accessed time.

    CacheLISA, defined in lisasim-retard.h, might improve performance for
    complicated (or multiple) TDI-variable evaluations, especially when
    performed in conjunction with PyLISA.
    """
    __swig_setmethods__ = {}
    for _s in [LISA]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, CacheLISA, name, value)
    __swig_getmethods__ = {}
    for _s in [LISA]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, CacheLISA, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        """
        Constructor. See above.

        """
        this = _lisaswig.new_CacheLISA(*args)
        try: self.this.append(this)
        except: self.this = this
        
        self.initargs = args


    __swig_destroy__ = _lisaswig.delete_CacheLISA
    __del__ = lambda self : None;
CacheLISA_swigregister = _lisaswig.CacheLISA_swigregister
CacheLISA_swigregister(CacheLISA)

class SampledLISA(LISA):
    """
    SampledLISA(p1,p2,p3,deltat,prebuffer,interp)
    returns a LISA object that takes the positions of its spacecraft from
    the 2-dimensional Numeric arrays p1, p2, p3; each of these consists of
    three columns that give the SSB coordinates of corresponding LISA
    spacecraft.

    The array data is understood to be spaced by intervals deltat [s], and
    it is offset so that (for instance)

    p1x(t) = p1[(t - prebuffer)/deltat,0],
    p1y(t) = p1[(t - prebuffer)/deltat,1],
    p1z(t) = p1[(t - prebuffer)/deltat,2].
      
    Last, interp (> 1) sets the semiwidth of the data window used in
    Lagrange interpolation of the positions.

    Note 1: SampledLISA makes copies of the positions arrays, so these can
    be safely destroyed after calling the SampledLISA constructor; on the
    other hand, modifying the arrays passed to the constructor will have no
    effect on the positions returned by SampledLISA.putp().

    Note 2: currently armlength are computed explicitly by SampledLISA by
    solving the backward light propagation equation.
    """
    __swig_setmethods__ = {}
    for _s in [LISA]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, SampledLISA, name, value)
    __swig_getmethods__ = {}
    for _s in [LISA]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, SampledLISA, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        """
        Constructor. See above.

        """
        this = _lisaswig.new_SampledLISA(*args)
        try: self.this.append(this)
        except: self.this = this
    __swig_destroy__ = _lisaswig.delete_SampledLISA
    __del__ = lambda self : None;
SampledLISA_swigregister = _lisaswig.SampledLISA_swigregister
SampledLISA_swigregister(SampledLISA)

class CacheLengthLISA(LISA):
    """
    CacheLengthLISA(baseLISA,bufferlength,deltat,interplen = 1)
    returns a LISA object that caches and interpolates armlengths found by
    solving the light-propagation equation for the spacecraft positions
    returned by baseLISA.putp(). The light-propagation equation is solved
    every deltat seconds, and results remain available in a time window of
    duration bufferlength*deltat. Last, interplen is the semiwidth of the
    interpolation kernel (with 0 nearest-neighbor interpolation and 1 linear
    interpolation).

    Note: the current implementation does not support changing the physical
    LISA of baseLISA on the fly, and is untested for different nominal and
    physical LISAs.
    """
    __swig_setmethods__ = {}
    for _s in [LISA]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, CacheLengthLISA, name, value)
    __swig_getmethods__ = {}
    for _s in [LISA]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, CacheLengthLISA, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        """
        Constructor. See above.

        """
        this = _lisaswig.new_CacheLengthLISA(*args)
        try: self.this.append(this)
        except: self.this = this
        
        self.initargs = args


    __swig_destroy__ = _lisaswig.delete_CacheLengthLISA
    __del__ = lambda self : None;
CacheLengthLISA_swigregister = _lisaswig.CacheLengthLISA_swigregister
CacheLengthLISA_swigregister(CacheLengthLISA)

retardation = _lisaswig.retardation
class SignalSource(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, SignalSource, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, SignalSource, name)
    def __init__(self): raise AttributeError, "No constructor defined"
    __repr__ = _swig_repr
    def reset(*args): return _lisaswig.SignalSource_reset(*args)
    def __getitem__(*args): return _lisaswig.SignalSource___getitem__(*args)
SignalSource_swigregister = _lisaswig.SignalSource_swigregister
SignalSource_swigregister(SignalSource)

class WhiteNoiseSource(SignalSource):
    __swig_setmethods__ = {}
    for _s in [SignalSource]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, WhiteNoiseSource, name, value)
    __swig_getmethods__ = {}
    for _s in [SignalSource]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, WhiteNoiseSource, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _lisaswig.new_WhiteNoiseSource(*args)
        try: self.this.append(this)
        except: self.this = this
    def setglobalseed(*args):
        """
        WhiteNoiseSource.setglobalseed(seed) sets the global seed that will be
        used to initialize the next pseudorandom-number generator to be created
        or reset. The argument should be an unsigned long integer. The global
        seed is increased by one after each creation or initialization. This is
        a class (static) method. 
        """
        return _lisaswig.WhiteNoiseSource_setglobalseed(*args)

    if _newclass:setglobalseed = staticmethod(setglobalseed)
    __swig_getmethods__["setglobalseed"] = lambda x: setglobalseed
    def getglobalseed(*args):
        """
        WhiteNoiseSource.getglobalseed() returns the global seed that will be
        used to initialize the next pseudorandom-number generator to be created
        or reset. The seed is an unsigned long integer. The global seed is
        increased by one after each creation or initialization. This is a class
        (static) method. 
        """
        return _lisaswig.WhiteNoiseSource_getglobalseed(*args)

    if _newclass:getglobalseed = staticmethod(getglobalseed)
    __swig_getmethods__["getglobalseed"] = lambda x: getglobalseed
    __swig_destroy__ = _lisaswig.delete_WhiteNoiseSource
    __del__ = lambda self : None;
WhiteNoiseSource_swigregister = _lisaswig.WhiteNoiseSource_swigregister
WhiteNoiseSource_swigregister(WhiteNoiseSource)

def WhiteNoiseSource_setglobalseed(*args):
  """
    WhiteNoiseSource.setglobalseed(seed) sets the global seed that will be
    used to initialize the next pseudorandom-number generator to be created
    or reset. The argument should be an unsigned long integer. The global
    seed is increased by one after each creation or initialization. This is
    a class (static) method. 
    """
  return _lisaswig.WhiteNoiseSource_setglobalseed(*args)

def WhiteNoiseSource_getglobalseed(*args):
  """
    WhiteNoiseSource.getglobalseed() returns the global seed that will be
    used to initialize the next pseudorandom-number generator to be created
    or reset. The seed is an unsigned long integer. The global seed is
    increased by one after each creation or initialization. This is a class
    (static) method. 
    """
  return _lisaswig.WhiteNoiseSource_getglobalseed(*args)

class SampledSignalSource(SignalSource):
    __swig_setmethods__ = {}
    for _s in [SignalSource]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, SampledSignalSource, name, value)
    __swig_getmethods__ = {}
    for _s in [SignalSource]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, SampledSignalSource, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _lisaswig.new_SampledSignalSource(*args)
        try: self.this.append(this)
        except: self.this = this
        
        self.initargs = args


    __swig_destroy__ = _lisaswig.delete_SampledSignalSource
    __del__ = lambda self : None;
SampledSignalSource_swigregister = _lisaswig.SampledSignalSource_swigregister
SampledSignalSource_swigregister(SampledSignalSource)

class FileSignalSource(SignalSource):
    __swig_setmethods__ = {}
    for _s in [SignalSource]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, FileSignalSource, name, value)
    __swig_getmethods__ = {}
    for _s in [SignalSource]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, FileSignalSource, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _lisaswig.new_FileSignalSource(*args)
        try: self.this.append(this)
        except: self.this = this
    __swig_destroy__ = _lisaswig.delete_FileSignalSource
    __del__ = lambda self : None;
FileSignalSource_swigregister = _lisaswig.FileSignalSource_swigregister
FileSignalSource_swigregister(FileSignalSource)

class NoFilter(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, NoFilter, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, NoFilter, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _lisaswig.new_NoFilter(*args)
        try: self.this.append(this)
        except: self.this = this
    __swig_destroy__ = _lisaswig.delete_NoFilter
    __del__ = lambda self : None;
NoFilter_swigregister = _lisaswig.NoFilter_swigregister
NoFilter_swigregister(NoFilter)

class IntFilter(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, IntFilter, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, IntFilter, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _lisaswig.new_IntFilter(*args)
        try: self.this.append(this)
        except: self.this = this
    __swig_destroy__ = _lisaswig.delete_IntFilter
    __del__ = lambda self : None;
IntFilter_swigregister = _lisaswig.IntFilter_swigregister
IntFilter_swigregister(IntFilter)

class DiffFilter(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, DiffFilter, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, DiffFilter, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _lisaswig.new_DiffFilter(*args)
        try: self.this.append(this)
        except: self.this = this
    __swig_destroy__ = _lisaswig.delete_DiffFilter
    __del__ = lambda self : None;
DiffFilter_swigregister = _lisaswig.DiffFilter_swigregister
DiffFilter_swigregister(DiffFilter)

class FIRFilter(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, FIRFilter, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, FIRFilter, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _lisaswig.new_FIRFilter(*args)
        try: self.this.append(this)
        except: self.this = this
    __swig_destroy__ = _lisaswig.delete_FIRFilter
    __del__ = lambda self : None;
FIRFilter_swigregister = _lisaswig.FIRFilter_swigregister
FIRFilter_swigregister(FIRFilter)

class IIRFilter(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, IIRFilter, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, IIRFilter, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _lisaswig.new_IIRFilter(*args)
        try: self.this.append(this)
        except: self.this = this
    __swig_destroy__ = _lisaswig.delete_IIRFilter
    __del__ = lambda self : None;
IIRFilter_swigregister = _lisaswig.IIRFilter_swigregister
IIRFilter_swigregister(IIRFilter)

class SignalFilter(SignalSource):
    __swig_setmethods__ = {}
    for _s in [SignalSource]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, SignalFilter, name, value)
    __swig_getmethods__ = {}
    for _s in [SignalSource]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, SignalFilter, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _lisaswig.new_SignalFilter(*args)
        try: self.this.append(this)
        except: self.this = this
        
        self.initargs = args


    __swig_destroy__ = _lisaswig.delete_SignalFilter
    __del__ = lambda self : None;
SignalFilter_swigregister = _lisaswig.SignalFilter_swigregister
SignalFilter_swigregister(SignalFilter)

class Signal(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, Signal, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, Signal, name)
    def __init__(self): raise AttributeError, "No constructor defined"
    __repr__ = _swig_repr
    def reset(*args): return _lisaswig.Signal_reset(*args)
    def value(*args): return _lisaswig.Signal_value(*args)
    def __call__(*args): return _lisaswig.Signal___call__(*args)
Signal_swigregister = _lisaswig.Signal_swigregister
Signal_swigregister(Signal)

class NearestInterpolator(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, NearestInterpolator, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, NearestInterpolator, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _lisaswig.new_NearestInterpolator(*args)
        try: self.this.append(this)
        except: self.this = this
    __swig_destroy__ = _lisaswig.delete_NearestInterpolator
    __del__ = lambda self : None;
NearestInterpolator_swigregister = _lisaswig.NearestInterpolator_swigregister
NearestInterpolator_swigregister(NearestInterpolator)

class LinearInterpolator(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, LinearInterpolator, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, LinearInterpolator, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _lisaswig.new_LinearInterpolator(*args)
        try: self.this.append(this)
        except: self.this = this
    __swig_destroy__ = _lisaswig.delete_LinearInterpolator
    __del__ = lambda self : None;
LinearInterpolator_swigregister = _lisaswig.LinearInterpolator_swigregister
LinearInterpolator_swigregister(LinearInterpolator)

class LinearExtrapolator(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, LinearExtrapolator, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, LinearExtrapolator, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _lisaswig.new_LinearExtrapolator(*args)
        try: self.this.append(this)
        except: self.this = this
    __swig_destroy__ = _lisaswig.delete_LinearExtrapolator
    __del__ = lambda self : None;
LinearExtrapolator_swigregister = _lisaswig.LinearExtrapolator_swigregister
LinearExtrapolator_swigregister(LinearExtrapolator)

class LagrangeInterpolator(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, LagrangeInterpolator, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, LagrangeInterpolator, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _lisaswig.new_LagrangeInterpolator(*args)
        try: self.this.append(this)
        except: self.this = this
    __swig_destroy__ = _lisaswig.delete_LagrangeInterpolator
    __del__ = lambda self : None;
LagrangeInterpolator_swigregister = _lisaswig.LagrangeInterpolator_swigregister
LagrangeInterpolator_swigregister(LagrangeInterpolator)

class DotLagrangeInterpolator(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, DotLagrangeInterpolator, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, DotLagrangeInterpolator, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _lisaswig.new_DotLagrangeInterpolator(*args)
        try: self.this.append(this)
        except: self.this = this
    __swig_destroy__ = _lisaswig.delete_DotLagrangeInterpolator
    __del__ = lambda self : None;
DotLagrangeInterpolator_swigregister = _lisaswig.DotLagrangeInterpolator_swigregister
DotLagrangeInterpolator_swigregister(DotLagrangeInterpolator)

class NewLagrangeInterpolator(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, NewLagrangeInterpolator, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, NewLagrangeInterpolator, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _lisaswig.new_NewLagrangeInterpolator(*args)
        try: self.this.append(this)
        except: self.this = this
    __swig_destroy__ = _lisaswig.delete_NewLagrangeInterpolator
    __del__ = lambda self : None;
NewLagrangeInterpolator_swigregister = _lisaswig.NewLagrangeInterpolator_swigregister
NewLagrangeInterpolator_swigregister(NewLagrangeInterpolator)

class NoSignal(Signal):
    __swig_setmethods__ = {}
    for _s in [Signal]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, NoSignal, name, value)
    __swig_getmethods__ = {}
    for _s in [Signal]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, NoSignal, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _lisaswig.new_NoSignal(*args)
        try: self.this.append(this)
        except: self.this = this
    __swig_destroy__ = _lisaswig.delete_NoSignal
    __del__ = lambda self : None;
NoSignal_swigregister = _lisaswig.NoSignal_swigregister
NoSignal_swigregister(NoSignal)

class SumSignal(Signal):
    __swig_setmethods__ = {}
    for _s in [Signal]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, SumSignal, name, value)
    __swig_getmethods__ = {}
    for _s in [Signal]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, SumSignal, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _lisaswig.new_SumSignal(*args)
        try: self.this.append(this)
        except: self.this = this
        
        self.initargs = args


    __swig_destroy__ = _lisaswig.delete_SumSignal
    __del__ = lambda self : None;
SumSignal_swigregister = _lisaswig.SumSignal_swigregister
SumSignal_swigregister(SumSignal)

class InterpolatedSignal(Signal):
    __swig_setmethods__ = {}
    for _s in [Signal]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, InterpolatedSignal, name, value)
    __swig_getmethods__ = {}
    for _s in [Signal]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, InterpolatedSignal, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _lisaswig.new_InterpolatedSignal(*args)
        try: self.this.append(this)
        except: self.this = this
        
        self.initargs = args


    __swig_destroy__ = _lisaswig.delete_InterpolatedSignal
    __del__ = lambda self : None;
    def setinterp(*args): return _lisaswig.InterpolatedSignal_setinterp(*args)
InterpolatedSignal_swigregister = _lisaswig.InterpolatedSignal_swigregister
InterpolatedSignal_swigregister(InterpolatedSignal)

def getInterpolator(interplen=1):
    if interplen == 0:
        ret = NearestInterpolator()
    elif interplen == -1:
        ret = LinearExtrapolator()
    elif interplen == 1:
        ret = LinearInterpolator()
    elif interplen > 1:
        ret = LagrangeInterpolator(interplen)
    elif interplen < -1:
        ret = DotLagrangeInterpolator(-interplen)
    else:
        raise NotImplementedError, "getInterpolator: undefined interpolator length %s (lisasim-swig.i)." % interplen

    return ret

def getDerivativeInterpolator(interplen=2):
    if interplen > 1:
        return DotLagrangeInterpolator(interplen)
    else: 
        raise NotImplementedError, "getDerivativeInterpolator: undefined interpolator length %s (lisasim-swig.i)." % interplen

def PowerLawNoise(deltat,prebuffer,psd,exponent,interplen=1,seed=0):
    nyquistf = 0.5 / deltat

    if exponent == 0:
        filter = NoFilter()
        normalize = math.sqrt(psd) * math.sqrt(nyquistf)
    elif exponent == 2:
        filter = DiffFilter()
        normalize = math.sqrt(psd) * math.sqrt(nyquistf) / (2.00 * math.pi * deltat)
    elif exponent == -2:
        filter = IntFilter()
        normalize = math.sqrt(psd) * math.sqrt(nyquistf) * (2.00 * math.pi * deltat)
    elif exponent == -4:
        filter = IIRFilter([1,2,1],[0,0.9999*2,-0.9999])
        normalize = math.sqrt(psd) * math.sqrt(nyquistf) * (math.pi * deltat)**2
    else:
        raise NotImplementedError, "PowerLawNoise: undefined PowerLaw exponent %s (lisasim-swig.i)." % exponent

    if seed == 0:
        seed = getcseed()

    whitenoise = WhiteNoiseSource(int(prebuffer/deltat+32),seed)
    filterednoise = SignalFilter(int(prebuffer/deltat+32),whitenoise,filter)

    interp = getInterpolator(interplen)

    noise = InterpolatedSignal(filterednoise,interp,deltat,prebuffer,normalize)

    noise.xmltype = 'PowerLawNoise'
    noise.xmlargs = [deltat,prebuffer,psd,exponent,interplen,seed]

    return noise

def SampledSignal(array,deltat,buffer = 136.0,norm = 1.0,filter = None,interplen = 1,timeoffset = 0.0,endianness = -1,readbuffer=2**20):
    interp = getInterpolator(interplen)

    if isinstance(array,Numeric.ndarray):
        samplednoise = SampledSignalSource(array,norm)
    elif isinstance(array,str):
        readbuffer = max(int(buffer/deltat),int(readbuffer))

        # the endianness parameter supports the MATLAB convention,
        # as well as the XSIL descriptors

        if endianness == 'n':
            endianness = -1
        elif endianness == 'b' or endianness == 'BigEndian':
            endianness = 0
        elif endianness == 'l' or endianness == 'LittleEndian':
            endianness = 1
        
        samplednoise = FileSignalSource(array,readbuffer,int(buffer/deltat),endianness,norm)
    else:
        raise NotImplementedError, "SampledSignal: need Numeric array or filename as first argument (lisasim-swig.i)."

    if not filter:
        filteredsamples = 0
        interpolatednoise = InterpolatedSignal(samplednoise,interp,deltat,-timeoffset)
    else:
        filteredsamples = SignalFilter(int(buffer/deltat),samplednoise,filter)
        interpolatednoise = InterpolatedSignal(filteredsamples,interp,deltat,-timeoffset)

    return interpolatednoise

class CachedSignal(Signal):
    """
    CachedSignal(Signal,bufferlen,deltat,interplen = 4)

    """
    __swig_setmethods__ = {}
    for _s in [Signal]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, CachedSignal, name, value)
    __swig_getmethods__ = {}
    for _s in [Signal]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, CachedSignal, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        """
        CachedSignal(Signal,bufferlen,deltat,interplen = 4)

        """
        this = _lisaswig.new_CachedSignal(*args)
        try: self.this.append(this)
        except: self.this = this
        
        self.initargs = args


    __swig_destroy__ = _lisaswig.delete_CachedSignal
    __del__ = lambda self : None;
CachedSignal_swigregister = _lisaswig.CachedSignal_swigregister
CachedSignal_swigregister(CachedSignal)

class Wave(_object):
    """
    Wave is the base class for all GW objects; all Wave objects represent
    plane waves incoming from a definite position in the sky (as
    characterized by its SSB ecliptic latitude and longitude) with a
    definite polarization angle.

    - Wave provides putk(), which returns the GW direction of propagation,
      and putwave(t), which returns the gravitational strain tensor at
      time t at the SSB.

    - All derived Wave objects must define hp(t) and hc(t), which describe
      the time dependence of the two independent GW polarizations.

    Wave, and most of its derived classes, are defined in lisasim-wave.cpp
    """
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, Wave, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, Wave, name)
    def __init__(self): raise AttributeError, "No constructor defined"
    __repr__ = _swig_repr
    def putk(*args):
        """
        Wave.putk() -> (kx,ky,kz) returns a 3-tuple with the SSB components
        (normalized) of GW propagation vector.
        """
        return _lisaswig.Wave_putk(*args)

    def putwave(*args):
        """
        Wave.putwave(t) -> ((hxx,hxy,hxz),(hyx,hyy,hyz),(hzx,hzy,hzz)) returns
        a nested 3-tuple with the gravitational strain tensor at time t [s] at
        the SSB.
        """
        return _lisaswig.Wave_putwave(*args)

    def hp(*args):
        """
        Wave.hp(t) returns the hp polarization of the GW Wave at time t [s] at
        the SSB.
        """
        return _lisaswig.Wave_hp(*args)

    def hc(*args):
        """
        Wave.hc(t) returns the hc polarization of the GW Wave at time t [s] at
        the SSB.
        """
        return _lisaswig.Wave_hc(*args)

    def putep(*args):
        """
        Wave.putep(elat,elon,pol) returns the basic ep polarization tensor
        for a plane Wave object at ecliptic latitude elat, longitude elon,
        and polarization pol. This is a class (static) method.

        """
        return _lisaswig.Wave_putep(*args)

    if _newclass:putep = staticmethod(putep)
    __swig_getmethods__["putep"] = lambda x: putep
    def putec(*args):
        """
        Wave.putec(elat,elon,pol) returns the basic ec polarization tensor
        for a plane Wave object at ecliptic latitude elat, longitude elon,
        and polarization pol. This is a class (static) method.

        """
        return _lisaswig.Wave_putec(*args)

    if _newclass:putec = staticmethod(putec)
    __swig_getmethods__["putec"] = lambda x: putec
Wave_swigregister = _lisaswig.Wave_swigregister
Wave_swigregister(Wave)

def Wave_putep(*args):
  """
    Wave.putep(elat,elon,pol) returns the basic ep polarization tensor
    for a plane Wave object at ecliptic latitude elat, longitude elon,
    and polarization pol. This is a class (static) method.

    """
  return _lisaswig.Wave_putep(*args)

def Wave_putec(*args):
  """
    Wave.putec(elat,elon,pol) returns the basic ec polarization tensor
    for a plane Wave object at ecliptic latitude elat, longitude elon,
    and polarization pol. This is a class (static) method.

    """
  return _lisaswig.Wave_putec(*args)

class SimpleBinary(Wave):
    """
    SimpleBinary(f,phi0,inc,amp,elat,elon,pol) returns a Wave object that
    models the waveform emitted by a simple monochromatic binary with the
    following parameters:

    - the wave has frequency f [Hz] (so the binary has orbital frequency
      f/2) and initial phase phi0;

    - the hp and hc polarizations have a relative phase shift pi/2 and
      have an amplitude amp distributed consistently with a binary
      inclination angle inc:
      hp = amp * (1 + cos(inc)^2) * cos(2*pi*f*t + phi0),
      hc = amp * 2*cos(inc) *       sin(2*pi*f*t + phi0);

    - the wave is incoming from sky position (elat,elon), with
      polarization pol.
    """
    __swig_setmethods__ = {}
    for _s in [Wave]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, SimpleBinary, name, value)
    __swig_getmethods__ = {}
    for _s in [Wave]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, SimpleBinary, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        """
        Constructor. See above.

        """
        this = _lisaswig.new_SimpleBinary(*args)
        try: self.this.append(this)
        except: self.this = this
        
        self.initargs = args


    __swig_destroy__ = _lisaswig.delete_SimpleBinary
    __del__ = lambda self : None;
SimpleBinary_swigregister = _lisaswig.SimpleBinary_swigregister
SimpleBinary_swigregister(SimpleBinary)

class SimpleMonochromatic(Wave):
    """
    SimpleMonochromatic(f,phi,gamma,amp,elat,elon,pol) returns a Wave
    object that implements a simple sinusoidal wave with the following
    parameters:

    - the wave has frequency f [Hz];

    - the hp and hc polarizations have a relative phase shift phi and
      amplitude amp distributed according to the angle gamma:
      hp = amp * sin(gamma) * sin(2*pi*f*t + phi),
      hc = amp * cos(gamma) * sin(2*pi*f*t);

    - the wave is incoming from sky position (elat,elon), with
      polarization pol.
    """
    __swig_setmethods__ = {}
    for _s in [Wave]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, SimpleMonochromatic, name, value)
    __swig_getmethods__ = {}
    for _s in [Wave]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, SimpleMonochromatic, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        """
        Constructor. See above.

        """
        this = _lisaswig.new_SimpleMonochromatic(*args)
        try: self.this.append(this)
        except: self.this = this
    __swig_destroy__ = _lisaswig.delete_SimpleMonochromatic
    __del__ = lambda self : None;
SimpleMonochromatic_swigregister = _lisaswig.SimpleMonochromatic_swigregister
SimpleMonochromatic_swigregister(SimpleMonochromatic)

class GaussianPulse(Wave):
    """
    GaussianPulse(t0,efold,gamma,amp,elat,elon,pol) returns a Wave object
    that implements a Gaussian wavepulse with the following parameters:

    - the pulse is centered at SSB baricentric time t0 [seconds];

    - the pulse has e-folding time efold [seconds];

    - the pulse has amplitude amp, distributed as {ap,ac} = 
      amp*{sin(gamma),cos(gamma)} between the two polarizations
      (the same convention as SimpleMonochromatic)

    - the pulse is incoming from sky position (elat,elon), with
      polarization pol.

    The amplitude of the pulse is cut to zero at 10 efolding times from
    the central time (this is set by GaussianPulse::sigma_cutoff in
    lisasim-wave.cpp).
    """
    __swig_setmethods__ = {}
    for _s in [Wave]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, GaussianPulse, name, value)
    __swig_getmethods__ = {}
    for _s in [Wave]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, GaussianPulse, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        """
        Constructor. See above.

        """
        this = _lisaswig.new_GaussianPulse(*args)
        try: self.this.append(this)
        except: self.this = this
    __swig_destroy__ = _lisaswig.delete_GaussianPulse
    __del__ = lambda self : None;
GaussianPulse_swigregister = _lisaswig.GaussianPulse_swigregister
GaussianPulse_swigregister(GaussianPulse)

class SineGaussian(Wave):
    """
    SineGaussian(t0,efold,f,phi0,gamma,amp,elat,elon,pol) returns a Wave object
    that implements a Sine-Gaussian wavepulse with the following parameters:

    - the pulse is centered at SSB baricentric time t0 [seconds];

    - the pulse has e-folding time efold [seconds];

    - the pulse is modulated by a sinusoid of frequency f, centered at time
      t0, with relative phase phi0 between the two polarizations;

    - the pulse has amplitude amp, distributed as {ap,ac} = 
      amp*{sin(gamma),cos(gamma)} between the two polarizations
      (the same convention as SimpleMonochromatic)

    - the pulse is incoming from sky position (elat,elon), with
      polarization pol.

    The amplitude of the pulse is cut to zero at 10 efolding times from
    the central time (this is set by SineGaussian::sigma_cutoff in
    lisasim-wave.cpp).
    """
    __swig_setmethods__ = {}
    for _s in [Wave]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, SineGaussian, name, value)
    __swig_getmethods__ = {}
    for _s in [Wave]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, SineGaussian, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        """
        Constructor. See above.

        """
        this = _lisaswig.new_SineGaussian(*args)
        try: self.this.append(this)
        except: self.this = this
    __swig_destroy__ = _lisaswig.delete_SineGaussian
    __del__ = lambda self : None;
SineGaussian_swigregister = _lisaswig.SineGaussian_swigregister
SineGaussian_swigregister(SineGaussian)

class NoiseWave(Wave):
    """
    NoiseWave(hpnoise,hcnoise,elat,elon,pol),
    NoiseWave(deltat,prebuffer,psd,filter,interp,elat,elon,pol)
    return Wave objects that represent a noise-like plane GW incoming from
    sky position (elat,elon) with polarization pol.

    With the first form, hpnoise and hcnoise are Noise objects (previously
    instantiated, e.g., with InterpolateNoise) that provide the GW
    polarizations directly from the methods hpnoise.noise(t) and
    hpnoise.noise(t)

    With the second form, hp(t) and hc(t) are fed from two independent
    pseudorandom noise streams (implemented with InterpolateNoise), where:

    - deltat [s] is the time spacing of the pseudorandom samples at
      generation;

    - prebuffer [s ???] sets the minimum buffering interval for the
      pseudorandom sequences, which are stored in ring buffers (i.e.,
      after pseudorandom noise has been requested and computed at time t,
      the earliest value guaranteed to be available will be at time t -
      prebuffer);

    - psd and filter set the one-sided PSD of the pseudorandom noise
      stream to psd*(f/Hz)^filter Hz^-1 (currently only filter = -2, 0, 2
      is implemented);

    - interp (> 1) sets the semiwidth of the data window used in Lagrange
      interpolation (1 yields linear interpolation).

    The parameter prebuffer should generally be set higher for a NoiseWave
    object than it would be for an InterpolateNoise object, because hp(t)
    and hc(t) are defined in terms of SSB time, so the polarization values
    needed to build (say) X at t = 0 may require accessing hp and hc at
    the SSB t = -500 s, or earlier; on the other hand, when Synthetic LISA
    builds new InterpolateNoise objects it fills the ring buffer with
    values in the interval [-prebuffer,0].

    NoiseWave can also be created from arrays of previously
    generated waveform samples, using the SampledWave syntax (see help for
    SampledWave):

    NoiseWave(hparray,hcarray,len,deltat,prebuffer,norm,filter,interp,
              elat,elon,pol)

    TODO: details to be addressed: does the choice of interpolation affect
    the effective prebuffering interval? ???
    """
    __swig_setmethods__ = {}
    for _s in [Wave]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, NoiseWave, name, value)
    __swig_getmethods__ = {}
    for _s in [Wave]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, NoiseWave, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        """
        Constructor. See above.

        """
        this = _lisaswig.new_NoiseWave(*args)
        try: self.this.append(this)
        except: self.this = this
        
        self.initargs = args


    __swig_destroy__ = _lisaswig.delete_NoiseWave
    __del__ = lambda self : None;
    def hp(*args):
        """
        Wave.hp(t) returns the hp polarization of the GW Wave at time t [s] at
        the SSB.
        """
        return _lisaswig.NoiseWave_hp(*args)

    def hc(*args):
        """
        Wave.hc(t) returns the hc polarization of the GW Wave at time t [s] at
        the SSB.
        """
        return _lisaswig.NoiseWave_hc(*args)

NoiseWave_swigregister = _lisaswig.NoiseWave_swigregister
NoiseWave_swigregister(NoiseWave)

def SampledWave(hparray,hcarray,len,deltat,prebuffer,norm,filter,interp,elat,elon,pol):
    """Returns a Wave object that represent a sampled plane GW incoming from
sky position (elat,elon) with polarization pol, where:

- hparray and hcarray are 1-D Numeric arrays of length len containing
  time series for the hp and hc polarizations;

- deltat [s] is the time spacing of the time series;

- prebuffer [s ???] sets the indexing offset of the arrays with
  respect to the SSB time, so that (temporarily forgetting
  interpolation) hp(t) = hparray[(t - prebuffer)/deltat].
  This padding is needed because hp(t) and hc(t) are defined in terms
  of SSB time: the polarization values needed to build (say) X at t =
  0 may require accessing hp and hc at the SSB t = -500 s, or earlier;

- norm and filter set the normalization and filtering of the sampled
  arrays. The parameter filter must be a SynthLISA Filter object, or
  0 if only normalization is required;

- interp (> 1) sets the semiwidth of the data window used in Lagrange
  interpolation (1 yields linear interpolation).

SampledWave is represented internally using NoiseWave.

TODO: check if the prebuffering formula above is exact or if there is
another displacement by one or so."""

    wave = NoiseWave(hparray,hcarray,len,deltat,prebuffer,norm,filter,interp,elat,elon,pol)

    wave.xmltype = 'SampledWave'
    wave.xmlargs = [hparray,hcarray,len,deltat,prebuffer,norm,filter,interp,elat,elon,pol]

    return wave

def InterpolateMemory(hparray,hcarray,len,deltat,prebuffer,elat,elon,pol):
    """For backward compatibility, equivalent to 
NoiseWave(hparray,hcarray,len,deltat,prebuffer,1.0,0,1,elat,elon,pol)."""

    return NoiseWave(hparray,hcarray,len,deltat,prebuffer,1.0,0,1,elat,elon,pol)

class PyWave(Wave):
    """
    PyWave(hpfunc,hcfunc,elat,elon,pol)
    returns a Wave object that represents a generic plane GW incoming from
    ecliptic latitude elat and longitude elon, with polarization pol. The
    parameters hpfunc(t) and hcfunc(t) are Python functions that must
    return the hp and hc polarizations at SSB time t.

    While not too efficient, PyWave may be the simplest way to extend the
    Synthetic-LISA built-in Wave objects.
    """
    __swig_setmethods__ = {}
    for _s in [Wave]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, PyWave, name, value)
    __swig_getmethods__ = {}
    for _s in [Wave]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, PyWave, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        """
        Constructor. See above.

        """
        this = _lisaswig.new_PyWave(*args)
        try: self.this.append(this)
        except: self.this = this
        
        self.initargs = args


    def hp(*args):
        """
        Wave.hp(t) returns the hp polarization of the GW Wave at time t [s] at
        the SSB.
        """
        return _lisaswig.PyWave_hp(*args)

    def hc(*args):
        """
        Wave.hc(t) returns the hc polarization of the GW Wave at time t [s] at
        the SSB.
        """
        return _lisaswig.PyWave_hc(*args)

    __swig_destroy__ = _lisaswig.delete_PyWave
    __del__ = lambda self : None;
PyWave_swigregister = _lisaswig.PyWave_swigregister
PyWave_swigregister(PyWave)

class WaveArray(_object):
    """
    WaveArray(waves[]) returns a WaveArray object that represents the
    linear superposition of an array of Wave objects (each of which can be
    of a different type, have different parameters, or have different sky
    position and polarization angle).

    Note that if WaveArray is initialized with a reference to a list,
    successive modifications to the list will not be mirrored in the
    contents of the WaveArray, and could result in single Wave objects
    being deallocated when they shouldn't. To avoid the possibility of
    this, WaveArray should be created with a tuple.
    """
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, WaveArray, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, WaveArray, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        """
        Constructor. See above.

        """
        this = _lisaswig.new_WaveArray(*args)
        try: self.this.append(this)
        except: self.this = this
        
        self.initargs = args


    __swig_destroy__ = _lisaswig.delete_WaveArray
    __del__ = lambda self : None;
    def firstwave(*args):
        """
        WaveArray.firstwave() returns the first Wave object in a WaveArray.
        """
        return _lisaswig.WaveArray_firstwave(*args)

    def nextwave(*args):
        """
        WaveArray.nextwave() can be used repeatedly after
        WaveArray.firstwave() to return all the Wave objects in a
        WaveArray. After the last object, it will return None.
        """
        return _lisaswig.WaveArray_nextwave(*args)

WaveArray_swigregister = _lisaswig.WaveArray_swigregister
WaveArray_swigregister(WaveArray)

class TDIobject(Signal):
    __swig_setmethods__ = {}
    for _s in [Signal]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, TDIobject, name, value)
    __swig_getmethods__ = {}
    for _s in [Signal]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, TDIobject, name)
    def __init__(self): raise AttributeError, "No constructor defined"
    __repr__ = _swig_repr
    __swig_destroy__ = _lisaswig.delete_TDIobject
    __del__ = lambda self : None;
    def value(*args): return _lisaswig.TDIobject_value(*args)
TDIobject_swigregister = _lisaswig.TDIobject_swigregister
TDIobject_swigregister(TDIobject)

class TDIobjectpnt(TDIobject):
    __swig_setmethods__ = {}
    for _s in [TDIobject]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, TDIobjectpnt, name, value)
    __swig_getmethods__ = {}
    for _s in [TDIobject]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, TDIobjectpnt, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _lisaswig.new_TDIobjectpnt(*args)
        try: self.this.append(this)
        except: self.this = this
    __swig_destroy__ = _lisaswig.delete_TDIobjectpnt
    __del__ = lambda self : None;
    def value(*args): return _lisaswig.TDIobjectpnt_value(*args)
TDIobjectpnt_swigregister = _lisaswig.TDIobjectpnt_swigregister
TDIobjectpnt_swigregister(TDIobjectpnt)

class timeobject(Signal):
    __swig_setmethods__ = {}
    for _s in [Signal]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, timeobject, name, value)
    __swig_getmethods__ = {}
    for _s in [Signal]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, timeobject, name)
    def __init__(self): raise AttributeError, "No constructor defined"
    __repr__ = _swig_repr
timeobject_swigregister = _lisaswig.timeobject_swigregister
timeobject_swigregister(timeobject)

fastgetobs = _lisaswig.fastgetobs
fastgetobsc = _lisaswig.fastgetobsc
class TDI(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, TDI, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, TDI, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _lisaswig.new_TDI(*args)
        try: self.this.append(this)
        except: self.this = this
    __swig_destroy__ = _lisaswig.delete_TDI
    __del__ = lambda self : None;
    def reset(*args): return _lisaswig.TDI_reset(*args)
    def alpham(*args): return _lisaswig.TDI_alpham(*args)
    def betam(*args): return _lisaswig.TDI_betam(*args)
    def gammam(*args): return _lisaswig.TDI_gammam(*args)
    def zetam(*args): return _lisaswig.TDI_zetam(*args)
    def alpha1(*args): return _lisaswig.TDI_alpha1(*args)
    def alpha2(*args): return _lisaswig.TDI_alpha2(*args)
    def alpha3(*args): return _lisaswig.TDI_alpha3(*args)
    def zeta1(*args): return _lisaswig.TDI_zeta1(*args)
    def zeta2(*args): return _lisaswig.TDI_zeta2(*args)
    def zeta3(*args): return _lisaswig.TDI_zeta3(*args)
    def P(*args): return _lisaswig.TDI_P(*args)
    def E(*args): return _lisaswig.TDI_E(*args)
    def U(*args): return _lisaswig.TDI_U(*args)
    def Xm(*args): return _lisaswig.TDI_Xm(*args)
    def Ym(*args): return _lisaswig.TDI_Ym(*args)
    def Zm(*args): return _lisaswig.TDI_Zm(*args)
    def Xmlock1(*args): return _lisaswig.TDI_Xmlock1(*args)
    def Xmlock2(*args): return _lisaswig.TDI_Xmlock2(*args)
    def Xmlock3(*args): return _lisaswig.TDI_Xmlock3(*args)
    def X1(*args): return _lisaswig.TDI_X1(*args)
    def X2(*args): return _lisaswig.TDI_X2(*args)
    def X3(*args): return _lisaswig.TDI_X3(*args)
    def y(*args): return _lisaswig.TDI_y(*args)
    def z(*args): return _lisaswig.TDI_z(*args)
    def y123(*args): return _lisaswig.TDI_y123(*args)
    def y231(*args): return _lisaswig.TDI_y231(*args)
    def y312(*args): return _lisaswig.TDI_y312(*args)
    def y321(*args): return _lisaswig.TDI_y321(*args)
    def y132(*args): return _lisaswig.TDI_y132(*args)
    def y213(*args): return _lisaswig.TDI_y213(*args)
    def z123(*args): return _lisaswig.TDI_z123(*args)
    def z231(*args): return _lisaswig.TDI_z231(*args)
    def z312(*args): return _lisaswig.TDI_z312(*args)
    def z321(*args): return _lisaswig.TDI_z321(*args)
    def z132(*args): return _lisaswig.TDI_z132(*args)
    def z213(*args): return _lisaswig.TDI_z213(*args)
    def time(*args): return _lisaswig.TDI_time(*args)
    def t(*args): return _lisaswig.TDI_t(*args)
TDI_swigregister = _lisaswig.TDI_swigregister
TDI_swigregister(TDI)

class SampledTDI(TDI):
    __swig_setmethods__ = {}
    for _s in [TDI]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, SampledTDI, name, value)
    __swig_getmethods__ = {}
    for _s in [TDI]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, SampledTDI, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _lisaswig.new_SampledTDI(*args)
        try: self.this.append(this)
        except: self.this = this
        
        self.initargs = args


    __swig_destroy__ = _lisaswig.delete_SampledTDI
    __del__ = lambda self : None;
SampledTDI_swigregister = _lisaswig.SampledTDI_swigregister
SampledTDI_swigregister(SampledTDI)

class SampledTDIaccurate(SampledTDI):
    __swig_setmethods__ = {}
    for _s in [SampledTDI]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, SampledTDIaccurate, name, value)
    __swig_getmethods__ = {}
    for _s in [SampledTDI]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, SampledTDIaccurate, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _lisaswig.new_SampledTDIaccurate(*args)
        try: self.this.append(this)
        except: self.this = this
    __swig_destroy__ = _lisaswig.delete_SampledTDIaccurate
    __del__ = lambda self : None;
SampledTDIaccurate_swigregister = _lisaswig.SampledTDIaccurate_swigregister
SampledTDIaccurate_swigregister(SampledTDIaccurate)

class TDIquantize(TDI):
    __swig_setmethods__ = {}
    for _s in [TDI]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, TDIquantize, name, value)
    __swig_getmethods__ = {}
    for _s in [TDI]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, TDIquantize, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _lisaswig.new_TDIquantize(*args)
        try: self.this.append(this)
        except: self.this = this
        
        self.initargs = args


    __swig_destroy__ = _lisaswig.delete_TDIquantize
    __del__ = lambda self : None;
TDIquantize_swigregister = _lisaswig.TDIquantize_swigregister
TDIquantize_swigregister(TDIquantize)

def lighttime(lisa):
    # to estimate size of noisebuffer, take maximum armlength at time zero,
    # and add 10% for uplink-downlink uncertainty and flexing

    return 1.10 * max(lisa.armlength(1,0.0),
                      lisa.armlength(2,0.0),
                      lisa.armlength(3,0.0))

def stdproofnoise(lisa,stproof,sdproof,interp=1,seed=0):
    # we need quadruple retardations for the V's appearing in the z's
    # (octuple for 2nd-gen TDI); we add two sampling times to allow linear
    # interpolation for large sampling times

    pbtproof = 8.0 * lighttime(lisa) + 2.0*stproof

    return PowerLawNoise(stproof,pbtproof,sdproof,-2.0,interp,seed)

def stdproofnoisepink(lisa,stproof,sdproof,sf0proof,interp=1,seed=0):
    # we need quadruple retardations for the V's appearing in the z's
    # (octuple for 2nd-gen TDI); we add two sampling times to allow linear
    # interpolation for large sampling times

    pbtproof = 8.0 * lighttime(lisa) + 2.0*stproof

    return PowerLawNoise(stproof,pbtproof,sdproof * sf0proof**2,-4.0,interp,seed)

def stdopticalnoise(lisa,stshot,sdshot,interp=1,seed=0):
    # we need only triple retardations for the shot's appearing in the y's
    # (septuple for 2nd-gen TDI); we add two sampling times to allow linear
    # interpolation for large sampling times

    pbtshot = 7.0 * lighttime(lisa) + 2.0*stshot

    return PowerLawNoise(stshot,pbtshot,sdshot,2.0,interp,seed)

def stdlasernoise(lisa,stlaser,sdlaser,interp=1,seed=0):
    pbtlaser = 8.0 * lighttime(lisa) + 2.0*stlaser

    return PowerLawNoise(stlaser,pbtlaser,sdlaser,0.0,interp,seed)

class TDInoise(TDI):
    """
    TDInoise(lisa,PMnoise[6],      SHnoise[6],      LSnoise[6])
    TDInoise(lisa,PMdt,   PMpsd,   SHdt,   SHpsd,   LSdt,   LSpsd)

    all return TDI objects that implement the inter- and intra-spacecraft
    phase measurements using the standard noise transfer functions for
    proof-mass noise, shot noise, and laser noise. All the TDI observables
    defined in the base TDI class are available from TDInoise.

    - In the first form of the constructor, Synthetic LISA Noise/Signal
      objects (e.g., as created with PowerLawNoise or SampledSignal) must be
      provided for all 18 fundamental noises, in the orders [according to
      the PRD 71, 022001 (2005) naming]

      [pn_1,pn_1*,pn_2,pn_2*,pn_3,pn_3*]
      [y^sh_{12},y^sh_{21},y^sh_{23},y^sh_{32},y^sh_{31},y^sh_{13}]
      [C_1,C_1*,C_2,C_2*,C_3,C_3*]
      
    - In the second form of the constructor, the noise object are created
      internally as pseudorandom noise objects (equivalent to PowerLawNoise)
      with sampling times PMdt, SHdt, and LSdt, and with approximate
      one-sided power spectral densities

      PMpsd*(f/Hz)^-2 Hz^-1
      SHpsd*(f/Hz)^2  Hz^-1
      LSpsd           Hz^-1

    Note: resetting the TDInoise object will reset all the component noise
    objects. 

    TODO: might want to allow different interpolation widths for the
    self-built pseudorandom noise objects.
    """
    __swig_setmethods__ = {}
    for _s in [TDI]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, TDInoise, name, value)
    __swig_getmethods__ = {}
    for _s in [TDI]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, TDInoise, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        """
        Constructor. See above.

        """
        
        self.lisa = args[0]
        args = args[1:]
        
        # if no parameters are passed, used default value
        # if only one parameter is passed, use it as stime
        
        if len(args) == 0:
            args = (1.0, 2.5e-48, 1.0, 1.8e-37, 1.0, 1.1e-26)
        elif len(args) == 1:
            args = (args[0], 2.5e-48, args[0], 1.8e-37, args[0], 1.1e-26)
        
        # proof-mass: use deltat-psd model if we find a number, or assume
        # six Noise objects otherwise
        
        if type(args[0]) in (int,float):
            self.pm = [stdproofnoise(self.lisa,args[0],args[1]) for i in range(6)]
            args = args[2:]
        else:
            self.pm = args[0]
            args = args[1:]
        
        # shot noise: same story
        
        if type(args[0]) in (int,float):
            self.pd = [stdopticalnoise(self.lisa,args[0],args[1]) for i in range(6)]
            args = args[2:]
        else:
            self.pd = args[0]
            args = args[1:]
        
        # laser noise may not be passed: if so, set it to zero
        
        if len(args) > 0:
            if type(args[0]) in (int,float):
                self.c = [stdlasernoise(self.lisa,args[0],args[1]) for i in range(6)]
                args = args[2:]
            else:
                self.c = args[0]
                args = args[1:]    
        else:
            self.c = [NoSignal() for i in range(6)]
        
        args = (self.lisa,self.pm,self.pd,self.c)

        this = _lisaswig.new_TDInoise(*args)
        try: self.this.append(this)
        except: self.this = this
        
        self.initargs = args


    __swig_destroy__ = _lisaswig.delete_TDInoise
    __del__ = lambda self : None;
    def setphlisa(*args):
        val = _lisaswig.TDInoise_setphlisa(*args)
        
        self.phlisa = args

        return val

    def lock(*args): return _lisaswig.TDInoise_lock(*args)
    def reset(*args): return _lisaswig.TDInoise_reset(*args)
TDInoise_swigregister = _lisaswig.TDInoise_swigregister
TDInoise_swigregister(TDInoise)

class TDIaccurate(TDInoise):
    __swig_setmethods__ = {}
    for _s in [TDInoise]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, TDIaccurate, name, value)
    __swig_getmethods__ = {}
    for _s in [TDInoise]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, TDIaccurate, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _lisaswig.new_TDIaccurate(*args)
        try: self.this.append(this)
        except: self.this = this
        
        self.initargs = args


    __swig_destroy__ = _lisaswig.delete_TDIaccurate
    __del__ = lambda self : None;
TDIaccurate_swigregister = _lisaswig.TDIaccurate_swigregister
TDIaccurate_swigregister(TDIaccurate)

class TDIdoppler(TDInoise):
    __swig_setmethods__ = {}
    for _s in [TDInoise]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, TDIdoppler, name, value)
    __swig_getmethods__ = {}
    for _s in [TDInoise]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, TDIdoppler, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _lisaswig.new_TDIdoppler(*args)
        try: self.this.append(this)
        except: self.this = this
        
        self.initargs = args


    __swig_destroy__ = _lisaswig.delete_TDIdoppler
    __del__ = lambda self : None;
TDIdoppler_swigregister = _lisaswig.TDIdoppler_swigregister
TDIdoppler_swigregister(TDIdoppler)

class TDIcarrier(TDInoise):
    __swig_setmethods__ = {}
    for _s in [TDInoise]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, TDIcarrier, name, value)
    __swig_getmethods__ = {}
    for _s in [TDInoise]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, TDIcarrier, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _lisaswig.new_TDIcarrier(*args)
        try: self.this.append(this)
        except: self.this = this
        
        self.initargs = args


    __swig_destroy__ = _lisaswig.delete_TDIcarrier
    __del__ = lambda self : None;
    def y(*args): return _lisaswig.TDIcarrier_y(*args)
    def z(*args): return _lisaswig.TDIcarrier_z(*args)
TDIcarrier_swigregister = _lisaswig.TDIcarrier_swigregister
TDIcarrier_swigregister(TDIcarrier)

class TDIsignal(TDI):
    __swig_setmethods__ = {}
    for _s in [TDI]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, TDIsignal, name, value)
    __swig_getmethods__ = {}
    for _s in [TDI]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, TDIsignal, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _lisaswig.new_TDIsignal(*args)
        try: self.this.append(this)
        except: self.this = this
        
        self.initargs = args


    def Phi(*args): return _lisaswig.TDIsignal_Phi(*args)
    __swig_destroy__ = _lisaswig.delete_TDIsignal
    __del__ = lambda self : None;
TDIsignal_swigregister = _lisaswig.TDIsignal_swigregister
TDIsignal_swigregister(TDIsignal)



