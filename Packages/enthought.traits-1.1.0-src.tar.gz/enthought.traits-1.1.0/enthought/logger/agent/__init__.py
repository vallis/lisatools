"""
lib.enthought.logger.agent
"""