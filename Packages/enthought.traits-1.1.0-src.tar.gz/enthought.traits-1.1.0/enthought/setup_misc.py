#!/usr/bin/env python
#------------------------------------------------------------------------------
# Copyright (c) 2005, Enthought, Inc.
# All rights reserved.
# 
# This software is provided without warranty under the terms of the BSD
# license included in enthought/LICENSE.txt and may be redistributed only
# under the conditions described in the aforementioned license.  The license
# is also available online at http://www.enthought.com/licenses/BSD.txt
# Thanks for using Enthought open source!
# 
# Author: David C. Morrill
# Date: 2/03/2003
# Description: Python setup for the 'traits' package
#------------------------------------------------------------------------------

# we have to maintain 2 min versions for each numpy and scipy
# because releases do not include svn versions
minimum_numpy_version_svn = '0.9.7.2476'
minimum_scipy_version_svn = '0.4.9.1882'
minimum_numpy_version = '0.9.8'
minimum_scipy_version = '0.4.9'

def configuration(parent_package='',top_path=None):
    global minimum_numpy_version
    global minimum_scipy_version
    import numpy
    if (4 == len(numpy.__version__.split('.'))):
        minimum_numpy_version = minimum_numpy_version_svn
    if numpy.__version__ < minimum_numpy_version:
        raise RuntimeError, 'numpy version %s or higher required, but got %s'\
              % (minimum_numpy_version, numpy.__version__)
    import scipy
    if (4 == len(scipy.__version__.split('.'))):
        minimum_scipy_version = minimum_scipy_version_svn
    if scipy.__version__ < minimum_scipy_version:
        raise RuntimeError, 'scipy version %s or higher required, but got %s'\
              % (minimum_scipy_version, scipy.__version__)
    from numpy.distutils.misc_util import Configuration
    config = Configuration('enthought',parent_package,top_path)
    config.set_options(ignore_setup_xxx_py=True,
                       assume_default_configuration=True,
                       delegate_options_to_subpackages=True,
                       quiet=True)

    config.add_data_files('LICENSE.txt')

    config.add_subpackage("io")
    config.add_subpackage("component")
    config.add_subpackage("debug")
    config.add_subpackage("guitest")
    config.add_subpackage("help")
    config.add_subpackage("interpolate")
    config.add_subpackage("io")
    config.add_subpackage("logger")
    config.add_subpackage("mathematics")
    config.add_subpackage("mathtext")
    config.add_subpackage("model")
    config.add_subpackage("plugins")
    config.add_subpackage("python")
    config.add_subpackage("resource")
    config.add_subpackage("resource_type")
    config.add_subpackage("type_manager")
    
    return config

if __name__ == "__main__":

    # Remove current working directory from sys.path
    # to avoid importing numpy.logging as Python std. logging:
    import os, sys
    for cwd in ['','.',os.getcwd(),os.path.dirname(sys.argv[0])]:
        while cwd in sys.path: sys.path.remove(cwd)

    from numpy.distutils.core import setup
    setup(version='1.1.0',
          description  = 'Core Enthought Tool Suite packages',
          author       = 'Enthought, Inc',
          author_email = 'info@enthought.com',
          url          = 'http://code.enthought.com/traits',
          license      = 'BSD',
          configuration=configuration)