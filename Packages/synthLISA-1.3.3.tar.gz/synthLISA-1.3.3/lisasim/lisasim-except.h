/* $Id: lisasim-except.h 393 2006-12-17 11:29:24Z vallis $
 * $Date: 2006-12-17 12:29:24 +0100 (Sun, 17 Dec 2006) $
 * $Author: vallis $
 * $Revision: 393 $
 */

#ifndef _LISASIM_EXCEPT_H_
#define _LISASIM_EXCEPT_H_

// later can be made to inherit from a more generic class

class SynthLISAException {};

class ExceptionOutOfBounds : SynthLISAException {};
class ExceptionUndefined : SynthLISAException {};
class ExceptionWrongArguments : SynthLISAException {};
class ExceptionFileError : SynthLISAException {};
class ExceptionKeyboardInterrupt : SynthLISAException {};

#endif /* _LISASIM_EXCEPT_H_ */
