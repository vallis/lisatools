/****************************************************************************/
/*                                                                          */
/* TITLE: Vertex 2 Noise                                                    */
/* AUTHORS: Louis J. Rubbo and Neil J. Cornish                              */
/* DATE: June 22, 2006                                                      */
/* VERSION: 2.1.1                                                           */
/*                                                                          */
/*                                                                          */
/* ABSTRACT: This program produces a full realization of the LISA noise     */
/* associated with the signals produced with spacecraft 2 acting as the     */
/* vertex craft.  The two main effects included in the noise are photon     */
/* shot noise and acceleration noise.                                       */
/*                                                                          */
/*                                                                          */
/* COMPILE: gcc -o Vertex2Noise Vertex2Noise.c -lm                          */
/*                                                                          */
/****************************************************************************/


/*************************  REQUIRED HEADER FILES  **************************/

#include <stdio.h>
#include <math.h>
#include "LISAconstants.h"



/*******************************  STRUCTURES  *******************************/

 /* Vertex 2 time structure (tij: time of emission from spacecraft i for a 
    photon that will be received by spacecraft j) */
struct Time
{
  double t2;
  double t32;
  double t23;
  double t12;
  double t21;
  double t32x;
  double t23x;
  double t12x;
  double t21x;
};
 


/*************  PROTOTYPE DECLARATIONS FOR INTERNAL FUNCTIONS  **************/

void MichelsonNoise(struct Time*, double*, long, long, int);
void TDINoise(struct Time*, double*, double*, long, long, int);
void MichelsonShotNoise(struct Time*, double*, double, long, long, int);
void TDIShotNoise(struct Time*, double*, double, long, long, int);
void MichelsonAccNoise(struct Time*, double*, double, long, long, int);
void TDIAccNoise(struct Time*, double*, double, long, long, int);
void VertexTimes(struct Time*, long, char*);
void FileRead(double*, long, char*);
void FileWrite(double*, long, char*);
void KILL(char*);



/* ============================  MAIN PROGRAM  ============================ */

int main(void)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Number of data points in a section without padding */
  long Nsec;

 /* Number of data points in a section with padding */
  long N;

 /* Array of Time structures */
  struct Time* Times;

 /* Time noise stream for the Michelson and Y noises */
  double* Mike;
  double* Ysig;

 /* Filename character array */
  char Filename[50];
  char Xfile[50];
  char Mfile[50];

 /* rSeed recorded for file naming */
  FILE* filename;

 /* Random number seed */
  long rSeed;

 /* Loop indexes */
  long a, b;


          /* -------------------  CALCULATIONS  ------------------- */

  printf("\n\n");
  printf("  ______________________________________________________  \n");
  printf(" |                                                      | \n");
  printf(" |                    Vertex 2 Noise                    | \n");
  printf(" |______________________________________________________| \n\n");

  filename = fopen("Data/seed.txt","r");

  fscanf(filename,"%d\n",&rSeed);

  fclose(filename);

  rSeed *= -1;

  sprintf(Xfile, "Binary/YNoise_%d.bin", rSeed);
  sprintf(Mfile, "Binary/M2Noise_%d.bin", rSeed);

 /* Remove any old signal files */

  remove(Xfile);
  remove(Mfile);


 /* Calculate the section widths */

  Nsec = (int)ceil(NFFT/Ndiv);

  N = Nsec + 2*(int)ceil(Tpad/dt);


 /* Dynamically allocate the memory for the array of Time structures */

  Times = (struct Time*) malloc (Nsec*sizeof(struct Time));

  if (!Times) KILL("Out of memory!\n");


 /* Dynamically allocate the memory for the two noise data series */

  Mike = (double*) malloc (Nsec*sizeof(double));
  Ysig = (double*) malloc (Nsec*sizeof(double));

  if(!Mike || !Ysig) KILL("Out of memory.\n");


 /* Calculate the noise in the time domain */

  printf("Calculating the noise in the time domain.\n\n");

  for (a = 1 ; a <= Ndiv ; a++)
  {

   /* Initialize the noise to zero */

    for (b = 0 ; b < Nsec ; b++)
    {
      Mike[b] = 0.0;
      Ysig[b] = 0.0;
    }


   /* Import the vertex 2 times */

    sprintf(Filename, "Binary/Vert2_%i.dat", a);
    VertexTimes(Times, Nsec, Filename);


   /* Calculate the Michelson noise */

    MichelsonNoise(Times, Mike, Nsec, N, a);


   /* Calculate the Y noise */

    TDINoise(Times, Mike, Ysig, Nsec, N, a);


   /* Turn the noise data series into unitless strains */

    for(b = 0 ; b < Nsec ; b++)
    {
      Mike[b] *= 1.0/(2.0*L);
      Ysig[b] *= 1.0/(2.0*L);
    }


   /* Write the time noise stream to file */

    FileWrite(Mike, Nsec, Mfile);
    FileWrite(Ysig, Nsec, Xfile);

   /* User update */

    printf("  Section %i out of %i is now complete.\n", a, (int)Ndiv);
  }


 /* Free the allocated memory */

  free(Times);
  free(Mike);
  free(Ysig);


  printf("\n----------------------------------------------------------\n");
  printf("The program is now complete.\n\n\n");


  return 0;
}

/* ======================================================================== */





/***************************  INTERNAL FUNCTIONS  ***************************/

void MichelsonNoise(struct Time* Times, double* Mike, long Nsec, long N, 
		    int Section)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Initial time for a section */
  double ts;


          /* -------------------  CALCULATIONS  ------------------- */

 /* Calculate the starting time for the section */

  ts = dt*( (double)(Section-1)*ceil(NFFT/Ndiv) - ceil(Tpad/dt) )+dt/2.0;

 /* Add in the shot noise */

  MichelsonShotNoise(Times, Mike, ts, Nsec, N, Section);


 /* Add in the acceleration noise */

  MichelsonAccNoise(Times, Mike, ts, Nsec, N, Section);


  return;
}





void TDINoise(struct Time* Times, double* Mike, double* Ysig, long Nsec, 
	      long N, int Section)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Initial time for a section */
  double ts;

 /* Loop index */
  long a;


          /* -------------------  CALCULATIONS  ------------------- */

 /* Initialize the Y noise */

  for(a = 0 ; a < Nsec ; a++) Ysig[a] = Mike[a];
  

 /* Calculate the starting time for the section */

  ts = dt*( (double)(Section-1)*ceil(NFFT/Ndiv) - ceil(Tpad/dt) )+dt/2.0;

 /* Add in the shot noise */

  TDIShotNoise(Times, Ysig, ts, Nsec, N, Section);


 /* Add in the acceleration noise */

  TDIAccNoise(Times, Ysig, ts, Nsec, N, Section);


  return;
}





void MichelsonShotNoise(struct Time* Times, double* Mike, double ts, long Nsec,
			long N, int Section)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Helio-time */
  double t;

 /* Temporary shot noise array */
  double* nsij;

 /* Bin number that contains the time t */
  long Bin;

 /* Loop index */
  long a;

  double DT;

 /* Filename character array */
  char Filename[50];


          /* -------------------  CALCULATIONS  ------------------- */

 /* Dynamically allocate the memory for the shot noise array */

  nsij = (double*) malloc (N*sizeof(double));

  if (!nsij) KILL("Out of memory!\n");


 /* Phi32 */

  sprintf(Filename, "Binary/ShotNoise32_%i.dat", Section);
  FileRead(nsij, N, Filename);

 

  for (a = 0 ; a < Nsec ; a++)
  {

    t = Times[a].t2;
    Bin = (int)floor(t/dt) - (int)floor(ts/dt);
    if (Bin < 0 || Bin > N-2) 
      KILL("Requested array access is out of bounds.\n");

    DT = t - dt*floor(t/dt);

    Mike[a] += ((nsij[Bin+1]-nsij[Bin])/dt)*DT + nsij[Bin];

  }


 /* Phi23 */

  sprintf(Filename, "Binary/ShotNoise23_%i.dat", Section);
  FileRead(nsij, N, Filename);

  for (a = 0 ; a < Nsec ; a++)
  {
    t = Times[a].t32;
    Bin = (int)floor(t/dt) - (int)floor(ts/dt);

    if (Bin < 0 || Bin > N-2) 
      KILL("Requested array access is out of bounds.\n");

    DT = t - dt*floor(t/dt);

    Mike[a] += (((nsij[Bin+1]-nsij[Bin])/dt)*DT + nsij[Bin]);
  }


 /* Phi12 */

  sprintf(Filename, "Binary/ShotNoise12_%i.dat", Section);
  FileRead(nsij, N, Filename);

  for (a = 0 ; a < Nsec ; a++)
  {
    t = Times[a].t2;
    Bin = (int)floor(t/dt) - (int)floor(ts/dt);
    if (Bin < 0 || Bin > N-2) 
      KILL("Requested array access is out of bounds.\n");

    DT = t - dt*floor(t/dt);

    Mike[a] -= (((nsij[Bin+1]-nsij[Bin])/dt)*DT + nsij[Bin]);


  }


 /* Phi21 */

  sprintf(Filename, "Binary/ShotNoise21_%i.dat", Section);
  FileRead(nsij, N, Filename);

  for (a = 0 ; a < Nsec ; a++)
  {
    t = Times[a].t12;
    Bin = (int)floor(t/dt) - (int)floor(ts/dt);
    if (Bin < 0 || Bin > N-2) 
      KILL("Requested array access is out of bounds.\n");

    DT = t - dt*floor(t/dt);

    Mike[a] -= (((nsij[Bin+1]-nsij[Bin])/dt)*DT + nsij[Bin]);

  }


 /* Free the allocated memory */

  free(nsij);


  return;
}





void TDIShotNoise(struct Time* Times, double* Ysig, double ts, long Nsec,
		  long N, int Section)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Helio-time */
  double t;

 /* Temporary shot noise array */
  double* nsij;

 /* Bin number that contains the time t */
  long Bin;

 /* Loop index */
  long a;

  double DT;

 /* Filename character array */
  char Filename[50];


          /* -------------------  CALCULATIONS  ------------------- */

 /* Dynamically allocate the memory for the shot noise array */

  nsij = (double*) malloc (N*sizeof(double));

  if (!nsij) KILL("Out of memory!\n");


 /* Phi32 */

  sprintf(Filename, "Binary/ShotNoise32_%i.dat", Section);
  FileRead(nsij, N, Filename);

  for (a = 0 ; a < Nsec ; a++)
  {
    t = Times[a].t21;
    Bin = (int)floor(t/dt) - (int)floor(ts/dt);
    if (Bin < 0 || Bin > N-2) 
      KILL("Requested array access is out of bounds.\n");

    DT = t - dt*floor(t/dt);

    Ysig[a] -= (((nsij[Bin+1]-nsij[Bin])/dt)*DT + nsij[Bin]);

  }


 /* Phi23 */

  sprintf(Filename, "Binary/ShotNoise23_%i.dat", Section);
  FileRead(nsij, N, Filename);

  for (a = 0 ; a < Nsec ; a++)
  {
    t = Times[a].t32x;
    Bin = (int)floor(t/dt) - (int)floor(ts/dt);
    if (Bin < 0 || Bin > N-2) 
      KILL("Requested array access is out of bounds.\n");

    DT = t - dt*floor(t/dt);

    Ysig[a] -= (((nsij[Bin+1]-nsij[Bin])/dt)*DT + nsij[Bin]);

  }


 /* Phi12 */

  sprintf(Filename, "Binary/ShotNoise12_%i.dat", Section);
  FileRead(nsij, N, Filename);

  for (a = 0 ; a < Nsec ; a++)
  {
    t = Times[a].t23;
    Bin = (int)floor(t/dt) - (int)floor(ts/dt);
    if (Bin < 0 || Bin > N-2) 
      KILL("Requested array access is out of bounds.\n");

    DT = t - dt*floor(t/dt);

    Ysig[a] += (((nsij[Bin+1]-nsij[Bin])/dt)*DT + nsij[Bin]);

  }


 /* Phi21 */

  sprintf(Filename, "Binary/ShotNoise21_%i.dat", Section);
  FileRead(nsij, N, Filename);

  for (a = 0 ; a < Nsec ; a++)
  {
    t = Times[a].t12x;
    Bin = (int)floor(t/dt) - (int)floor(ts/dt);
    if (Bin < 0 || Bin > N-2) 
      KILL("Requested array access is out of bounds.\n");

    DT = t - dt*floor(t/dt);

    Ysig[a] += (((nsij[Bin+1]-nsij[Bin])/dt)*DT + nsij[Bin]);

  }


 /* Free the allocated memory */

  free(nsij);


  return;
}





void MichelsonAccNoise(struct Time* Times, double* Mike, double ts, long Nsec, 
		       long N, int Section)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Emmission and reception times */
  double ti, tj;

 /* Time bins that contain the emission and reception times */
  long Bin_i, Bin_j;

 /* Interpolated unit vector component needed for dot product */
  double rij;

 /* Filename character array */
  char Filename[50];

 /* Acceleration noise in the time domain */
  double* na23;
  double* na32;
  double* na21;
  double* na12;

  double DTj, DTi;

 /* Loop index */
  long a;


          /* -------------------  CALCULATIONS  ------------------- */

 /* Phi23 and Phi32 */

     /* Dynamically allocate the memory for a component of the acceleration
	noise */

  na23 = (double*) malloc (N*sizeof(double));
  na32 = (double*) malloc (N*sizeof(double));

  if (!na23 || !na32) KILL("Out of memory!\n");


     /* Import the component of the acceleration noise in Phi23 and Phi32 */

  sprintf(Filename, "Binary/AccNoise23_%i.dat", Section);
  FileRead(na23, N, Filename);

  sprintf(Filename, "Binary/AccNoise32_%i.dat", Section);
  FileRead(na32, N, Filename);


     /* Phi32 acceleration noise */

  for (a = 0 ; a < Nsec ; a++)
  {
    tj = Times[a].t2;
    Bin_j = (int)floor(tj/dt) - (int)floor(ts/dt);
    if (Bin_j < 0 || Bin_j > N-2) 
      KILL("Requested array access is out of bounds.\n");

    ti = Times[a].t32;
    Bin_i = (int)floor(ti/dt) - (int)floor(ts/dt);
    if (Bin_i < 0 || Bin_i > N-2) 
      KILL("Requestes array access is out of bounds.\n");

    DTi = ti - dt*floor(ti/dt);
    DTj = tj - dt*floor(tj/dt);

    Mike[a] += -(((na32[Bin_j+1]-na32[Bin_j])/dt)*DTj + na32[Bin_j])
              -(((na23[Bin_i+1]-na23[Bin_i])/dt)*DTi + na23[Bin_i]);

  }


     /* Phi23 acceleration noise */

  for (a = 0 ; a < Nsec ; a++)
  {
    tj = Times[a].t32;
    Bin_j = (int)floor(tj/dt) - (int)floor(ts/dt);
    if (Bin_j < 0 || Bin_j > N-2) 
      KILL("Requested array access is out of bounds.\n");

    ti = Times[a].t23;
    Bin_i = (int)floor(ti/dt) - (int)floor(ts/dt);
    if (Bin_i < 0 || Bin_i > N-2) 
      KILL("Requqested array access is out of bounds.\n");

    DTi = ti - dt*floor(ti/dt);
    DTj = tj - dt*floor(tj/dt);

    Mike[a] += -(((na23[Bin_j+1]-na23[Bin_j])/dt)*DTj + na23[Bin_j])
               -(((na32[Bin_i+1]-na32[Bin_i])/dt)*DTi + na32[Bin_i]);

  }


 /* Free the allocated memory */

  free(na23);
  free(na32);


 /* Phi21 and Phi12 */

     /* Dynamically allocate the memory for a component of the acceleration
	noise */

  na21 = (double*) malloc (N*sizeof(double));
  na12 = (double*) malloc (N*sizeof(double));

  if (!na21 || !na12) KILL("Out of memory!\n");


     /* Import the component of the acceleration noise in Phi21 and Phi12 */

  sprintf(Filename, "Binary/AccNoise21_%i.dat", Section);
  FileRead(na21, N, Filename);

  sprintf(Filename, "Binary/AccNoise12_%i.dat", Section);
  FileRead(na12, N, Filename);


     /* Phi12 acceleration noise */

  for (a = 0 ; a < Nsec ; a++)
  {
   tj = Times[a].t2;
    Bin_j = (int)floor(tj/dt) - (int)floor(ts/dt);
    if (Bin_j < 0 || Bin_j > N-2) 
      KILL("Requested array access is out of bounds.\n");

    ti = Times[a].t12;
    Bin_i = (int)floor(ti/dt) - (int)floor(ts/dt);
    if (Bin_i < 0 || Bin_i > N-2) 
      KILL("Requested array access is out of bounds.\n");

    DTi = ti - dt*floor(ti/dt);
    DTj = tj - dt*floor(tj/dt);

    Mike[a] += +(((na12[Bin_j+1]-na12[Bin_j])/dt)*DTj + na12[Bin_j])
               +(((na21[Bin_i+1]-na21[Bin_i])/dt)*DTi + na21[Bin_i]);

  }


     /* Phi21 acceleration noise */

  for (a = 0 ; a < Nsec ; a++)
  {
    tj = Times[a].t12;
    Bin_j = (int)floor(tj/dt) - (int)floor(ts/dt);
    if (Bin_j < 0 || Bin_j > N) 
      KILL("Requested array access is out of bounds.\n");

    ti = Times[a].t21;
    Bin_i = (int)floor(ti/dt) - (int)floor(ts/dt);
    if (Bin_i < 0 || Bin_i > N) 
      KILL("Requested array access is out of bounds.\n");

    DTi = ti - dt*floor(ti/dt);
    DTj = tj - dt*floor(tj/dt);

    Mike[a] += +(((na21[Bin_j+1]-na21[Bin_j])/dt)*DTj + na21[Bin_j])
               +(((na12[Bin_i+1]-na12[Bin_i])/dt)*DTi + na12[Bin_i]);

  }


 /* Free the allocated memory */

  free(na21);
  free(na12);


  return;
}





void TDIAccNoise(struct Time* Times, double* Ysig, double ts, long Nsec, 
		 long N, int Section)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Emmission and reception times */
  double ti, tj;

 /* Time bins that contain the emission and reception times */
  long Bin_i, Bin_j;

 /* Interpolated unit vector component needed for dot product */
  double rij;

 /* Filename character array */
  char Filename[50];

 /* Acceleration noise in the time domain */
  double* na23;
  double* na32;
  double* na21;
  double* na12;

  double DTi, DTj;

 /* Loop index */
  long a;


          /* -------------------  CALCULATIONS  ------------------- */

 /* Phi23 and Phi32 */

     /* Dynamically allocate the memory for a component of the acceleration
	noise */

  na23 = (double*) malloc (N*sizeof(double));
  na32 = (double*) malloc (N*sizeof(double));

  if (!na23 || !na32) KILL("Out of memory!\n");


     /* Import the component of the acceleration noise in Phi23 and Phi32 */

  sprintf(Filename, "Binary/AccNoise23_%i.dat", Section);
  FileRead(na23, N, Filename);

  sprintf(Filename, "Binary/AccNoise32_%i.dat", Section);
  FileRead(na32, N, Filename);


     /* Phi32 acceleration noise */

  for (a = 0 ; a < Nsec ; a++)
  {
    tj = Times[a].t21;
    Bin_j = (int)floor(tj/dt) - (int)floor(ts/dt);
    if (Bin_j < 0 || Bin_j > N-2) 
      KILL("Requested array access is out of bounds.\n");

    ti = Times[a].t32x;
    Bin_i = (int)floor(ti/dt) - (int)floor(ts/dt);
    if (Bin_i < 0 || Bin_i > N-2) 
      KILL("Requested array access is out of bounds.\n");

    DTi = ti - dt*floor(ti/dt);
    DTj = tj - dt*floor(tj/dt);

    Ysig[a] += (((na32[Bin_j+1]-na32[Bin_j])/dt)*DTj + na32[Bin_j])
               +(((na23[Bin_i+1]-na23[Bin_i])/dt)*DTi + na23[Bin_i]);

  }


     /* Phi23 acceleration noise */

  for (a = 0 ; a < Nsec ; a++)
  {
    tj = Times[a].t32x;
    Bin_j = (int)floor(tj/dt) - (int)floor(ts/dt);
    if (Bin_j < 0 || Bin_j > N-2) 
      KILL("Requested array access is out of bounds.\n");

    ti = Times[a].t23x;
    Bin_i = (int)floor(ti/dt) - (int)floor(ts/dt);
    if (Bin_i < 0 || Bin_i > N-2) 
      KILL("Requqested array access is out of bounds.\n");

    DTi = ti - dt*floor(ti/dt);
    DTj = tj - dt*floor(tj/dt);

    Ysig[a] += (((na23[Bin_j+1]-na23[Bin_j])/dt)*DTj + na23[Bin_j])
               +(((na32[Bin_i+1]-na32[Bin_i])/dt)*DTi + na32[Bin_i]);

  }


 /* Free the allocated memory */

  free(na23);
  free(na32);


 /* Phi21 and Phi12 */

     /* Dynamically allocate the memory for a component of the acceleration
	noise */

  na21 = (double*) malloc (N*sizeof(double));
  na12 = (double*) malloc (N*sizeof(double));

  if (!na21 || !na12) KILL("Out of memory!\n");


     /* Import the component of the acceleration noise in Phi21 and Phi12 */

  sprintf(Filename, "Binary/AccNoise21_%i.dat", Section);
  FileRead(na21, N, Filename);

  sprintf(Filename, "Binary/AccNoise12_%i.dat", Section);
  FileRead(na12, N, Filename);


     /* Phi12 acceleration noise */

  for (a = 0 ; a < Nsec ; a++)
  {
    tj = Times[a].t23;
    Bin_j = (int)floor(tj/dt) - (int)floor(ts/dt);
    if (Bin_j < 0 || Bin_j > N) 
      KILL("Requested array access is out of bounds.\n");

    ti = Times[a].t12x;
    Bin_i = (int)floor(ti/dt) - (int)floor(ts/dt);
    if (Bin_i < 0 || Bin_i > N) 
      KILL("Requested array access is out of bounds.\n");

    DTi = ti - dt*floor(ti/dt);
    DTj = tj - dt*floor(tj/dt);

    Ysig[a] += -(((na12[Bin_j+1]-na12[Bin_j])/dt)*DTj + na12[Bin_j])
               -(((na21[Bin_i+1]-na21[Bin_i])/dt)*DTi + na21[Bin_i]);

  }


     /* Phi21 acceleration noise */

  for (a = 0 ; a < Nsec ; a++)
  {
    tj = Times[a].t12x;
    Bin_j = (int)floor(tj/dt) - (int)floor(ts/dt);
    if (Bin_j < 0 || Bin_j > N) 
      KILL("Requested array access is out of bounds.\n");

    ti = Times[a].t21x;
    Bin_i = (int)floor(ti/dt) - (int)floor(ts/dt);
    if (Bin_i < 0 || Bin_i > N) 
      KILL("Requested array access is out of bounds.\n");

    DTi = ti - dt*floor(ti/dt);
    DTj = tj - dt*floor(tj/dt);

    Ysig[a] += -(((na21[Bin_j+1]-na21[Bin_j])/dt)*DTj + na21[Bin_j])
               -(((na12[Bin_i+1]-na12[Bin_i])/dt)*DTi + na12[Bin_i]);

  }


 /* Free the allocated memory */

  free(na21);
  free(na12);


  return;
}





void VertexTimes(struct Time* Times, long Nsec, char* Filename)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Error message character array */
  char ErrorMessage[100];

 /* Loop index */
  int a;

 /* File pointer */
  FILE* TimeIn;


          /* -------------------  CALCULATIONS  ------------------- */

 /* Open a binary formatted file */

  if ((TimeIn = fopen(Filename, "rb")) == NULL)
  {
    sprintf(ErrorMessage, "Cannot open the file %s.\n", Filename);
    KILL(ErrorMessage);
  }


 /* Read in the file */

  for (a = 0 ; a < Nsec ; a++)
    fread(&Times[a], sizeof(struct Time), 1, TimeIn);


 /* Close the file */

  fclose(TimeIn);


  return;
}





void FileRead(double* n_ij, long N, char* Filename)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Error message character array */
  char ErrorMessage[100];

 /* Loop index */
  long a;

 /* File pointer */
  FILE* NoiseIn;


          /* -------------------  CALCULATIONS  ------------------- */

 /* Open a binary formatted file */

  if ((NoiseIn = fopen(Filename, "rb")) == NULL)
  {
    sprintf(ErrorMessage, "Cannot open the file %s.\n", Filename);
    KILL(ErrorMessage);
  }


 /* Read in the file */

  for (a = 0 ; a < N ; a++) fread(&n_ij[a], sizeof(double), 1, NoiseIn);


 /* Close the file */

  fclose(NoiseIn);


  return;
}






void FileWrite(double* TDS, long Nsec, char* Filename)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Error message character array */
  char ErrorMessage[100];

 /* Loop index */
  int a;

 /* File pointer */
  FILE* NoiseOut;


          /* -------------------  CALCULATIONS  ------------------- */

 /* Open a binary formatted file */

  if ((NoiseOut = fopen(Filename, "ab")) == NULL)
  {
    sprintf(ErrorMessage, "Cannot open the file %s.\n", Filename);
    KILL(ErrorMessage);
  }


 /* Write to file in binary format */

  for (a = 0 ; a < Nsec ; a++) fwrite(&TDS[a], sizeof(double), 1, NoiseOut);


 /* Close the file */

  fclose(NoiseOut);


  return;
}





void KILL(char* Message)
{
  printf("\a\n");
  printf(Message);
  printf("Terminating the program.\n\n");
  exit(1);

 
  return;
}
