#------------------------------------------------------------------------------
# Copyright (c) 2005, Enthought, Inc.
# All rights reserved.
# 
# This software is provided without warranty under the terms of the BSD
# license included in enthought/LICENSE.txt and may be redistributed only
# under the conditions described in the aforementioned license.  The license
# is also available online at http://www.enthought.com/licenses/BSD.txt
# Thanks for using Enthought open source!
# 
# Author: Enthought, Inc.
# Description: <Enthought util package component>
#------------------------------------------------------------------------------
""" A constant (point) distribution. """


# Major package imports.
from enthought.util.numerix import ones

# Enthought library imports.
from enthought.traits  import Trait, TraitGroup, TraitRange

# Local imports.
from distribution import Distribution


class Constant(Distribution):
    """ A constant (point) distribution. """


    __editable_traits__ = TraitGroup('value', style='text')


    def __init__(self, value, low_bound, high_bound, **traits):
        """ Creates a new constant (point) distribution. """
        
        # Base-class constructor.
        Distribution.__init__(self, low_bound, high_bound)
        
        # Dynamic traits.
        value_trait = Trait(value, TraitRange(low_bound, high_bound))
        self.add_trait('value', value_trait)
        
        # Initialize dynamic traits.
        self.value = value

        # fixme: Hmmm, so the 'model' knows about its colour!
        self.fill_color = (0, 0, 1, 0.6)

        return

    ###########################################################################
    # 'Distribution' interface.
    ###########################################################################
    
    def clone(self):
        """ Returns a clone of the distribution. """

        clone = Constant(self.low_bound, self.high_bound)
        clone.set(value=self.value)
        
        return clone

    def generate(self, n=1):
        """ Generates 'n' values in the distribution. """
        
        return self.value * ones((n,))

    def plot_value (self):

        from enthought.chaco.plot_value import PlotValue        

        """ Returns a plot value representing the variable. """

        value = self.value

        plot_value = PlotValue( [[self.low_bound,  0.0], 
                                 [value,           0.0], 
                                 [value,           1.0], 
                                 [value,           1.0], 
                                 [value,           0.0], 
                                 [self.high_bound, 0.0],],
            type        = 'polygon',
            line_weight = 3,
            line_color  = self.fill_color
        )

        return plot_value

#### EOF ######################################################################
