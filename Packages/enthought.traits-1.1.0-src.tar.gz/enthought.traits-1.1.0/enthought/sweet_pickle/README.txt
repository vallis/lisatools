The sweet_pickle package is not in wide use and thus has not been fully
vetted.  As such, we reserve the right to make significant refactorings
to this package, classes, and API.

**** USE ONLY IF YOU ACCEPT THIS SITUATION. ****

See the comments in the package init for an explanation of why this package
exists.
