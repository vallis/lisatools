/****************************************************************************/
/*                                                                          */
/* TITLE: Gravitational Wave Noiseless Signals From Vertex 3                */
/* AUTHORS: Louis J. Rubbo and Neil J. Cornish                              */
/* DATE: June 22, 2006                                                      */
/* VERSION: 2.1.1                                                           */
/*                                                                          */
/*                                                                          */
/* ABSTRACT: This program calculates the response of the LISA detector to   */
/* an arbitrary gravitational wave in the absense of noise.  The            */
/* calculations used in this code are based on the paper:                   */
/*      N.J. Cornish and L.J. Rubbo, Phys. Rev. D 67, 022001 (2003).        */
/*                                                                          */
/*                                                                          */
/* COMPILE: gcc -o Vertex3Signals Vertex3Signals.c SpacecraftPositions -lm  */
/*                                                                          */
/****************************************************************************/


/*************************  REQUIRED HEADER FILES  **************************/

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "LISAconstants.h"



/*******************************  STRUCTURES  ******************************/

 /* Tensors */
struct Tensors
{
  double n[3];    /* Unit vector that points to the source */
  double ep[3][3];   /* Basis tensor e^plus */
  double ec[3][3];   /* Basis tensor e^cross */
} tens;


 /* Unit vectors along each arm */
struct UnitVec
{
  double r12;
  double r21;
  double r13;
  double r31;
  double r23;
  double r32;
};


 /* Vertex 3 time structure (tij: time of emission from spacecraft i for a 
    photon that will be received by spacecraft j) */
struct Time
{
  double t3;
  double t13;
  double t31;
  double t23;
  double t32;
  double t13x;
  double t31x;
  double t23x;
  double t32x;
};



/**************  PROTOTYPE DECLARATIONS FOR EXTERNAL FUNCTIONS  *************/

double xPos(double, int);
double yPos(double, int);
double zPos(double, int);



/**************  PROTOTYPE DECLARATIONS FOR INTERNAL FUNCTIONS  *************/

void ConsistencyCheck();
void FileReadSP(char*, int*, double*, double*, double*);
void MichelsonSignal(struct UnitVec*, struct UnitVec*, struct UnitVec*, 
		     struct Time*, double*, double*, double*, long, long, int, 
		     int);
void TDISignal(struct UnitVec*, struct UnitVec*, struct UnitVec*, struct Time*,
	       double*, double*, double*, double*, long, long, int, int);
double deltaell_ij(double, double*, int, int, double*, double*, int, int);
void IndefInt(double*, double*, double, long, char*);
double DefInt(double, double, double*, int, int);
double ell_ij(double, int, int);
void VectorRead(struct UnitVec*, long, char*);
void VertexTimes(struct Time*, long, char*);
void FileWrite(double*, long, char*);
void KILL(char*);



/* ============================  MAIN PROGRAM  ============================ */

int main(void)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Root name for the files */
  char root[50];

 /* Number of data points in each re-sampled section */
  int Ninsec;

 /* Observation time (this does not include padding) */
  double ObsTime;

 /* Polar location of the source in heliocentric-ecliptic coordinates */
  double theta;

 /* Azimuthal location of the source in heliocentric-ecliptic coordinates */
  double phi;

 /* Number of data points in a section with padding */
  long N;

 /* Number of data points in a section without padding */
  long Nsec;

 /* Increment of time between data point for the polarization signals */
  double Dt;

 /* Unit vectors that form the basis tensors */
  double u[3], v[3];

 /* Antiderivatives of h_plus and h_cross */
  double* Hp;
  double* Hc;

 /* Array of unit vector structures, one for each component */
  struct UnitVec* UVx;
  struct UnitVec* UVy;
  struct UnitVec* UVz;

 /* Array of Time structures */
  struct Time* Times;

 /* Time data streams for Michelson and Z signals */
  double* Mike;
  double* TDI;

 /* Filename character array */
  char Filename[50];
  char Xfile[50];
  char Mfile[50];

 /* Loop indexes */
  int a, b;


          /* -------------------  CALCULATIONS  ------------------- */

  printf("\n\n");
  printf("  ______________________________________________________  \n");
  printf(" |                                                      | \n");
  printf(" |              Noiseless Vertex 3 Signals              | \n");
  printf(" |______________________________________________________| \n\n");


 /* Check that none of the LISAconstants.h variables have changed */

  ConsistencyCheck();


 /* Import the source parameters */

  FileReadSP(root, &Ninsec, &theta, &phi, &ObsTime);


 /* Check that the observation for the source is equivalent to the 
    observation time of The LISA Simulator */

  if (fabs(ObsTime-T) > 1.0) KILL("The observation times are not equal.\n");

    sprintf(Xfile, "Binary/Z_%s.bin", root);
    sprintf(Mfile, "Binary/M3_%s.bin", root);

 /* Remove any old signal files */

  remove(Xfile);
  remove(Mfile);

 /* Calculate the components of the unit vector that points to the source */

  tens.n[0] = sin(theta)*cos(phi);
  tens.n[1] = sin(theta)*sin(phi);
  tens.n[2] = cos(theta);


 /* Calculate the components of the basis vectors that will form up the
    basis tensors */

  u[0] = cos(theta)*cos(phi);
  u[1] = cos(theta)*sin(phi);
  u[2] = -sin(theta);

  v[0] = sin(phi);
  v[1] = -cos(phi);
  v[2] = 0.0;


 /* Form the basis tensors e^plus and e^cross */

  for (a = 0 ; a < 3 ; a++)
    for (b = 0 ; b < 3 ; b++)
    {
      tens.ep[a][b] = u[a]*u[b] - v[a]*v[b];
      tens.ec[a][b] = u[a]*v[b] + v[a]*u[b];
    }


 /* Calculate the increment of time between polarization amplitude data 
    points */

  Dt = dt/4.0;


 /* Calculate the number of data points in a section without padding */

  Nsec = (int)ceil(NFFT/Ndiv);

 /* Dynamically allocate memory for the required arrays */
 /* Ninsec is always odd */

  Hp = (double*) malloc (((Ninsec+1)/2)*sizeof(double));
  Hc = (double*) malloc (((Ninsec+1)/2)*sizeof(double));

  if (!Hp || !Hc) KILL("Out of memory.\n");


  N = Nsec + 2*(int)ceil(Tpad/dt);

  UVx = (struct UnitVec*) malloc (N*sizeof(struct UnitVec));
  UVy = (struct UnitVec*) malloc (N*sizeof(struct UnitVec));
  UVz = (struct UnitVec*) malloc (N*sizeof(struct UnitVec));

  if (!UVx || !UVy || !UVz) KILL("Out of memory\n");


  Times = (struct Time*) malloc (Nsec*sizeof(struct Time));

  if (!Times) KILL("Out of memory.\n");


  Mike = (double*) malloc (Nsec*sizeof(double));
  TDI = (double*) malloc (Nsec*sizeof(double));

  if (!Mike || !TDI) KILL("Out of memory.\n");


 /* Calculate the noiseless gravitational wave signals */

  printf("Calculate the noiseless gravitational wave signals.\n\n");


  for (a = 1 ; a <= Ndiv ; a++)
  {

   /* Calculate the antiderivative of the gravitational wave without the
      tensor nature included */

    sprintf(Filename, "Binary/GW%i.dat", a);
    IndefInt(Hp, Hc, Dt, Ninsec, Filename);


    N = (int)ceil(NFFT/Ndiv) + 2*(int)ceil(Tpad/dt);


   /* Import the unit vectors */

    sprintf(Filename, "Binary/UnVcX%i.dat", a);
    VectorRead(UVx, N, Filename);

    sprintf(Filename, "Binary/UnVcY%i.dat", a);
    VectorRead(UVy, N, Filename);

    sprintf(Filename, "Binary/UnVcZ%i.dat", a);
    VectorRead(UVz, N, Filename);


   /* Import the vertex 3 times */

    sprintf(Filename, "Binary/Vert3_%i.dat", a);
    VertexTimes(Times, Nsec, Filename);


   /* Calculate the Michelson signal */

    MichelsonSignal(UVx, UVy, UVz, Times, Hp, Hc, Mike, Nsec, N, Ninsec, a);


   /* Calculate the Z signal */

    TDISignal(UVx, UVy, UVz, Times, Hp, Hc, Mike, TDI, Nsec, N, Ninsec, a);


   /* Turn the time data series into unitless strains */

    for(b = 0 ; b < Nsec ; b++)
    {
      Mike[b] *= 1.0/(2.0*L);
      TDI[b] *= 1.0/(2.0*L);
    }


   /* Write the time data series to file */

    FileWrite(Mike, Nsec, Mfile);
    FileWrite(TDI, Nsec, Xfile);


   /* User update */

    printf("  Section %i out of %i is now complete.\n", a, (int)Ndiv);
  }


 /* Free the allocated memory */

  free(Hp);
  free(Hc);

  free(UVx);
  free(UVy);
  free(UVz);

  free(Times);

  free(Mike);
  free(TDI);


  printf("\n----------------------------------------------------------\n");
  printf("The program is now complete.\n\n\n");


  return 0;
}

/* ======================================================================== */





/***************************  INTERNAL FUNCTIONS  ***************************/

void FileReadSP(char* root, int* Ninsec, double* theta, double* phi, 
		double* ObsTime)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Error message character array */
  char ErrorMessage[100];

 /* Filename charater array */
  char* Filename;

 /* File pointer */
  FILE* SPin;


          /* -------------------  CALCULATIONS  ------------------- */

 /* Open an ASCII formatted file */

  Filename = "Binary/SourceParameters.dat";

  if ((SPin = fopen(Filename, "r")) == NULL)
  {
    sprintf(ErrorMessage, "Cannot open the file %s.\n", Filename);
    KILL(ErrorMessage);
  }


 /* Write the source parameters to the file */

  fscanf(SPin, "%s\n", root);
  fscanf(SPin, "%i\n", Ninsec);
  fscanf(SPin, "%lg\n", theta);
  fscanf(SPin, "%lg\n", phi);
  fscanf(SPin, "%lg\n", ObsTime);


 /* Close the file */

  fclose(SPin);


  return;
}





void MichelsonSignal(struct UnitVec* UVx, struct UnitVec* UVy, 
		     struct UnitVec* UVz, struct Time* Times, double* Hp, 
		     double* Hc, double* Mike, long Nsec, long N, int Ninsec, 
		     int Section)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Time of photon emmision from spacecraft 3 */
  double t31, t32;

 /* Time of "reflection" at spacecraft 1 and 2 */
  double t13, t23;

 /* Initial time for a section */
  double ts;

 /* Interpolation time interval */
  double DT;

 /* Bin number in the UnVc array that contain the time t */
  long Bin;

 /* Phase difference due to the passage of the gravitational wave as measured 
    at spacecraft j */
  double Phi31, Phi13, Phi32, Phi23;

 /* Interpolated unit vector */
  double rij[3];

 /* Loop index */
  long a;


          /* -------------------  CALCULATIONS  ------------------- */

 /* Calculate the starting time for the section */

  ts = T0 + dt*( (double)(Section-1)*ceil(NFFT/Ndiv)-ceil(Tpad/dt) ) + dt/2.0;


 /* Calculate the phase differences measured at each spacecraft */

  for (a = 0 ; a < Nsec ;  a++)
  {

   /* Phi_13 */

    t13 = Times[a].t13;

      /* Find what bin t13 is in */

    Bin = (int)floor(t13/dt) - (int)floor(ts/dt);

    if (Bin < 0 || Bin >= N) 
      KILL("Requested array access is out of bounds.\n");

      /* Linearly interpolate the components of r_13 at time t13 */

    DT = t13 - dt*floor(t13/dt);

    rij[0] = ((UVx[Bin+1].r13-UVx[Bin].r13)/dt)*DT + UVx[Bin].r13;
    rij[1] = ((UVy[Bin+1].r13-UVy[Bin].r13)/dt)*DT + UVy[Bin].r13;
    rij[2] = ((UVz[Bin+1].r13-UVz[Bin].r13)/dt)*DT + UVz[Bin].r13;

      /* Retrieve the phase difference measured at spacecraft 3 at time t */

    Phi13 = deltaell_ij(t13, rij, 1, 3, Hp, Hc, Ninsec, Section);


   /* Phi_31 */

    t31 = Times[a].t31;

      /* Find what bin t31 is in */

    Bin = (int)floor(t31/dt) - (int)floor(ts/dt);

    if (Bin < 0 || Bin >= N) 
      KILL("Requested array access is out of bounds.\n");

      /*  Linearly interpolate the components of r_31 at time t31 */

    DT = t31 - dt*floor(t31/dt);

    rij[0] = ((UVx[Bin+1].r31-UVx[Bin].r31)/dt)*DT + UVx[Bin].r31;
    rij[1] = ((UVy[Bin+1].r31-UVy[Bin].r31)/dt)*DT + UVy[Bin].r31;
    rij[2] = ((UVz[Bin+1].r31-UVz[Bin].r31)/dt)*DT + UVz[Bin].r31;

      /* Retrieve the phase difference measured at spacecraft 1 at time t13 */

    Phi31 = deltaell_ij(t31, rij, 3, 1, Hp, Hc, Ninsec, Section);


   /* Phi_23 */

    t23 = Times[a].t23;

      /* Find what bin t23 is in */

    Bin = (int)floor(t23/dt) - (int)floor(ts/dt);

    if (Bin < 0 || Bin >= N) 
      KILL("Requested array access is out of bounds.\n");

      /*  Linearly interpolate the components of r_23 at time t23 */

    DT = t23 - dt*floor(t23/dt);

    rij[0] = ((UVx[Bin+1].r23-UVx[Bin].r23)/dt)*DT + UVx[Bin].r23;
    rij[1] = ((UVy[Bin+1].r23-UVy[Bin].r23)/dt)*DT + UVy[Bin].r23;
    rij[2] = ((UVz[Bin+1].r23-UVz[Bin].r23)/dt)*DT + UVz[Bin].r23;

      /* Retrieve the phase difference measured at spacecraft 3 at time t */

    Phi23 = deltaell_ij(t23, rij, 2, 3, Hp, Hc, Ninsec, Section);


   /* Phi_32 */

    t32 = Times[a].t32;

      /* Find what bin t32 is in */

    Bin = (int)floor(t32/dt) - (int)floor(ts/dt);

    if (Bin < 0 || Bin >= N) 
      KILL("Requested array access is out of bounds.\n");

      /*  Linearly interpolate the components of r_32 at time t32 */

    DT = t32 - dt*floor(t32/dt);

    rij[0] = ((UVx[Bin+1].r32-UVx[Bin].r32)/dt)*DT + UVx[Bin].r32;
    rij[1] = ((UVy[Bin+1].r32-UVy[Bin].r32)/dt)*DT + UVy[Bin].r32;
    rij[2] = ((UVz[Bin+1].r32-UVz[Bin].r32)/dt)*DT + UVz[Bin].r32;

      /* Retrieve the phase difference measured at spacecraft 2 at time t23 */

    Phi32 = deltaell_ij(t32, rij, 3, 2, Hp, Hc, Ninsec, Section);


   /* Form the Michelson signal */

    Mike[a] = Phi31 + Phi13 - Phi32 - Phi23;
  }


  return;
}





void TDISignal(struct UnitVec* UVx, struct UnitVec* UVy, struct UnitVec* UVz, 
	       struct Time* Times, double* Hp, double* Hc, double* Mike, 
	       double* TDI, long Nsec, long N, int Ninsec, int Section)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Z signal times */
  double t31x, t32x, t13x, t23x;

 /* Initial time for a section */
  double ts;

 /* Interpolation time interval */
  double DT;

 /* Bin number in the UnVc array that contain the time t */
  long Bin;

 /* Phase difference due to the passage of the gravitational wave as measured 
    at spacecraft j */
  double Phi31, Phi13, Phi32, Phi23;

 /* Interpolated unit vector */
  double rij[3];

 /* Loop index */
  long a;


          /* -------------------  CALCULATIONS  ------------------- */

 /* Calculate the starting time for the section */

  ts = T0+dt*( (double)(Section-1)*ceil(NFFT/Ndiv)-ceil(Tpad/dt) ) + dt/2.0;


 /* Calculate the phase differences measured at each spacecraft */

  for (a = 0 ; a < Nsec ;  a++)
  {

   /* Phi_13 */

    t13x = Times[a].t13x;

      /* Find what bin t13x is in */

    Bin = (int)floor(t13x/dt) - (int)floor(ts/dt);

    if (Bin < 0 || Bin >= N) 
      KILL("Requested array access is out of bounds.\n");

      /* Linearly interpolate the components of r_13 at time t13x */

    DT = t13x - dt*floor(t13x/dt);

    rij[0] = ((UVx[Bin+1].r13-UVx[Bin].r13)/dt)*DT + UVx[Bin].r13;
    rij[1] = ((UVy[Bin+1].r13-UVy[Bin].r13)/dt)*DT + UVy[Bin].r13;
    rij[2] = ((UVz[Bin+1].r13-UVz[Bin].r13)/dt)*DT + UVz[Bin].r13;

      /* Retrieve the phase difference measured at spacecraft 3 at time t32 */

    Phi13 = deltaell_ij(t13x, rij, 1, 3, Hp, Hc, Ninsec, Section);


   /* Phi_31 */

    t31x = Times[a].t31x;

      /* Find what bin t31x is in */

    Bin = (int)floor(t31x/dt) - (int)floor(ts/dt);

    if (Bin < 0 || Bin >= N) 
      KILL("Requested array access is out of bounds.\n");

      /*  Linearly interpolate the components of r_31 at time t31x */

    DT = t31x - dt*floor(t31x/dt);

    rij[0] = ((UVx[Bin+1].r31-UVx[Bin].r31)/dt)*DT + UVx[Bin].r31;
    rij[1] = ((UVy[Bin+1].r31-UVy[Bin].r31)/dt)*DT + UVy[Bin].r31;
    rij[2] = ((UVz[Bin+1].r31-UVz[Bin].r31)/dt)*DT + UVz[Bin].r31;

      /* Retrieve the phase difference measured at spacecraft 1 at time t13x */

    Phi31 = deltaell_ij(t31x, rij, 3, 1, Hp, Hc, Ninsec, Section);


   /* Phi_23 */

    t23x = Times[a].t23x;

      /* Find what bin t23x is in */

    Bin = (int)floor(t23x/dt) - (int)floor(ts/dt);

    if (Bin < 0 || Bin >= N) 
      KILL("Requested array access is out of bounds.\n");

      /*  Linearly interpolate the components of r_23 at time t23x */

    DT = t23x - dt*floor(t23x/dt);

    rij[0] = ((UVx[Bin+1].r23-UVx[Bin].r23)/dt)*DT + UVx[Bin].r23;
    rij[1] = ((UVy[Bin+1].r23-UVy[Bin].r23)/dt)*DT + UVy[Bin].r23;
    rij[2] = ((UVz[Bin+1].r23-UVz[Bin].r23)/dt)*DT + UVz[Bin].r23;

      /* Retrieve the phase difference measured at spacecraft 3 at time t31 */

    Phi23 = deltaell_ij(t23x, rij, 2, 3, Hp, Hc, Ninsec, Section);


   /* Phi_32 */

    t32x = Times[a].t32x;

     /* Find what bin t32x is in */

    Bin = (int)floor(t32x/dt) - (int)floor(ts/dt);

    if (Bin < 0 || Bin >= N) 
      KILL("Requested array access is out of bounds.\n");

     /*  Linearly interpolate the components of r_32 at time t32x */

    DT = t32x - dt*floor(t32x/dt);

    rij[0] = ((UVx[Bin+1].r32-UVx[Bin].r32)/dt)*DT + UVx[Bin].r32;
    rij[1] = ((UVy[Bin+1].r32-UVy[Bin].r32)/dt)*DT + UVy[Bin].r32;
    rij[2] = ((UVz[Bin+1].r32-UVz[Bin].r32)/dt)*DT + UVz[Bin].r32;

     /* Retrieve the phase difference measured at spacecraft 2 at time t23x */

    Phi32 = deltaell_ij(t32x, rij, 3, 2, Hp, Hc, Ninsec, Section);


   /* Form the time delay interferometer signal */

    TDI[a] = Mike[a] - Phi31 - Phi13 + Phi32 + Phi23;
  }


  return;
}





double deltaell_ij(double t, double* rij, int i, int j, double* Hp, 
		   double* Hc, int Ninsec, int Section)
{

          /* ------------  DECLARATION OF VARIABLES  ------------ */

 /* Coordinate distance between spacecraft i and spacecraft j */
  double ell;

 /* Unit vector in the propagation direction of the photon */
  double r_ij[3];

 /* Dot product between the unit position vector for the source and the unit
    propagation direction of the photon */
  double ndotr_ij;

 /* Wave variables xi_i and xi_j */
  double xi_i, xi_j;

 /* Antiderivative of the gravitational wave tensor */
  double H[3][3];

 /* Antiderivative coefficients */
  double Hplus, Hcross;

 /* Variation in the optical path length due to the gravitational wave */
  double deltaell;

 /* Loop indexes */
  int a, b;


          /* ------------------  CALCULATIONS  ------------------ */

 /* Calculate the distance between the i and j spacecraft */

  ell = ell_ij(t,i,j);


 /* Contract the n-hat vector with the unit vector that points along the 
    photon propagation direction */

  ndotr_ij = tens.n[0]*rij[0] + tens.n[1]*rij[1] + tens.n[2]*rij[2];


 /* Calculate the wave variable values */

  xi_i = t + ( tens.n[0]*xPos(t,i) + tens.n[1]*yPos(t,i) 
                                               + tens.n[2]*zPos(t,i) ) / c;

  xi_j = t+ell/c + ( tens.n[0]*xPos(t+ell/c,j) 
		                         + tens.n[1]*yPos(t+ell/c,j)
		                         + tens.n[2]*zPos(t+ell/c,j) ) / c;


 /* Form the antiderivative of the gravitational wave in full tensor form */

  Hplus = DefInt(xi_i, xi_j, Hp, Ninsec, Section);
  Hcross = DefInt(xi_i, xi_j, Hc, Ninsec, Section);

  for (a = 0 ; a < 3 ; a++)
    for (b = 0 ; b < 3 ; b++)
      H[a][b] = Hplus*tens.ep[a][b] + Hcross*tens.ec[a][b];


 /* Calculate the variation in the optical path length due to the passing
    gravitational wave */

  deltaell = 0.0;

  for (a = 0 ; a < 3 ; a++)
    for (b = 0 ; b < 3 ; b++) deltaell += rij[a]*rij[b]*H[a][b];

  deltaell *= c/(2.0*(1.0+ndotr_ij));


  return deltaell;
}





void IndefInt(double* Hp, double* Hc, double Dt, long N, char* Filename)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* h_plus and h_cross in the helioframe */
  double* hp;
  double* hc;

 /* Error message character array */
  char ErrorMessage[100];

 /* Loop index */
  long a;

 /* File pointer */
  FILE* AmpsIn;


          /* -------------------  CALCULATIONS  ------------------- */

 /* Dynamically allocate the memory for the polarization signals */

  hp = (double*) malloc (N*sizeof(double));
  hc = (double*) malloc (N*sizeof(double));

  if (!hp || !hc) KILL("Out of memory!\n");


 /* Import the polarization signals */

     /* Open a binary formatted file */

  if ((AmpsIn = fopen(Filename, "rb")) == NULL)
  {
    sprintf(ErrorMessage, "Cannot open the file %s.\n", Filename);
    KILL(ErrorMessage);
  }

     /* Read in the file */

  for (a = 0 ; a < N ; a++)
  {
    fread(&hp[a], sizeof(double), 1, AmpsIn);
    fread(&hc[a], sizeof(double), 1, AmpsIn);
  }

     /* Close the file */

  fclose(AmpsIn);


 /* Integrate the polarization signals and store the accumlated areas into 
    two arrays */

  Hp[0] = 0.0;
  Hc[0] = 0.0;

  for (a = 0 ; a < (int)ceil(N/2.)-1 ; a++)
  {
    Hp[a+1] = Hp[a] + (Dt/3.0)*(hp[2*a]+4.0*hp[2*a+1]+hp[2*a+2]);
    Hc[a+1] = Hc[a] + (Dt/3.0)*(hc[2*a]+4.0*hc[2*a+1]+hc[2*a+2]);
  }


 /* Free the allocated memory */

  free(hp);
  free(hc);


  return;
}





double DefInt(double xi_i, double xi_j, double* H, int Ninsec, int Section)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Initial time for a section */
  double ts;

 /* Increment of time between data point for the polarization signals */
  double Dt;

 /* Bin number that contains xi_i */
  long B_i;

 /* Bin number that contains xi_j */
  long B_j;

 /* Interpolation time intervals */
  double DT;

  double dti, dtj;

 /* Interpolated values of H */
  double H_i, H_j;

 /* Definite integral of h_plus or h_cross between xi_i and xi_j */
  double Area;


          /* -------------------  CALCULATIONS  ------------------- */

 /* Calculate the increment of time between polarization amplitude data 
    points */

  Dt = dt/4.0;


 /* Calculate the starting time for the section */
 /* Note: Interpolated hp, hc have same start and end times as
    their un-interpolated predecessors */

  ts = T0+dt*( (double)(Section-1)*ceil(NFFT/Ndiv) ) - dt*(ceil(Tpad/dt))+dt/2.0;


 /* Find the bin numbers that contain the values of xi_i and xi_j */

  B_i = (int)floor(xi_i/(2.*Dt)) - (int)floor(ts/(2.*Dt));
  B_j = (int)floor(xi_j/(2.*Dt)) - (int)floor(ts/(2.*Dt));


 /* Evaluate the definite integral between xi_i and xi_j */

  dti = xi_i - 2.0*Dt*floor(xi_i/(2.0*Dt));
  dtj = xi_j - 2.0*Dt*floor(xi_j/(2.0*Dt));

  H_i = ((H[B_i+1]-H[B_i])/(2.*Dt))*dti + H[B_i];
  H_j = ((H[B_j+1]-H[B_j])/(2.*Dt))*dtj + H[B_j];

  Area = H_j - H_i;


  return Area;
}





double ell_ij(double t, int i, int j)
{

          /* ------------  DECLARATION OF VARIABLES  ------------ */

 /* Coordinate distance between spacecraft i and spacecraft j */
  double ell;

 /* Distance spacecraft j moves relative to its position in the previous
    iteration */
  double delta;

 /* Light travel time of the photon from the previous iteration */
  double pltt;


          /* ------------------  CALCULATIONS  ------------------ */

 /* Initial guess to the distance between spacecraft i and spacecraft j */

  ell = L;


 /* Solve iteratively the actual distance between the spacecraft.  Note that 
    our cutoff is set for when the calcualted distance between iterations 
    does not change by more than a meter */

  do
  {
    pltt = ell/c;

    ell = sqrt ( pow(xPos(t+ell/c,j)-xPos(t,i),2)
		                         + pow(yPos(t+ell/c,j)-yPos(t,i),2)
		                         + pow(zPos(t+ell/c,j)-zPos(t,i),2) );

    delta = sqrt ( pow(xPos(t+ell/c,j) - xPos(t+pltt,j),2)
                                  + pow(yPos(t+ell/c,j) - yPos(t+pltt,j),2)
                                  + pow(zPos(t+ell/c,j) - zPos(t+pltt,j),2) );

  } while ( delta >= 1.0 );


  return ell;
}





void VectorRead(struct UnitVec* UnVc, long N, char* Filename)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Error message character array */
  char ErrorMessage[100];

 /* Loop index */
  int a;

 /* File pointer */
  FILE* VecIn;


          /* -------------------  CALCULATIONS  ------------------- */

 /* Open a binary formatted file */

  if ((VecIn = fopen(Filename, "rb")) == NULL)
  {
    sprintf(ErrorMessage, "Cannot open the file %s.\n", Filename);
    KILL(ErrorMessage);
  }


 /* Read in the file */

  for (a = 0 ; a < N ; a++)
    fread(&UnVc[a], sizeof(struct UnitVec), 1, VecIn);


 /* Close the file */

  fclose(VecIn);


  return;
}





void VertexTimes(struct Time* Times, long Nsec, char* Filename)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Error message character array */
  char ErrorMessage[100];

 /* Loop index */
  int a;

 /* File pointer */
  FILE* TimeIn;


          /* -------------------  CALCULATIONS  ------------------- */

 /* Open a binary formatted file */

  if ((TimeIn = fopen(Filename, "rb")) == NULL)
  {
    sprintf(ErrorMessage, "Cannot open the file %s.\n", Filename);
    KILL(ErrorMessage);
  }


 /* Read in the file */

  for (a = 0 ; a < Nsec ; a++)
    fread(&Times[a], sizeof(struct Time), 1, TimeIn);


 /* Close the file */

  fclose(TimeIn);


  return;
}





void FileWrite(double* TDS, long Nsec, char* Filename)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Error message character array */
  char ErrorMessage[100];

 /* Loop index */
  int a;

 /* File pointer */
  FILE* SignalOut;


          /* -------------------  CALCULATIONS  ------------------- */

 /* Open a binary formatted file */

  if ((SignalOut = fopen(Filename, "ab")) == NULL)
  {
    sprintf(ErrorMessage, "Cannot open the file %s.\n", Filename);
    KILL(ErrorMessage);
  }


 /* Write to the file in binary format */

  for (a = 0 ; a < Nsec ; a++) fwrite(&TDS[a], sizeof(double), 1, SignalOut);


 /* Close the file */

  fclose(SignalOut);


  return;
}





void ConsistencyCheck()
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Power of 2 which gives the number of data points to be FFTed */
  int npow_old;

 /* Observation length */
  double T_old;

 /* Number of sections to divide the observation length into */
  int Ndiv_old;

 /* Initial azimuthal position of the guiding center in the ecliptic plane */
  double kappa_old;

 /* Initial orientation of the LISA spacecraft */
  double lambda_old;

 /* Orbital radius of the guiding center */
  double Rgc_old;

 /* Mean arm length of the LISA detector */
  double L_old;

 /* File pointer */
  FILE* CheckIn;


          /* -------------------  CALCULATIONS  ------------------- */

 /* Open an ASCII formatted file */

  if ((CheckIn = fopen("Binary/Setup.dat", "r")) == NULL)
    KILL("Cannot open the file Binary/Setup.dat.\n");


 /* Read in the file */

  fscanf(CheckIn, "%i\n", &npow_old);
  fscanf(CheckIn, "%lg\n", &T_old);
  fscanf(CheckIn, "%i\n", &Ndiv_old);
  fscanf(CheckIn, "%lg\n", &kappa_old);
  fscanf(CheckIn, "%lg\n", &lambda_old);
  fscanf(CheckIn, "%lg\n", &Rgc_old);
  fscanf(CheckIn, "%lg\n", &L_old);


 /* Close the file */

  fclose(CheckIn);


 /* Check that nothing has changed */

  if (npow_old != npow)
    KILL("The value of npow has changed in the LISAconstants.h file.\n");

  if (T_old != T)
    KILL("The value of T has changed in the LISAconstants.h file.\n");

  if (Ndiv_old != Ndiv)
    KILL("The value of Ndiv has changed in the LISAconstants.h file.\n");

  if (kappa_old != kappa)
    KILL("The value of kappa has changed in the LISAconstants.h file.\n");

  if (lambda_old != lambda)
    KILL("The value of lambda has changed in the LISAconstants.h file.\n");

  if (Rgc_old != Rgc)
    KILL("The value of Rgc has changed in the LISAconstants.h file.\n");

  if (L_old != L)
    KILL("The value of L has changed in the LISAconstants.h file.\n");


  return;
}





void KILL(char* Message)
{
  printf("\a\n");
  printf(Message);
  printf("Terminating the program.\n\n");
  exit(1);


  return;
}
