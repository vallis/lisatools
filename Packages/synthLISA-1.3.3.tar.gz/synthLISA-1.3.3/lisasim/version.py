version_full = """Id: lisasim-lisa.cpp 392 2006-12-17 11:29:01Z vallis 
Id: 
Id: lisasim-signal.cpp 386 2006-12-17 11:24:10Z vallis 
Id: lisasim-tdi.cpp 389 2006-12-17 11:27:09Z vallis 
Id: lisasim-tdinoise.cpp 318 2006-06-01 01:09:29Z vallis 
Id: lisasim-tdisignal.cpp 380 2006-11-05 20:18:51Z vallis 
Id: lisasim-tens.cpp 256 2005-12-02 02:08:20Z vallis 
Id: lisasim-wave.cpp 250 2005-11-30 00:23:55Z vallis 
Id: lisasim-except.h 393 2006-12-17 11:29:24Z vallis 
Id: lisasim-lisa.h 378 2006-11-05 20:06:11Z vallis 
Id: lisasim-retard.h 377 2006-11-05 20:01:28Z vallis 
Id: lisasim-signal.h 349 2006-07-27 17:51:26Z vallis 
Id: lisasim-tdi.h 391 2006-12-17 11:27:58Z vallis 
Id: lisasim-tdinoise.h 318 2006-06-01 01:09:29Z vallis 
Id: lisasim-tdisignal.h 366 2006-08-28 18:48:27Z vallis 
Id: lisasim-tens.h 256 2005-12-02 02:08:20Z vallis 
Id: lisasim-wave.h 250 2005-11-30 00:23:55Z vallis 
Id: lisasim.h 227 2005-11-15 21:55:15Z vallis 
Id: __init__.py 361 2006-08-17 18:22:21Z vallis 
Id: convertunit.py 370 2006-08-28 18:52:58Z vallis 
Id: lisautils.py 388 2006-12-17 11:26:16Z vallis 
Id: lisaxml.py 363 2006-08-28 18:41:45Z vallis """

version_short = "1.3.3"

