#!/usr/bin/env python
#------------------------------------------------------------------------------
# Copyright (c) 2006, Enthought, Inc.
# All rights reserved.
# 
# This software is provided without warranty under the terms of the BSD
# license included in enthought/LICENSE.txt and may be redistributed only
# under the conditions described in the aforementioned license.  The license
# is also available online at http://www.enthought.com/licenses/BSD.txt
# Thanks for using Enthought open source!
# 
# Author: Enthought, Inc.
# Description: <Enthought library component>
#------------------------------------------------------------------------------

import os
import sys
from os.path import join
import glob

from scipy_distutils.core          import setup
from scipy_distutils.dist          import Distribution
from scipy_distutils.misc_util     import get_subpackages, dict_append, get_path
from scipy_distutils.misc_util     import merge_config_dicts, default_config_dict
from scipy_distutils.command.build import build as buildcmd
from scipy_distutils.command.build_ext import build_ext

from distutils.command.install_lib import install_lib as installcmd

ext_modules = ["kiva/agg/setup_agg.py",
               "freetype/setup_freetype.py",
               "interpolate/setup_interpolate.py",
               "util/setup_util.py",
               "traits/setup_traits.py",
               "tvtk/setup_tvtk.py",
               "chaco/setup_chaco.py"
              ]

# We have to snoop for file types that distutils doesn't copy correctly when
# doing a non-build-in-place.
EXTS = ['.conf', '.css', '.dtd', '.gif', '.jpg', '.html',
        '.js',   '.mo',  '.png', '.pt', '.stx', '.ref',
        '.txt',  '.xml', '.zcml', '.mar', '.in', '.pyd',
        '.c', '.cpp', '.h', '.a', '.o', '.ttf', '.txt',
        '.i', '', '.co', '.ico', '.TXT', '.mk', '.mm',
        '.doc', '.bmp', '.dsp', '.dat', '.mms', 'ufo'
         ]


def data_files_here(install_path, local_path, *directories):
    """ Return a suitable entry for data_files given a directory to copy into
    the package directory.

    For now, it ignores subdirectories.
    """
    args = (local_path,) + directories + ('*',)
    files = [x for x in glob.glob(os.path.join(*args)) 
             if os.path.isfile(x)]
    args = (install_path,) + directories
    return (os.path.join(*args), files)

def configuration(parent_package='',parent_path=None):
    package_name = 'enthought'
    local_path = get_path(__name__,parent_path)
    config = default_config_dict(package_name, parent_package)    
        
    install_path = join(*config['name'].split('.'))
    entries = join(local_path,'.svn','entries')
    if os.path.isfile(entries):
        config['data_files'].append((join(install_path,'.svn'),[entries]))

    config['data_files'].extend([
        data_files_here(install_path, local_path, 'enable', 'om', 'images'),
        data_files_here(install_path, local_path,
            'envisage', 'project', 'images'),
        data_files_here(install_path, local_path,
            'envisage', 'project', 'action', 'images'),
        data_files_here(install_path, local_path,
            'envisage', 'project', 'view', 'images'),
        data_files_here(install_path, local_path,
            'envisage', 'project', 'wizard', 'images'),
        data_files_here(install_path, local_path,
            'envisage', 'resource', 'images'),
        data_files_here(install_path, local_path,
            'envisage', 'single_project', 'images'),
        data_files_here(install_path, local_path,
            'envisage', 'examples', 'plugin', 'simple_ui', 'action', 'images'),
        data_files_here(install_path, local_path, 'graph', 'vpl', 'images'),
        data_files_here(install_path, local_path, 'kiva', 'pil_fonts'),
        data_files_here(install_path, local_path, 'component', 'images'),
        data_files_here(install_path, local_path, 'naming', 'ui', 'images'),
        data_files_here(install_path, local_path, 'pyface', 'images'),
        data_files_here(install_path, local_path, 'pyface', 'action', 'images'),
        data_files_here(install_path, local_path, 'pyface', 'tree', 'images'),
        data_files_here(install_path, local_path, 'traits', 'images'),
        data_files_here(install_path, local_path, 'traits', 'ui', 'wx', 'images'),
        data_files_here(install_path, local_path, 'traits', 'vet', 'images'),
    ])

    config_list = [config]
    config_list += get_ext_configs_from_setups(ext_modules)        
    config = merge_config_dicts(config_list)

    return config


def get_ext_configs_from_setups(sources, args=None):
    """ Gets extension config dicts from setup_xxx.py
    
    usage: get_ext_configs_from_setups([sources])
    
    With new structure, extension modules are the only directories that
    need a setup_xxx.py file.
    """
    
    old_path = os.getcwd()
    sys.path.insert(0,old_path)

    path = get_path(__name__)

    # check for actual source location in case we're in a sub-dir
    #good_sources = get_ext_setup_path(sources)
    
    config_list = []

    for src in sources:
        print "    Getting configs for: %s" % src
        src_path = os.path.join(path,src)
        src_base = os.path.basename(src)
        src_package = os.path.splitext(src_base)[0]
        new_path = os.path.join(path,os.path.split(src)[0])

        try:
            parent_package = dot_join(*os.path.split(src)[0].split('\\'))
        except:
            parent_package = ''

        sys.path.insert(0,os.path.dirname(src_path))

        try:
            exec 'import %s as info_module' \
                 % (os.path.splitext(src_base)[0])
            if not getattr(info_module,'ignore',0):
                exec 'import %s as setup_module' % (src_package)

                config = setup_module.configuration(parent_package = parent_package)
                config_list.append(config)
        finally:
            del sys.path[0]
            os.chdir(old_path)

    return config_list



# Distutils hook classes
class MyBuilder(buildcmd):
    def run(self):
        os.path.walk(os.curdir, remove_stale_bytecode, None)
        buildcmd.run(self)
        finder.copy_files(self, self.build_lib)

class MyExtBuilder(build_ext):
    # Override the default build_ext to remove stale bytecodes.
    # Technically, removing bytecode has nothing to do with
    # building extensions, but this is needed for inplace builds
    def run(self):
        os.path.walk(os.curdir, remove_stale_bytecode, None)
        build_ext.run(self)

class MyLibInstaller(installcmd):
    def run(self):
        installcmd.run(self)
        finder.copy_files(self, self.install_dir)

class MyDistribution(Distribution):
    # To control the selection of MyLibInstaller and MyPyBuilder, we
    # have to set it into the cmdclass instance variable, set in
    # Distribution.__init__().
    def __init__(self, *attrs):
        Distribution.__init__(self, *attrs)
        self.cmdclass['build'] = MyBuilder
        self.cmdclass['build_ext'] = MyExtBuilder
        self.cmdclass['install_lib'] = MyLibInstaller

class Finder:
    """ Finder class creates object that walks file system
    
        This class serves multiple purposes.  It walks the file system looking for
        auxiliary files that distutils doesn't install properly, and it actually
        copies those files (when hooked into by distutils).  It also walks the file
        system looking for candidate packages for distutils to install as normal.
        The key here is that the package must have an __init__.py file. (as seen in
        Zope3 setup.py)--this is a change from the requirement that there be a 
        setup_xxx.py isn't it.
        """
        
    def __init__(self, exts, prefix):
        self._files = []
        self._pkgs = {}
        self._exts = exts
        self.ignored_exts = {}
        # We're finding packages in lib/python in the source dir, but we're
        # copying them directly under build/lib.<plat>.  So we need to lop off
        # the prefix when calculating the package names from the file names.
        self._plen = len(prefix)

    def visit(self, ignore, dir, files):
        # for debugging, I'm interested in exts not included in copy       
        
        # ignore uninteresting dirs
        if dir.split("\\")[0] == 'build' or '.svn' in dir.split("\\") or 'CVS' in dir.split("\\"):
            return
        for file in files:
            # First see if this is one of the packages we want to add, or if
            # we're really skipping this package.
            if '__init__.py' in files:
                aspkg = dir[self._plen:].replace(os.sep, '.')
                self._pkgs[aspkg] = True
            # Add any extra files we're interested in
            base, ext = os.path.splitext(file)

            if ext in self._exts:
                # make sure file isn't directory (in the case of '' in EXT list)
                if not os.path.isdir(os.path.join(dir, file)):
                    self._files.append(os.path.join(dir, file))
            else:
                # just get list of ignored extensions for grins
                ext_only = ext.replace('.','')
                if self.ignored_exts.has_key(ext_only):
                    self.ignored_exts[ext_only] = self.ignored_exts[ext_only] + 1
                else:
                    self.ignored_exts[ext_only] = 1
                   

    def copy_files(self, cmd, outputbase):
        for file in self._files:
            dest = os.path.join(outputbase, file[self._plen:])
            # Make sure the destination directory exists
            dir = os.path.dirname(dest)
            if not os.path.exists(dir):
                dir_util.mkpath(dir)
            cmd.copy_file(file, dest)

    def get_packages(self):
        return self._pkgs.keys()



def remove_stale_bytecode(arg, dirname, names):
    names = map(os.path.normcase, names)
    for name in names:
        if name.endswith(".pyc") or name.endswith(".pyo"):
            srcname = name[:-1]
            if srcname not in names:
                fullname = os.path.join(dirname, name)
                print "Removing stale bytecode file", fullname
                os.unlink(fullname)

def setup_package():
    old_path = os.getcwd()
    local_path = os.path.dirname(os.path.abspath(sys.argv[0]))
    os.chdir(local_path)

    from enthought_version import enthought_version

    try:
        setup(version=enthought_version,
              distclass=MyDistribution,
              maintainer="Enthought, Inc",
              maintainer_email="info@enthought.com",
              description="Enthought Tool Suite",
              license="Copyright 2003-2006, Enthought, Inc.",
              url="http://code.enthought.com",
              **configuration(parent_path='')
              )
    finally:
        os.chdir(old_path)
    return

basedir = ''  # could root this elsewhere
finder = Finder(EXTS, basedir)
os.path.walk(basedir, finder.visit, None)
pkgs = finder.get_packages()
print '   Ignoring extensions %s' % finder.ignored_exts

if __name__ == '__main__':
    setup_package()
