/****************************************************************************/
/*                                                                          */
/* TITLE: Unit Vectors Along The Photon Trajectories                        */
/* AUTHORS: Louis J. Rubbo and Neil J. Cornish                              */
/* DATE: June 22, 2006                                                      */
/* VERSION: 2.1.1                                                           */
/*                                                                          */
/*                                                                          */
/* ABSTRACT: This program calculates the unit vectors that point along the  */
/* photon trajectories of the LISA constellation of spacecraft.             */
/*                                                                          */
/*                                                                          */
/* COMPILE: gcc -o UnitVectors UnitVectors.c SpacecraftPositions.c -lm      */
/*                                                                          */
/****************************************************************************/


/*************************  REQUIRED HEADER FILES  **************************/

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "LISAconstants.h"



/*******************************  STRUCTURES  *******************************/

 /* Unit vectors along each arm */
struct UnitVec
{
  double r12;
  double r21;
  double r13;
  double r31;
  double r23;
  double r32;
};



/**************  PROTOTYPE DECLARATIONS FOR EXTERNAL FUNCTIONS  *************/

double xPos(double, int);
double yPos(double, int);
double zPos(double, int);



/**************  PROTOTYPE DECLARATIONS FOR INTERNAL FUNCTIONS  *************/

double ell_ij(double, int, int);
void FileWrite(struct UnitVec*, long, char*);
void KILL(char*);



/* ============================  MAIN PROGRAM  ============================ */

int main(void)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Time (seconds) */
  double t;

 /* Number of data points in a section with padding included */
  long N;

 /* Unit vector that point from spacecraft i to spacecraft j */
  double rij[3];

 /* Coordinate distance bewteen spacecraft i and j */
  double ell;

 /* Array of unit vector structures for each component */
  struct UnitVec* UVx;
  struct UnitVec* UVy;
  struct UnitVec* UVz;

 /* Loop indexes */
  long a, b;

 /* Filename character array */
  char Filename[50];


          /* -------------------  CALCULATIONS  ------------------- */

  printf("\n\n");
  printf("  ______________________________________________________  \n");
  printf(" |                                                      | \n");
  printf(" |         LISA's Photon Trajectory Unit Vectors        | \n");
  printf(" |______________________________________________________| \n\n");


 /* Calculate the number of data points within a section */

  N = (int)ceil(NFFT/Ndiv) + 2*(int)ceil(Tpad/dt);


 /* Dynamically allocate the memory for the unit vector components */

  UVx = (struct UnitVec*) malloc (N*sizeof(struct UnitVec));
  UVy = (struct UnitVec*) malloc (N*sizeof(struct UnitVec));
  UVz = (struct UnitVec*) malloc (N*sizeof(struct UnitVec));

  if (!UVx || !UVy || !UVz) KILL("Out of memory!\n");


 /* Calculate the components of the unit vectors and save the results to an
    array of structures */

  printf("Calculating the components of the unit vectors.\n\n");

  for (a = 1 ; a <= Ndiv ; a++)
  {
    t = dt*( (double)(a-1)*ceil(NFFT/Ndiv) - ceil(Tpad/dt) ) +dt/2.0;

    for (b = 0 ; b < N ; b++)
    {

     /* Calculate the unit vector components ... */

         /* from spacecraft 1 towards spacecraft 2 */
      
      ell = ell_ij(t,1,2);
      UVx[b].r12 = (xPos(t+ell/c,2) - xPos(t,1)) / ell;
      UVy[b].r12 = (yPos(t+ell/c,2) - yPos(t,1)) / ell;
      UVz[b].r12 = (zPos(t+ell/c,2) - zPos(t,1)) / ell;
    

        /* from spacecraft 2 towards spacecraft 1 */

      ell = ell_ij(t,2,1);
      UVx[b].r21 = (xPos(t+ell/c,1) - xPos(t,2)) / ell;
      UVy[b].r21 = (yPos(t+ell/c,1) - yPos(t,2)) / ell;
      UVz[b].r21 = (zPos(t+ell/c,1) - zPos(t,2)) / ell;


        /* from spacecraft 1 towards spacecraft 3 */

      ell = ell_ij(t,1,3);
      UVx[b].r13 = (xPos(t+ell/c,3) - xPos(t,1)) / ell;
      UVy[b].r13 = (yPos(t+ell/c,3) - yPos(t,1)) / ell;
      UVz[b].r13 = (zPos(t+ell/c,3) - zPos(t,1)) / ell;


        /* from spacecraft 3 towards spacecraft 1 */

      ell = ell_ij(t,3,1);
      UVx[b].r31 = (xPos(t+ell/c,1) - xPos(t,3)) / ell;
      UVy[b].r31 = (yPos(t+ell/c,1) - yPos(t,3)) / ell;
      UVz[b].r31 = (zPos(t+ell/c,1) - zPos(t,3)) / ell;


        /* from spacecraft 2 towards spacecraft 3 */
      
      ell = ell_ij(t,2,3);
      UVx[b].r23 = (xPos(t+ell/c,3) - xPos(t,2)) / ell;
      UVy[b].r23 = (yPos(t+ell/c,3) - yPos(t,2)) / ell;
      UVz[b].r23 = (zPos(t+ell/c,3) - zPos(t,2)) / ell;


        /* from spacecraft 3 towards spacecraft 2 */

      ell = ell_ij(t,3,2);
      UVx[b].r32 = (xPos(t+ell/c,2) - xPos(t,3)) / ell;
      UVy[b].r32 = (yPos(t+ell/c,2) - yPos(t,3)) / ell;
      UVz[b].r32 = (zPos(t+ell/c,2) - zPos(t,3)) / ell;


     /* Increment the time */

      t += dt;
    }


   /* Write the section information to file */

       /* x component */

    sprintf(Filename, "Binary/UnVcX%i.dat", a);
    FileWrite(UVx, N, Filename);


       /* y component */

    sprintf(Filename, "Binary/UnVcY%i.dat", a);
    FileWrite(UVy, N, Filename);


       /* z component */

    sprintf(Filename, "Binary/UnVcZ%i.dat", a);
    FileWrite(UVz, N, Filename);


   /* User update */

    printf("  Section %i out of %i is now complete.\n", a, (int)Ndiv);
  }


 /* Free the allocated memory */

  free(UVx);
  free(UVy);
  free(UVz);


  printf("\n----------------------------------------------------------\n");
  printf("The program is now complete.\n\n\n");


  return 0;
}

/* ======================================================================== */





/***************************  INTERNAL FUNCTIONS  ***************************/

double ell_ij(double t, int i, int j)
{

          /* ------------  DECLARATION OF VARIABLES  ------------ */

 /* Coordinate distance a photon travels */
  double ell;

 /* Distance spacecraft j moves relative to its position in the previous
    iteration */
  double delta;

 /* Light travel time of the photon from the previous iteration */
  double pltt;


          /* ------------------  CALCULATIONS  ------------------ */

 /* Initial guess to the distance between spacecraft i and spacecraft j */

  ell = L;


 /* Solve iteratively the actual distance between the spacecraft.  Note that 
    our cutoff is set for when the calcualted distance between iterations 
    does not change by more than a meter */

  do
  {
    pltt = ell/c;

    ell = sqrt ( pow(xPos(t+ell/c,j)-xPos(t,i),2)
		                         + pow(yPos(t+ell/c,j)-yPos(t,i),2)
		                         + pow(zPos(t+ell/c,j)-zPos(t,i),2) );

    delta = sqrt ( pow(xPos(t+ell/c,j) - xPos(t+pltt,j),2)
                                  + pow(yPos(t+ell/c,j) - yPos(t+pltt,j),2)
                                  + pow(zPos(t+ell/c,j) - zPos(t+pltt,j),2) );

  } while ( delta >= 1.0 );


  return ell;
}





void FileWrite(struct UnitVec* UV, long N, char* Filename)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Error message character array */
  char ErrorMessage[100];

 /* Loop index */
  int a;

 /* File pointer */
  FILE* VecOut;


          /* -------------------  CALCULATIONS  ------------------- */

 /* Open a binary formatted file */

  if ((VecOut = fopen(Filename, "wb")) == NULL)
  {
    sprintf(ErrorMessage, "Cannot open the file %s.\n", Filename);
    KILL(ErrorMessage);
  }


 /* Write to file in binary format */

  for (a = 0 ; a < N ; a++) fwrite(&UV[a], sizeof(struct UnitVec), 1, VecOut);


 /* Close file */

  fclose(VecOut);


  return;
}





void KILL(char* Message)
{
  printf("\a\n");
  printf(Message);
  printf("Terminating the program.\n\n");
  exit(1);


  return;
}
