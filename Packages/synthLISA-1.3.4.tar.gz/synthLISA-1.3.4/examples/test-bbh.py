#!/usr/bin/env python

from synthlisa import *
from numpy.oldnumeric import transpose
import lisawp

import math

# creates a standard LISA geometry object

lisa = EccentricInclined(0.0,1.5*math.pi,-1)

# creates a PNBinary object; the calling syntax is
# PNBinary(m1, m2, f0, phi0, dist, theta, elat, elon, pol,
#          deltat=10, prebuffer=650)

mysystem = lisawp.PNBinary(1e6,2e6,8e-5,0,1e9,0,0,0,0)

signalTDI = TDIsignal(lisa,mysystem)

stime = 30.0
samples = 2**20

# what is the time to coalescence for this object?

ctime = lisawp.PNBinaryCoalescenceTime(1e6,2e6,8e-5)

print "Estimated time to coalescence = %s s = %s y." % (ctime,ctime/(samples*stime))
print "Waveform will be zero-padded after that."

# get the TDI variables

[t,Xm,Ym,Zm] = transpose(getobs(samples,stime,[signalTDI.t,
                                                       signalTDI.Xm,
                                                       signalTDI.Ym,
                                                       signalTDI.Zm]))

# create output XML file

outputXML = lisaXML('data/bbh',
                    author='Michele Vallisneri',
                    comments="PN binary from Stas' code")

# dump LISA data

outputXML.LISAData(lisa)

# dump 

outputXML.SourceData(mysystem,name='(1e6+2e6)Msun PN binary')

outputXML.TDIData(transpose([t,Xm,Ym,Zm]),samples,stime,'t,Xf,Yf,Zf')

outputXML.close()
