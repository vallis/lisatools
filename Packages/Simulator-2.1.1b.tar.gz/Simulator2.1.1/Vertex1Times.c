/****************************************************************************/
/*                                                                          */
/* TITLE: Vertex 1 TDI Times                                                */
/* AUTHORS: Louis J. Rubbo and Neil J. Cornish                              */
/* DATE: June 22, 2006                                                      */
/* VERSION: 2.1.1                                                           */
/*                                                                          */
/*                                                                          */
/* ABSTRACT: This program calculates the times that are required to         */
/* simulate the Michelson and X signals out of the #1 spacecraft.           */
/*                                                                          */
/*                                                                          */
/* COMPILE: gcc -o Vertex1Times Vertex1Times.c SpacecraftPositions.c -lm    */
/*                                                                          */
/****************************************************************************/


/*************************  REQUIRED HEADER FILES  **************************/

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "LISAconstants.h"



/*******************************  STRUCTURES  *******************************/

 /* Vertex 1 time structure (tij: time of emission from spacecraft i for a 
    photon that will be received by spacecraft j) */
struct Time
{
  double t1;
  double t21;
  double t12;
  double t31;
  double t13;
  double t21x;
  double t12x;
  double t31x;
  double t13x;
};



/**************  PROTOTYPE DECLARATIONS FOR EXTERNAL FUNCTIONS  *************/

double xPos(double, int);
double yPos(double, int);
double zPos(double, int);



/**************  PROTOTYPE DECLARATIONS FOR INTERNAL FUNCTIONS  *************/

double ell_ij(double, int, int);
void FileWrite(struct Time*, long, int);
void ConsistencyCheck();
void KILL(char*);



/* ============================  MAIN PROGRAM  ============================ */

int main(void)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Helio-time; time of reception back at spacecraft #1 (seconds) */
  double t;

  /* time at spacecraft corresponding to t in Barycenter */
  double t1;

 /* Michelson times */
  double t12, t13, t21, t31;

 /* X times (the complete set of X times is the Michelson times plus these */
  double t12x, t13x, t21x, t31x;

 /* Reception time from previous iteration (seconds) */
  double pt;

 /* Change in time from previous iteration (seconds) */
  double delta;

 /* Number of data points in a section without padding */
  long Nsec;

 /* Array of time structures */
  struct Time* Times;

 /* Loop indexes */
  long a, b;


          /* -------------------  CALCULATIONS  ------------------- */

  printf("\n\n");
  printf("  ______________________________________________________  \n");
  printf(" |                                                      | \n");
  printf(" |                    Vertex 1 Times                    | \n");
  printf(" |______________________________________________________| \n\n");


 /* Write an ASCII formatted file that contains the LISAconstants.h 
    variables used for producing the Vertex1Times.c */

  ConsistencyCheck();


 /* Calculate the number of data points within a section */

  Nsec = (int)ceil(NFFT/Ndiv);


 /* Dynamically allocate the memory for the Time array of structures */

  Times = (struct Time*) malloc (Nsec*sizeof(struct Time));

  if (!Times) KILL("Out of memory!\n");


 /* Calulate the vertex 1 times and save them into an array of structures */

  printf("Calculating the vertex 1 times.\n\n");

  for(a = 1 ; a <= Ndiv ; a++)
  {
    t = dt*(double)(a-1)*ceil(NFFT/Ndiv)+dt/2.0;

    for (b = 0 ; b < Nsec ; b++)
    {

      t1 = t;

      Times[b].t1 = t1;

         /* Michelson times */

     /* t21: the time of emission for a photon leaving spacecraft 2 and
	traveling towards spacecraft 1 */

      t21 = t1 - L/c;
      do
      {
	pt = t21;
	t21 = t1 - ell_ij(t21,2,1)/c;
	delta = fabs(t21-pt);
      } while ( delta >= pow(10,-5) );

      Times[b].t21 = t21;


     /* t12 (t12 < t21): the time of emission for a photon leaving spacecraft 
	1 and traveling towards spacecraft 2 */

      t12 = t21 - L/c;
      do
      {
	pt = t12;
	t12 = t21 - ell_ij(t12,1,2)/c;
	delta = fabs(t12-pt);
      } while ( delta >= pow(10,-5) );

      Times[b].t12 = t12;


     /* t31: the time of emission for a photon leaving spacecraft 3 and
	traveling towards spacecraft 1 */

      t31 = t1 - L/c;
      do
      {   
	pt = t31;
	t31 = t1 - ell_ij(t31,3,1)/c;
	delta = fabs(t31-pt);
      } while ( delta >= pow(10,-5) );

      Times[b].t31 = t31;


     /* t13 (t13 < t31): the time of emission for a photon leaving spacecraft 
	1 and traveling towards spacecraft 3 */

      t13 = t31 - L/c;
      do
      {   
	pt = t13;
	t13 = t31 - ell_ij(t13,1,3)/c;
	delta = fabs(t13-pt);
      } while ( delta >= pow(10,-5) );

      Times[b].t13 = t13;


         /* X times */

      t21x = t13 - L/c;
      do
      {   
	pt = t21x;
	t21x = t13 - ell_ij(t21x,2,1)/c;
	delta = fabs(t21x-pt);
      } while ( delta >= pow(10,-5) );

      Times[b].t21x = t21x;


      t31x = t12 - L/c;
      do
      {   
	pt = t31x;
	t31x = t12 - ell_ij(t31x,3,1)/c;
	delta = fabs(t31x-pt);
      } while ( delta >= pow(10,-5) );

      Times[b].t31x = t31x;


      t12x = t21x - L/c;
      do
      {   
	pt = t12x;
	t12x = t21x - ell_ij(t12x,1,2)/c;
	delta = fabs(t12x-pt);
      } while ( delta >= pow(10,-5) );

      Times[b].t12x = t12x;


      t13x = t31x - L/c;
      do
      {   
	pt = t13x;
	t13x = t31x - ell_ij(t13x,1,3)/c;
	delta = fabs(t13x-pt);
      } while ( delta >= pow(10,-5) );

      Times[b].t13x = t13x;


     /* Increment the time */

      t += dt;
    }


   /* Write the section information to file */

    FileWrite(Times, Nsec, a);


   /* User update */

    printf("  Section %i out of %i is now complete.\n", a, (int)Ndiv);
  }


 /* Free the allocated memory */

  free(Times);


  printf("\n----------------------------------------------------------\n");
  printf("The program is now complete.\n\n\n");


  return 0;
}

/* ======================================================================== */





/***************************  INTERNAL FUNCTIONS  ***************************/

double ell_ij(double t, int i, int j)
{

          /* ------------  DECLARATION OF VARIABLES  ------------ */

 /* Coordinate distance between spacecraft i and spacecraft j */
  double ell;

 /* Distance spacecraft j moves relative to its position in the previous
    iteration */
  double delta;

  /* Light travel time of the photon from the previous iteration */
  double pltt;


          /* ------------------  CALCULATIONS  ------------------ */

 /* Initial guess to the distance between spacecraft i and spacecraft j */

  ell = L;


 /* Solve iteratively the actual distance between the spacecraft.  Note that 
    our cutoff is set for when the calcualted distance between iterations 
    does not change by more than a meter */

  do
  {
    pltt = ell/c;

    ell = sqrt ( pow(xPos(t+ell/c,j)-xPos(t,i),2)
		                         + pow(yPos(t+ell/c,j)-yPos(t,i),2)
		                         + pow(zPos(t+ell/c,j)-zPos(t,i),2) );

    delta = sqrt ( pow(xPos(t+ell/c,j) - xPos(t+pltt,j),2)
                                  + pow(yPos(t+ell/c,j) - yPos(t+pltt,j),2)
                                  + pow(zPos(t+ell/c,j) - zPos(t+pltt,j),2) );

  } while ( delta >= 1.0 );


  return ell;
}





void FileWrite(struct Time* Times, long Nsec, int Section)
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* Error message character array */
  char ErrorMessage[100];

 /* Filename character array */
  char Filename[50];

 /* Loop index */
  int a;

 /* File pointer */
  FILE* TimeOut;


          /* -------------------  CALCULATIONS  ------------------- */

 /* Open a binary formatted file */

  sprintf(Filename, "Binary/Vert1_%i.dat", Section);

  if ((TimeOut = fopen(Filename, "wb")) == NULL)
  {
    sprintf(ErrorMessage, "Cannot open the file %s.\n", Filename);
    KILL(ErrorMessage);
  }


 /* Write to file in binary format */

  for (a = 0 ; a < Nsec ; a++)
    fwrite(&Times[a], sizeof(struct Time), 1, TimeOut);


 /* Close the file */

  fclose(TimeOut);


  return;
}





void ConsistencyCheck()
{

          /* -------------  DECLARATION OF VARIABLES  ------------- */

 /* File pointer */
  FILE* CheckOut;


          /* -------------------  CALCULATIONS  ------------------- */

 /* Open an ASCII formatted file */

  if ((CheckOut = fopen("Binary/Setup.dat", "w")) == NULL)
    KILL("Cannot open the file Binary/Setup.dat.\n");


 /* Write to file */

  fprintf(CheckOut, "%i\n", npow);
  fprintf(CheckOut, "%.12g\n", T);
  fprintf(CheckOut, "%i\n", Ndiv);
  fprintf(CheckOut, "%g\n", kappa);
  fprintf(CheckOut, "%g\n", lambda);
  fprintf(CheckOut, "%.12g\n", Rgc);
  fprintf(CheckOut, "%.12g\n", L);


 /* Close the file */

  fclose(CheckOut);


  return;
}





void KILL(char* Message)
{
  printf("\a\n");
  printf(Message);
  printf("Terminating the program.\n\n");
  exit(1);


  return;
}
