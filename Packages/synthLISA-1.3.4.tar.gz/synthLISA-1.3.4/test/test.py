#!/usr/bin/env python

import unittest

# assert_, assertEqual, assertNotEqual, assertRaises(exception, func, args), fail()

import synthlisa
import numpy

class SampledSignalTest(unittest.TestCase):
    def setUp(self):
        self.length = 20
        self.a = numpy.array(range(self.length),'d')
    
    def test_reproduce(self):
        # test interpolation on the sampled points

        for myfilter in (None,synthlisa.NoFilter()):
            for interp in range(0,5):
                s = synthlisa.SampledSignal(self.a,1,buffer = 16,norm = 1.0,filter = myfilter,interplen = interp,timeoffset = 0.0)
                self.assertEqual(0.0,sum(abs( self.a - numpy.array([s(t) for t in range(self.length)],'d') )))

    def test_interpolate_minimal(self):
        # test interpolation (length 1) between sampled points

        for myfilter in (None,synthlisa.NoFilter()):
            s = synthlisa.SampledSignal(self.a,1,buffer = 16,norm = 1.0,filter = myfilter,interplen = 1,timeoffset = 0.0)
            self.assertEqual(0.0,sum(abs( numpy.array(range(2*self.length-2),'d') * 0.5 - numpy.array([s(0.5*t) for t in range(2*self.length-2)],'d') )))

    def test_before_and_after(self):
        # test zeros before timeoffset

        for myfilter in (None,synthlisa.NoFilter()):
            for time in (0.0,-10.0,10.0):
                s = synthlisa.SampledSignal(self.a + 1.0,1,buffer = 16,norm = 1.0,filter = myfilter,interplen = 1,timeoffset = time)

                self.assertEqual(0.0,s(time - 2.0))
                self.assertEqual(0.0,s(time - 1.0))
                self.assertEqual(0.5,s(time - 0.5)) # half of 1.0 and 0.0
                self.assertEqual(1.0,s(time + 0.0))

            # test zeros after end of array
        
            for time in (0.0,-10.0,10.0):
                s = synthlisa.SampledSignal(self.a + 1.0,1,buffer = 16,norm = 1.0,filter = myfilter,interplen = 1,timeoffset = time)

                self.assertEqual(0.0,            s(time + (self.length - 1) + 2.0))
                self.assertEqual(0.0,            s(time + (self.length - 1) + 1.0))
                self.assertEqual(0.5*self.length,s(time + (self.length - 1) + 0.5))
                self.assertEqual(1.0*self.length,s(time + (self.length - 1) + 0.0))

    def test_buffer(self):
        print "--- Don't worry, the following error messages are expected in the unit test! ---"

        # note that buffer has no meaning if the array-based SampledSignal is not filtered...

        for time in (0.0,-10.0,10.0):
            s = synthlisa.SampledSignal(self.a,1,buffer = self.length / 2,norm = 1.0,filter = synthlisa.NoFilter(),interplen = 1,timeoffset = time)
            
            b = [s(time + t) for t in range(self.length)]

            self.assertRaises(IndexError,s,time)
            self.assertRaises(IndexError,s,time + self.length/2)


if __name__ == '__main__':
    unittest.main()
