#!/bin/sh
# Use of a while loop to read sources.txt file
cat sources.txt |   \
while read line
do
      ./GWconverter $line
      ./Vertex1Signals
      ./Vertex2Signals
      ./Vertex3Signals
done

