#------------------------------------------------------------------------------
# Copyright (c) 2005, Enthought, Inc.
# All rights reserved.
# 
# This software is provided without warranty under the terms of the BSD
# license included in enthought/LICENSE.txt and may be redistributed only
# under the conditions described in the aforementioned license.  The license
# is also available online at http://www.enthought.com/licenses/BSD.txt
# Thanks for using Enthought open source!
# 
# Author: Enthought, Inc.
# Description: <Enthought logger package component>
#------------------------------------------------------------------------------
""" 
Usage example:

>>> from enthought.logger import logger
>>>
>>> logger.debug('excruciating detail')
>>> logger.info('all systems returned to normal')
>>> logger.warn('it looks a bit dodgy')
>>> logger.error('aaaaaaaggggghhhhh!!')
>>> logger.critical('as bad as it gets') 
>>> logger.exception('use this in an except: block')

"""

# Standard library imports.
import sys, os
import logging
import logging.handlers

# Enthought library imports.
from enthought.util.home_directory import get_home_directory
from enthought.logger.log_queue_handler import log_queue_handler
#from enthought.logger.custom_excepthook import custom_excepthook

# create a reference to the logger that we will be using ... 
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

# All uncaught exceptions are intercepted by this handler before they can
# be sent to stderr by the regular 
#sys.excepthook = custom_excepthook

# Redirect stderr into the logging system
#sys.stderr = logger

formatter = logging.Formatter('%(levelname)s|%(asctime)s|%(message)s')

# Logs to the specified files.
log_file = os.path.join(get_home_directory(), 'envisage.log')
handler = logging.handlers.RotatingFileHandler(log_file, maxBytes=1000000, 
                                               backupCount = 3)
handler.setFormatter(formatter)
logger.addHandler(handler) 

# create a log queue in order to retrreive the logs later
logger_queue = log_queue_handler
logger_queue.setFormatter(formatter)
logger_queue.setLevel(logging.DEBUG)
logging.getLogger().addHandler(logger_queue)


#### EOF ######################################################################
