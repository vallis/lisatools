#-------------------------------------------------------------------------------
#  
#  Implements the DockWindowFeature base class.
#  
#  A DockWindowFeature is an optional feature of a DockControl that can be
#  dynamically contributed to the package. Whenever a DockControl is added to
#  a DockWindow, each feature will be given the opportunity to add itself to
#  the DockControl.
#  
#  Each feature is manifested as an image that appears on the DockControl tab
#  (or drag bar). The user interacts wth the feature using mouse clicks and
#  drag and drop operations (depending upon how the feature is implemented).
#  
#  Written by: David C. Morrill
#  
#  Date: 07/03/2006
#  
#  (c) Copyright 2006 by Enthought, Inc.
#  
#-------------------------------------------------------------------------------

#-------------------------------------------------------------------------------
#  Imports:
#-------------------------------------------------------------------------------

import wx

from weakref \
    import ref
    
from enthought.traits.api \
    import HasPrivateTraits, Instance, Int, Str, Property
    
from enthought.util.wx.do_later \
    import do_later
    
from dock_window \
    import DockWindow
    
from dock_sizer \
    import DockControl, add_feature
    
from enthought.pyface.image_resource \
    import ImageResource
    
#-------------------------------------------------------------------------------
#  'DockWindowFeature' class:
#-------------------------------------------------------------------------------

class DockWindowFeature ( HasPrivateTraits ):
    
    #---------------------------------------------------------------------------
    #  Class variables:  
    #---------------------------------------------------------------------------

    # The user interface name of the feature (must be overridden in sub-class
    # if feature is to be hidden/shown via the DockWindow context menu):
    feature_name = ''
    
    # Current feature state (0 = uninstalled, 1 = active, 2 = disabled):
    state = 0
    
    # List of weak references to all current instances:
    instances = []
    
    #---------------------------------------------------------------------------
    #  Trait definitions:  
    #---------------------------------------------------------------------------

#-- Public Traits --------------------------------------------------------------

    # The DockControl this feature is associated with:
    dock_control = Instance( DockControl )
    
#-- Public Traits (new defaults can be defined by subclasses) ------------------

    # The current image to display on the DockControl tab:
    tab_image = Instance( ImageResource, allow_none = True )
    
    # The current (optional) image to display on the DockControl drag bar:
    bar_image = Instance( ImageResource, allow_none = True )
    
    # The tooltip to display when the mouse is hovering over the image:
    tooltip = Str
    
    # The (x,y) coordinate of an event:
    x = Int
    y = Int
    
#-- Private Traits -------------------------------------------------------------

    # The current bitmap to display on the DockControl tab:
    tab_bitmap = Property

    # The current (optional) bitmap to display on the DockControl drag bar:
    bar_bitmap = Property    
   
#-- Overridable Public Methods -------------------------------------------------

    #---------------------------------------------------------------------------
    #  Handles the user left clicking on the feature image:    
    #---------------------------------------------------------------------------
    
    def left_click ( self ):
        """ Handles the user left clicking on the feature image.
        """
        return
        
    #---------------------------------------------------------------------------
    #  Handles the user right clicking on the feature image:    
    #---------------------------------------------------------------------------
    
    def right_click ( self ):
        """ Handles the user right clicking on the feature image.
        """
        return

    #---------------------------------------------------------------------------
    #  Returns the object to be dragged when the user drags the feature image:
    #---------------------------------------------------------------------------
    
    def drag ( self ):
        """ Returns the object to be dragged when the user drags the feature 
            image.
        """
        return None

    #---------------------------------------------------------------------------
    #  Returns the object to be dragged when the user drags the feature image
    #  while holding down the 'Ctrl' key:
    #---------------------------------------------------------------------------
    
    def control_drag ( self ):
        """ Returns the object to be dragged when the user drags the feature
            image while holding down the 'Ctrl' key:
        """
        return None
        
    #---------------------------------------------------------------------------
    #  Returns the object to be dragged when the user drags the feature image
    #  while holding down the 'Shift' key:
    #---------------------------------------------------------------------------
    
    def shift_drag ( self ):
        """ Returns the object to be dragged when the user drags the feature 
            image while holding down the 'Shift' key.
        """
        return None

    #---------------------------------------------------------------------------
    #  Returns the object to be dragged when the user drags the feature image
    #  while holding down the 'Alt' key:
    #---------------------------------------------------------------------------
    
    def alt_drag ( self ):
        """ Returns the object to be dragged when the user drags the feature
            image while holding down the 'Alt' key:
        """
        return None

    #---------------------------------------------------------------------------
    #  Handles the user dropping a specified object on the feature image:
    #---------------------------------------------------------------------------

    def drop ( self, object ):
        """ Handles the user dropping a specified object on the feature image.
        """
        return
        
    #---------------------------------------------------------------------------
    #  Returns whether a specified object can be dropped on the feature image:  
    #---------------------------------------------------------------------------
 
    def can_drop ( self, object ):
        """ Returns whether a specified object can be dropped on the feature 
            image.
        """
        return False
        
    #---------------------------------------------------------------------------
    #  Performs any clean-up needed when the feature is being removed:  
    #---------------------------------------------------------------------------
    
    def dispose ( self ):
        """ Performs any clean-up needed when the feature is being removed.
        """
        pass

#-- Public Methods -------------------------------------------------------------

    #---------------------------------------------------------------------------
    #  Displays a pop-up menu:    
    #---------------------------------------------------------------------------
                
    def popup_menu ( self, menu ):
        """ Displays a pop-up menu.
        """
        window = self.dock_control.control.GetParent()
        window.PopupMenuXY( menu.create_menu( window, self ), 
                            self.x - 10, self.y - 10 )
                            
    #---------------------------------------------------------------------------
    #  Refreshes the display of the feature image:  
    #---------------------------------------------------------------------------

    def refresh ( self, layout = False ):
        """ Refreshes the display of the feature image.
        """
        dc = self.dock_control
        if dc.control is not None:
            if layout:
                dc._tab_width = None
                dc._layout( True )
            else:
                dc.control.GetParent().RefreshRect( wx.Rect( *dc.drag_bounds ) ) 
            
    #---------------------------------------------------------------------------
    #  Disables the feature:  
    #---------------------------------------------------------------------------

    def disable ( self, layout = True ):
        """ Disables the feature.
        """
        self._tab_image = self.tab_image
        self._bar_image = self.bar_image
        self.tab_image  = self.bar_image = None
        self.dock_control._tab_width = None
        if layout:
            try:
                do_later( 
                    self.dock_control.control.GetParent().owner.update_layout )
            except wx.PyDeadObjectError:
                pass
            
    #---------------------------------------------------------------------------
    #  Enables the feature:  
    #---------------------------------------------------------------------------

    def enable ( self, layout = True ):
        """ Enables the feature.
        """
        self.tab_image  = self._tab_image
        self.bar_image  = self._bar_image
        self._tab_image = self._bar_image = None
        self.dock_control._tab_width = None
        if layout:
            try:
                do_later( 
                    self.dock_control.control.GetParent().owner.update_layout )
            except wx.PyDeadObjectError:
                pass

#-- Overidable Class Methods ---------------------------------------------------

    #---------------------------------------------------------------------------
    #  Returns a single new feature object or list of new feature objects for a
    #  specified DockControl (or None if the feature does not apply to it):
    #---------------------------------------------------------------------------
    
    def feature_for ( cls, dock_control ):
        """ Returns a single new feature object or list of new feature objects
            for a specified DockControl (or None if the feature does not apply 
            to it).
        """
        if cls.is_feature_for( dock_control):
            return cls.new_feature( dock_control )
            
        return None
        
    feature_for = classmethod( feature_for )
            
    #---------------------------------------------------------------------------
    #  Returns a new feature instance for a specified DockControl:  
    #---------------------------------------------------------------------------

    def new_feature ( cls, dock_control ):
        """ Returns a new feature instance for a specified DockControl.
        """
        return cls( dock_control = dock_control )
        
    new_feature = classmethod( new_feature )
        
    #---------------------------------------------------------------------------
    #  Returns whether or not the DockWindowFeature is a valid feature for a 
    #  specified DockControl:  
    #---------------------------------------------------------------------------

    def is_feature_for ( self, dock_control ):
        """ Returns whether or not the DockWindowFeature is a valid feature for 
            a specified DockControl.
        """
        return True
        
    is_feature_for = classmethod( is_feature_for )

#-- Public Class Methods -------------------------------------------------------

    #---------------------------------------------------------------------------
    #  Returns a feature object for use with the specified DockControl (or None 
    #  if the feature does not apply to the DockControl object):   
    #---------------------------------------------------------------------------

    def new_feature_for ( cls, dock_control ):
        """ Returns a feature object for use with the specified DockControl (or
            None if the feature does not apply to the DockControl object).
        """
        result = cls.feature_for( dock_control )
        if result is not None:
            cls.instances = [ aref for aref in cls.instances 
                                   if aref() is not None ]
            if isinstance( result, DockWindowFeature ):
                result = [ result ]
            cls.instances.extend( [ ref( feature ) for feature in result ] )
            
        return result
        
    new_feature_for = classmethod( new_feature_for )
 
    #---------------------------------------------------------------------------
    #  Toggles the feature on/off:  
    #---------------------------------------------------------------------------

    def toggle_feature ( cls, event ):
        """ Toggles the feature on/off.
        """
        if cls.state == 0:
            cls.state = 1
            add_feature( cls )
            for control in event.window.control.GetChildren():
                window = getattr( control, 'owner', None )
                if isinstance( window, DockWindow ):
                    do_later( window.update_layout )
        else:
            method    = 'disable'
            cls.state = 3 - cls.state
            if cls.state == 1:
                method = 'enable'
            cls.instances = [ aref for aref in cls.instances 
                                   if aref() is not None ]
            for aref in cls.instances:
                feature = aref()
                if feature is not None:
                    getattr( feature, method )()
                               
    toggle_feature = classmethod( toggle_feature )

#-- Event Handlers -------------------------------------------------------------

    #---------------------------------------------------------------------------
    #  Handles the 'tab_image' trait being changed:  
    #---------------------------------------------------------------------------

    def _tab_image_changed ( self ):
        self._tab_bitmap = None
        
    #---------------------------------------------------------------------------
    #  Handles the 'bar_image' trait being changed:  
    #---------------------------------------------------------------------------

    def _bar_image_changed ( self ):
        self._bar_bitmap = None

#-- Property Implementations ---------------------------------------------------
    
    def _get_tab_bitmap ( self ):
        if (self._tab_bitmap is None) and (self.tab_image is not None):
            self._tab_bitmap = self.tab_image.create_image().ConvertToBitmap()
                
        return self._tab_bitmap
    
    def _get_bar_bitmap ( self ):
        if (self._bar_bitmap is None) and (self.bar_image is not None):
            self._bar_bitmap = self.bar_image.create_image().ConvertToBitmap()
                
        return self._bar_bitmap

#-- Pyface menu interface implementation ---------------------------------------
            
    #---------------------------------------------------------------------------
    #  Adds a menu item to the menu bar being constructed:    
    #---------------------------------------------------------------------------
                            
    def add_to_menu ( self, menu_item ):
        """ Adds a menu item to the menu bar being constructed.
        """
        pass
        
    #---------------------------------------------------------------------------
    #  Adds a tool bar item to the tool bar being constructed:    
    #---------------------------------------------------------------------------
                
    def add_to_toolbar ( self, toolbar_item ):
        """ Adds a tool bar item to the tool bar being constructed.
        """
        pass
        
    #---------------------------------------------------------------------------
    #  Returns whether the menu action should be defined in the user interface:
    #---------------------------------------------------------------------------
        
    def can_add_to_menu ( self, action ):
        """ Returns whether the action should be defined in the user interface.
        """
        return True
        
    #---------------------------------------------------------------------------
    #  Returns whether the toolbar action should be defined in the user 
    #  interface:
    #---------------------------------------------------------------------------
        
    def can_add_to_toolbar ( self, action ):
        """ Returns whether the toolbar action should be defined in the user 
            interface.
        """
        return True
        
    #---------------------------------------------------------------------------
    #  Performs the action described by a specified Action object:    
    #---------------------------------------------------------------------------
                
    def perform ( self, action ):
        """ Performs the action described by a specified Action object.
        """
        action = action.action
        if action[ : 5 ] == 'self.':
            eval( action, globals(), { 'self': self } )
        else:
            getattr( self, action )()
    
