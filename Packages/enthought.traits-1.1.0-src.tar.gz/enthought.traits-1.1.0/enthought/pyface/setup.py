#!/usr/bin/env python
minimum_numpy_version = '0.9.7.2467'
def configuration(parent_package='enthought',top_path=None):
    import numpy
    if numpy.__version__ < minimum_numpy_version:
        raise RuntimeError, 'numpy version %s or higher required, but got %s'\
              % (minimum_numpy_version, numpy.__version__)

    from numpy.distutils.misc_util import Configuration
    config = Configuration('pyface',parent_package,top_path)
    config.set_options(ignore_setup_xxx_py=True,
                       assume_default_configuration=True,
                       delegate_options_to_subpackages=True,
                       quiet=True)

    config.add_subpackage('*')
    config.add_subpackage('*.*')

    map(config.add_data_dir,
        ['action/images','doc','dock/demos','dock/images',
         'examples','grid/images','grid/tests','images','sheet/tests',
         'sheet/swig_interface','tree/images'])
    
    return config

if __name__ == "__main__":
    from numpy.distutils.core import setup
    setup(version='1.1.0',
           description  = 'Traits capable windowing framework',
           author       = 'Enthought, Inc',
           author_email = 'info@enthought.com',
           url          = 'http://code.enthought.com/ets',
           license      = 'BSD',
           configuration=configuration)
