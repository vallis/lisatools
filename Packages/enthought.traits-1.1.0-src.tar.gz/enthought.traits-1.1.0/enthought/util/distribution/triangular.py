#------------------------------------------------------------------------------
# Copyright (c) 2005, Enthought, Inc.
# All rights reserved.
# 
# This software is provided without warranty under the terms of the BSD
# license included in enthought/LICENSE.txt and may be redistributed only
# under the conditions described in the aforementioned license.  The license
# is also available online at http://www.enthought.com/licenses/BSD.txt
# Thanks for using Enthought open source!
# 
# Author: Enthought, Inc.
# Description: <Enthought util package component>
#------------------------------------------------------------------------------
#-------------------------------------------------------------------------------
#  Imports:
#-------------------------------------------------------------------------------

from enthought.traits  import Trait, TraitRange, TraitGroup
from distribution      import Distribution
from scipy             import clip, stats

#-------------------------------------------------------------------------------
#  'Triangular' class:
#-------------------------------------------------------------------------------

class Triangular ( Distribution ):
    """ A triangular distribution. """

    __editable_traits__ = TraitGroup( 'low', 'mid', 'high', style = 'text' )

    def __init__ ( self, low_bound, high_bound, **traits ):
        Distribution.__init__( self, low_bound, high_bound )
        
        mid_point = (low_bound + high_bound) / 2

        self.add_trait('low',  Trait(low_bound, TraitRange(low_bound, high_bound )))
        self.add_trait('mid',  Trait(mid_point, TraitRange(low_bound, high_bound )))
        self.add_trait('high', Trait(high_bound, TraitRange(low_bound, high_bound )))
        self.set( **traits )
        self.fill_color = ( 199.0/255.0, 255.0/255.0, 183.0/255.0, 0.6 )
        
    def clone ( self ):
        return Triangular( self.low_bound, self.high_bound ).set( 
                           low  = self.low, 
                           mid  = self.mid, 
                           high = self.high )

    def generate ( self, n = 500 ):
        """ Generates 'n' values in the distribution. """

        start  = self.low
        width  = self.high - self.low
        ratio  = (self.mid - self.low) / width
        result = stats.triang( ratio, start, width, size = n )
        if self.high_bound is None:
           return max( result, self.low_bound )
        return clip( result, self.low_bound, self.high_bound )
        
    def plot_value ( self ):
        
        from enthought.chaco.plot_value import PlotValue

        return PlotValue( [ [ self.low_bound,  0.0 ],
                            [ self.low,        0.0 ],
                            [ self.mid,        1.0 ],
                            [ self.high,       0.0 ],
                            [ self.high_bound, 0.0 ] ], 
                            type       = 'polygon',
                            fill_color = self.fill_color )
                            
