#------------------------------------------------------------------------------
# Copyright (c) 2005, Enthought, Inc.
# All rights reserved.
# 
# This software is provided without warranty under the terms of the BSD
# license included in enthought/LICENSE.txt and may be redistributed only
# under the conditions described in the aforementioned license.  The license
# is also available online at http://www.enthought.com/licenses/BSD.txt
# Thanks for using Enthought open source!
# 
# Author: David C. Morrill
# Date: 10/21/2004
# Description: Define the wxPython implementation of the various enumeration
#              editors and the enumeration editor factory.
#
#  Symbols defined: ToolkitEditorFactory
#
#------------------------------------------------------------------------------

#-------------------------------------------------------------------------------
#  Imports:
#-------------------------------------------------------------------------------

import wx

from string \
    import ascii_lowercase
    
from editor \
    import Editor
    
from constants \
    import OKColor, ErrorColor
    
from helper \
    import enum_values_changed
    
from editor_factory \
    import EditorFactory
    
from enthought.traits \
    import Any, Range, Enum, Str, Trait, Event, Property
           
from enthought.traits.ui.ui_traits \
    import SequenceTypes

#-------------------------------------------------------------------------------
#  Trait definitions:  
#-------------------------------------------------------------------------------

# Display modes supported for custom editor:
Mode = Enum( 'radio', 'list' )

#-------------------------------------------------------------------------------
#  'ToolkitEditorFactory' class:
#-------------------------------------------------------------------------------

class ToolkitEditorFactory ( EditorFactory ):
    
    #---------------------------------------------------------------------------
    #  Trait definitions:
    #---------------------------------------------------------------------------
    
    values   = Any            # Values to enumerate (can be a list, tuple, dict,
                              # or a CTrait or TraitHandler than is 'mapped')
    object   = Str( 'object' )# Name of the context object containing the
                              # enumeration data
    name     = Str            # Name of the trait on 'object' containing the
                              # enumeration data
    evaluate = Any            # (Optional) function used to evaluate text input
    cols     = Range( 1, 20 ) # # of columns to use when displayed as a grid
    mode     = Mode           # Display modes supported for custom editor
    values_modified = Event   # Fired when the 'values' trait has been updated
    
    #---------------------------------------------------------------------------
    #  Recomputes the mappings whenever the 'values' trait is changed:
    #---------------------------------------------------------------------------
     
    def _values_changed ( self ):
        """ Recomputes the mappings whenever the 'values' trait is changed.
        """
        self._names, self._mapping, self._inverse_mapping = \
            enum_values_changed( self.values )
            
        self.values_modified = True
    
    #---------------------------------------------------------------------------
    #  'Editor' factory methods:
    #---------------------------------------------------------------------------
    
    def simple_editor ( self, ui, object, name, description, parent ):
        return SimpleEditor( parent,
                             factory     = self, 
                             ui          = ui, 
                             object      = object, 
                             name        = name, 
                             description = description ) 
    
    def custom_editor ( self, ui, object, name, description, parent ):
        if self.mode == 'radio':
            return RadioEditor( parent,
                                factory     = self, 
                                ui          = ui, 
                                object      = object, 
                                name        = name, 
                                description = description )
        else:
            return ListEditor( parent,
                               factory     = self, 
                               ui          = ui, 
                               object      = object, 
                               name        = name, 
                               description = description ) 
                                      
#-------------------------------------------------------------------------------
#  'BaseEditor' class:
#-------------------------------------------------------------------------------
                               
class BaseEditor ( Editor ):
    
    #---------------------------------------------------------------------------
    #  Trait definitions:  
    #---------------------------------------------------------------------------
        
    names           = Property  # Current set of enumeration names
    mapping         = Property  # Current mapping from names to values
    inverse_mapping = Property  # Current inverse mapping from values to names
        
    #---------------------------------------------------------------------------
    #  Finishes initializing the editor by creating the underlying toolkit
    #  widget:
    #---------------------------------------------------------------------------
        
    def init ( self, parent ):
        """ Finishes initializing the editor by creating the underlying toolkit
            widget.
        """
        factory = self.factory
        if factory.name != '':
            self._object = self.ui.context[ factory.object ]
            self._name   = factory.name
            self.values_changed()
            self._object.on_trait_change( self._values_changed, self._name )
            self._object.on_trait_change( self._values_changed, 
                                          self._name + '_items' )
        else:
            factory.on_trait_change( self.rebuild_editor, 'values_modified' )
            
    #---------------------------------------------------------------------------
    #  Gets the current set of enumeration names:  
    #---------------------------------------------------------------------------
    
    def _get_names ( self ):
        """ Gets the current set of enumeration names.
        """
        if self._object is None:
            return self.factory._names
        return self._names
            
    #---------------------------------------------------------------------------
    #  Gets the current mapping:
    #---------------------------------------------------------------------------
    
    def _get_mapping ( self ):
        """ Gets the current mapping.
        """
        if self._object is None:
            return self.factory._mapping
        return self._mapping
            
    #---------------------------------------------------------------------------
    #  Gets the current inverse mapping:
    #---------------------------------------------------------------------------
    
    def _get_inverse_mapping ( self ):
        """ Gets the current inverse mapping.
        """
        if self._object is None:
            return self.factory._inverse_mapping
        return self._inverse_mapping
            
    #---------------------------------------------------------------------------
    #  Rebuilds the contents of the editor whenever the original factory 
    #  object's 'values' trait changes:  
    #---------------------------------------------------------------------------
                        
    def rebuild_editor ( self ):
        """ Rebuilds the contents of the editor whenever the original factory
            object's 'values' trait changes.
        """
        raise NotImplementedError
            
    #---------------------------------------------------------------------------
    #  Recomputes the cached data based on the underlying enumeration model:
    #---------------------------------------------------------------------------
                        
    def values_changed ( self ):
        """ Recomputes the cached data based on the underlying enumeration model.
        """
        self._names, self._mapping, self._inverse_mapping = \
            enum_values_changed( getattr( self._object, self._name ) )
            
    #---------------------------------------------------------------------------
    #  Handles the underlying object model's enumeration set being changed:  
    #---------------------------------------------------------------------------
                        
    def _values_changed ( self ):
        """ Handles the underlying object model's enumeration set being changed.
        """
        self.values_changed()
        self.rebuild_editor()
        
    #---------------------------------------------------------------------------
    #  Disposes of the contents of an editor:    
    #---------------------------------------------------------------------------
                
    def dispose ( self ):
        """ Disposes of the contents of an editor.
        """
        super( BaseEditor, self ).dispose()
        if self._object is not None:
            self._object.on_trait_change( self._values_changed, 
                                          self._name, remove = True )
            self._object.on_trait_change( self._values_changed, 
                                          self._name + '_items', remove = True )
        else:
            self.factory.on_trait_change( self.rebuild_editor,
                                          'values_modified', remove = True )
                                      
#-------------------------------------------------------------------------------
#  'SimpleEditor' class:
#-------------------------------------------------------------------------------
                               
class SimpleEditor ( BaseEditor ):
        
    #---------------------------------------------------------------------------
    #  Finishes initializing the editor by creating the underlying toolkit
    #  widget:
    #---------------------------------------------------------------------------
        
    def init ( self, parent ):
        """ Finishes initializing the editor by creating the underlying toolkit
            widget.
        """
        super( SimpleEditor, self ).init( parent )
        
        if self.factory.evaluate is None:
            self.control = control = wx.Choice( parent, -1, wx.Point( 0, 0 ), 
                                                wx.Size( -1, -1 ), self.names )
            wx.EVT_CHOICE( parent, self.control.GetId(), self.update_object )
        else:
            self.control = control = wx.ComboBox( parent, -1, '',
                                wx.Point( 0, 0 ), wx.Size( -1, -1 ), self.names,
                                style = wx.CB_DROPDOWN )
            wx.EVT_COMBOBOX( parent, control.GetId(), self.update_object )
            wx.EVT_TEXT_ENTER( parent, control.GetId(), 
                               self.update_text_object )
            wx.EVT_KILL_FOCUS( control, self.on_kill_focus )
            if not self.factory.is_grid_cell:
                wx.EVT_TEXT( parent, control.GetId(), self.update_text_object )

    #---------------------------------------------------------------------------
    #  Handles the user selecting a new value from the combo box:
    #---------------------------------------------------------------------------
  
    def update_object ( self, event ):
        """ Handles the user selecting a new value from the combo box.
        """
        self._no_update = True
        self.value = self.mapping[ event.GetString() ]
        self._no_update = False

    #---------------------------------------------------------------------------
    #  Handles the user typing text into the combo box text entry field:
    #---------------------------------------------------------------------------
    
    def update_text_object ( self, event ):
        """ Handles the user typing text into the combo box text entry field.
        """
        value = self.control.GetValue()
        try:
            value = self.mapping[ value ]
        except:
            try:
                value = self.factory.evaluate( value )
            except Exception, ex:
                self.error(ex)
                return

        self._no_update = True
        try:
            self.value = value
            self.control.SetBackgroundColour( OKColor )
            self.control.Refresh()
        except:
            pass
        self._no_update = False
        
    #---------------------------------------------------------------------------
    #  Handles the control losing the keyboard focus:  
    #---------------------------------------------------------------------------
                
    def on_kill_focus ( self, event ):
        """ Handles the control losing the keyboard focus.
        """
        self.update_text_object( event )
        event.Skip()
        
    #---------------------------------------------------------------------------
    #  Updates the editor when the object trait changes external to the editor:
    #---------------------------------------------------------------------------
        
    def update_editor ( self ):
        """ Updates the editor when the object trait changes external to the 
            editor.
        """
        if not self._no_update:
            if self.factory.evaluate is None:
                try:
                    self.control.SetStringSelection( 
                                     self.inverse_mapping[ self.value ] )
                except:
                    pass
            else:
                try:
                    self.control.SetValue( self.str_value )
                except:
                    pass
        
    #---------------------------------------------------------------------------
    #  Handles an error that occurs while setting the object's trait value:
    #---------------------------------------------------------------------------
        
    def error ( self, excp ):
        """ Handles an error that occurs while setting the object's trait value.
        """
        self.control.SetBackgroundColour( ErrorColor )
        self.control.Refresh()
            
    #---------------------------------------------------------------------------
    #  Rebuilds the contents of the editor whenever the original factory 
    #  object's 'values' trait changes:  
    #---------------------------------------------------------------------------
                        
    def rebuild_editor ( self ):
        """ Rebuilds the contents of the editor whenever the original factory
            object's 'values' trait changes.
        """
        control = self.control
        control.Clear()
        for name in self.names:
            control.Append( name )
            
        self.update_editor()
                                      
#-------------------------------------------------------------------------------
#  'RadioEditor' class:
#-------------------------------------------------------------------------------
                               
class RadioEditor ( BaseEditor ):
        
    #---------------------------------------------------------------------------
    #  Finishes initializing the editor by creating the underlying toolkit
    #  widget:
    #---------------------------------------------------------------------------
        
    def init ( self, parent ):
        """ Finishes initializing the editor by creating the underlying toolkit
            widget.
        """
        super( RadioEditor, self ).init( parent )
            
        # Create a panel to hold all of the radio buttons:
        self.control = wx.Panel( parent, -1 )
        self.rebuild_editor()
   
    #---------------------------------------------------------------------------
    #  Handles the user clicking one of the 'custom' radio buttons:
    #---------------------------------------------------------------------------
    
    def update_object ( self, event ):
        """ Handles the user clicking one of the 'custom' radio buttons.
        """
        self.value = event.GetEventObject().value 
        
    #---------------------------------------------------------------------------
    #  Updates the editor when the object trait changes external to the editor:
    #---------------------------------------------------------------------------
        
    def update_editor ( self ):
        """ Updates the editor when the object trait changes external to the 
            editor.
        """
        value = self.value
        for button in self.control.GetChildren():
            button.SetValue( button.value == value )
            
    #---------------------------------------------------------------------------
    #  Rebuilds the contents of the editor whenever the original factory 
    #  object's 'values' trait changes:  
    #---------------------------------------------------------------------------
                        
    def rebuild_editor ( self ):
        """ Rebuilds the contents of the editor whenever the original factory
            object's 'values' trait changes.
        """
        # Clear any existing content:
        panel = self.control
        panel.SetSizer( None )
        panel.DestroyChildren()
                              
        # Get the current trait value:
        cur_name = self.str_value
                           
        # Create a sizer to manage the radio buttons:
        names   = self.names
        mapping = self.mapping
        n       = len( names )
        cols    = self.factory.cols
        rows    = (n + cols - 1) / cols
        incr    = [ n / cols ] * cols
        rem     = n % cols
        for i in range( cols ):
            incr[i] += (rem > i)
        incr[-1] = -(reduce( lambda x, y: x + y, incr[:-1], 0 ) - 1)
        if cols > 1:
            sizer = wx.GridSizer( 0, cols, 2, 4 )
        else:
            sizer = wx.BoxSizer( wx.VERTICAL )
        
        # Add the set of all possible choices:
        style = wx.RB_GROUP
        index = 0
        for i in range( rows ):
            for j in range( cols ):
                if n > 0:
                    name = label = names[ index ]
                    if label[:1] in ascii_lowercase:
                        label = label.capitalize()
                    control = wx.RadioButton( panel, -1, label, style = style )
                    control.value = mapping[ name ]
                    style         = 0
                    control.SetValue( name == cur_name )
                    wx.EVT_RADIOBUTTON( panel, control.GetId(), 
                                        self.update_object )
                    self.set_tooltip( control )
                    index += incr[j]
                    n     -= 1
                else:
                    control = wx.RadioButton( panel, -1, '' )
                    control.value = ''
                    control.Show( False )
                sizer.Add( control, 0, wx.NORTH, 5 )
     
        # Set-up the layout:
        panel.SetSizerAndFit( sizer )
                                            
#-------------------------------------------------------------------------------
#  'ListEditor' class:
#-------------------------------------------------------------------------------
                               
class ListEditor ( BaseEditor ):
        
    #---------------------------------------------------------------------------
    #  Finishes initializing the editor by creating the underlying toolkit
    #  widget:
    #---------------------------------------------------------------------------
        
    def init ( self, parent ):
        """ Finishes initializing the editor by creating the underlying toolkit
            widget.
        """
        super( ListEditor, self ).init( parent )
        
        # Create a panel to hold all of the radio buttons:
        self.control = wx.ListBox( parent, -1, wx.Point( 0, 0 ), 
                                   wx.Size( -1, -1 ), self.names,
                                   style = wx.LB_SINGLE | wx.LB_NEEDED_SB )
        wx.EVT_LISTBOX( parent, self.control.GetId(), self.update_object ) 
   
    #---------------------------------------------------------------------------
    #  Handles the user selecting a list box item:
    #---------------------------------------------------------------------------
    
    def update_object ( self, event ):
        """ Handles the user selecting a list box item.
        """
        value = self.control.GetStringSelection()
        try:
            value = self.mapping[ value ]
        except:
            try:
                value = self.factory.evaluate( value )
            except:
                pass
        self.value = value
        
    #---------------------------------------------------------------------------
    #  Updates the editor when the object trait changes external to the editor:
    #---------------------------------------------------------------------------
        
    def update_editor ( self ):
        """ Updates the editor when the object trait changes external to the 
            editor.
        """
        control = self.control
        try:
            index = control.FindString( self.inverse_mapping[ self.value ] )
            if index >= 0:
                control.SetSelection( index )
        except:
            pass
            
    #---------------------------------------------------------------------------
    #  Rebuilds the contents of the editor whenever the original factory 
    #  object's 'values' trait changes:  
    #---------------------------------------------------------------------------
                        
    def rebuild_editor ( self ):
        """ Rebuilds the contents of the editor whenever the original factory
            object's 'values' trait changes.
        """
        control = self.control
        control.Clear()
        for name in self.names:
            control.Append( name )
            
        # fixme: Is this line necessary?
        self.update_editor()

