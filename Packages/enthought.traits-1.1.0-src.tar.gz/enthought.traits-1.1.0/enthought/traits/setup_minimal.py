#
# minimal setup.py which only builds the C extensions for Traits and
# only requires the basic distutils...assumes setup.py build_ext --inplace
#
# Rick Ratzel - 2006-08-31
#
from distutils.core import setup, Extension

setup(
    name="traits",
    version="1.1.0",
    ext_modules=[Extension( "ctraits", ["ctraits.c"] )],
    )
